package com.harindra.iptvpro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException
import java.io.Reader
import java.net.SocketTimeoutException
import java.util.Calendar
import java.util.TimeZone

/**
 * StreamX Media3 Pro v18.1 — Complete Unit Test Suite:
 * Covers all existing v18.0 parser/network/preloader/security tests plus v18.1 mandatory
 * Content Separation (M3U Live-Only, Xtream VOD/Series Separation, Adversarial Channel Names,
 * Movie Details & Trailer validation, Series Seasons/Episodes & Auto-Next Episode,
 * Continue Watching eligibility, Watchlist & Account Isolation, Universal Search, Low-RAM Mode).
 */
class M3uParserTest {

    @Test
    fun parsesMetadataAndChannelUrl() {
        val playlist = """#EXTM3U
#EXTINF:-1 tvg-id="news.in" tvg-logo="https://cdn.example/logo.png" group-title="News",India News HD
https://stream.example/news/index.m3u8
""".trimIndent()

        val channels = M3uParser.parse(playlist)
        assertEquals(1, channels.size)
        assertEquals("India News HD", channels[0].name)
        assertEquals("News", channels[0].category)
        assertEquals("news.in", channels[0].epgId)
        assertEquals("https://cdn.example/logo.png", channels[0].logoUrl)
        assertEquals("https://stream.example/news/index.m3u8", channels[0].streamUrl)
        assertEquals(ContentSourceType.M3U_LIVE, channels[0].sourceType)
        assertTrue(channels[0].isLiveChannel())
        assertFalse(channels[0].isVodMovie())
        assertFalse(channels[0].isSeriesEpisode())
    }

    @Test
    fun parsesUnquotedAttributesCustomChNoAndSmartCategoriesWhilePreservingM3uLiveType() {
        val playlist = """#EXTM3U
#EXTINF:-1 tvg-id=star.sports.hd tvg-chno=505,Star Cricket Live
https://stream.example/live/cricket.m3u8
#EXTINF:-1,Blockbuster Action Movie (2025) 1080p
https://stream.example/movie/user/pass/9001.mp4
""".trimIndent()

        val channels = M3uParser.parse(playlist)
        assertEquals(2, channels.size)
        assertEquals(505, channels[0].number)
        assertEquals("star.sports.hd", channels[0].epgId)
        assertEquals("Sports", channels[0].category)
        assertEquals(ContentSourceType.M3U_LIVE, channels[0].sourceType)
        assertEquals(EntertainmentSection.LIVE_TV, channels[0].primarySection())

        // Even if an M3U entry has a movie-like name or .mp4 URL, v18.1 Rule 2A requires it to stay M3U_LIVE
        assertEquals(ContentSourceType.M3U_LIVE, channels[1].sourceType)
        assertTrue(channels[1].isLiveChannel())
        assertFalse(channels[1].isVodMovie())
        assertFalse(channels[1].isSeriesEpisode())
        assertEquals(EntertainmentSection.LIVE_TV, channels[1].primarySection())
        assertEquals("2025", channels[1].extractReleaseYear())
        assertEquals("1080p", channels[1].extractQualityBadge())
    }

    /**
     * Section 13A & 13C: M3U-Only and Adversarial Channel Name Tests.
     * Verifies that Live TV channels with movie/series names, 24x7 show names,
     * group-title="Movies"/"Series", or .mp4/.mkv URLs NEVER leak into Movies or Series.
     */
    @Test
    fun m3uAdversarialMovieAndSeriesChannelNamesAlwaysStayInLiveTv() {
        val adversarialPlaylist = """#EXTM3U
#EXTINF:-1 group-title="Movies",Bollywood Movies 24x7
https://stream.example/live/bollywood24x7.m3u8
#EXTINF:-1 group-title="Hollywood Movies",Hollywood Action Movies
https://stream.example/live/hollywood.ts
#EXTINF:-1 group-title="South Cinema",South Movie Mania (2025)
https://stream.example/live/south.mp4
#EXTINF:-1 group-title="Series",TMKOC 24x7
https://stream.example/live/tmkoc.m3u8
#EXTINF:-1 group-title="Hindi Series",CID Series Channel
https://stream.example/live/cid.m3u8
#EXTINF:-1 group-title="Web Series",Mirzapur Live S01E01
https://stream.example/live/mirzapur.mkv
#EXTINF:-1 group-title="Series",Web Series 24x7
https://stream.example/live/webseries24x7.m3u8
#EXTINF:-1 group-title="Drama",Drama Serial HD
https://stream.example/live/drama.m3u8
""".trimIndent()

        val channels = M3uParser.parse(adversarialPlaylist)
        assertEquals(8, channels.size)

        for (ch in channels) {
            assertEquals("Channel ${ch.name} must be M3U_LIVE", ContentSourceType.M3U_LIVE, ch.sourceType)
            assertEquals("Channel ${ch.name} must map to LIVE_TV", EntertainmentSection.LIVE_TV, ch.primarySection())
            assertTrue("Channel ${ch.name} must be live", ch.isLiveChannel())
            assertFalse("Channel ${ch.name} must NOT be VOD Movie", ch.isVodMovie())
            assertFalse("Channel ${ch.name} must NOT be Series Episode", ch.isSeriesEpisode())
        }

        // Verify Series grouping ignores M3U_LIVE entries completely
        val indices = IntArray(channels.size) { it }
        val seriesGroups = MediaCatalogEngine.groupSeriesCatalog(channels, indices)
        assertTrue("M3U channels must never form VOD Series groups", seriesGroups.isEmpty())
    }

    /**
     * Section 13B & 13C: Xtream Separation Tests.
     * Verifies that Xtream Live (`XTREAM_LIVE`), Xtream VOD (`XTREAM_VOD_MOVIE`),
     * and Xtream Series (`XTREAM_SERIES` / `XTREAM_SERIES_EPISODE`) are strictly separated by sourceType.
     */
    @Test
    fun separatesXtreamLiveVodMoviesAndSeriesByExplicitContentSourceType() {
        val xtreamLiveAdversarial = Channel(
            id = "live_101",
            number = 101,
            name = "Bollywood Movies 24x7",
            category = "Hindi Movies Live",
            streamUrl = "http://line.example:8080/live/u/p/101.m3u8",
            backupUrl = "http://line.example:8080/live/u/p/101.ts",
            logoUrl = "https://cdn.example/live.png",
            epgId = "bollywood.live",
            sourceType = ContentSourceType.XTREAM_LIVE
        )
        assertTrue(xtreamLiveAdversarial.isLiveChannel())
        assertFalse(xtreamLiveAdversarial.isVodMovie())
        assertFalse(xtreamLiveAdversarial.isSeriesEpisode())
        assertEquals(EntertainmentSection.LIVE_TV, xtreamLiveAdversarial.primarySection())

        val xtreamVodMovie = Channel(
            id = "vod_501",
            number = 1,
            name = "Night Silence (2024)",
            category = "BOLLYWOOD (2025-2026)",
            streamUrl = "http://line.example:8080/movie/u/p/501.mp4",
            backupUrl = "http://line.example:8080/movie/u/p/501.mkv",
            logoUrl = "https://cdn.example/night_silence.jpg",
            epgId = "",
            sourceType = ContentSourceType.XTREAM_VOD_MOVIE,
            rating = "4.7",
            releaseDate = "2024-10-31",
            genre = "Horror, Drama, Mystery",
            cast = "Maciej Damiecki, Zdzislaw Wardejn",
            director = "Bartosz M. Kowalski",
            plot = "A theatre actor whose health is failing gets admitted to a nursing home.",
            trailerUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
            addedTimestamp = 1730332800L,
            containerExtension = "mp4"
        )
        assertFalse(xtreamVodMovie.isLiveChannel())
        assertTrue(xtreamVodMovie.isVodMovie())
        assertFalse(xtreamVodMovie.isSeriesEpisode())
        assertEquals(EntertainmentSection.MOVIES, xtreamVodMovie.primarySection())
        assertTrue(xtreamVodMovie.hasValidTrailer())
        assertEquals("2024", xtreamVodMovie.extractReleaseYear())

        val ep12 = Channel(
            id = "series_ep_900_12",
            number = 12,
            name = "HURMAT (2026) - S01E12",
            category = "PAK: HUM TV",
            streamUrl = "http://line.example:8080/series/u/p/9012.mp4",
            backupUrl = "http://line.example:8080/series/u/p/9012.mkv",
            logoUrl = "https://cdn.example/hurmat.jpg",
            epgId = "",
            sourceType = ContentSourceType.XTREAM_SERIES_EPISODE,
            seriesId = 900,
            seasonNumber = 1,
            episodeNumber = 12,
            releaseDate = "2026-10-04",
            genre = "Drama / Family"
        )
        val ep13 = ep12.copy(
            id = "series_ep_900_13",
            number = 13,
            name = "HURMAT (2026) - S01E13",
            streamUrl = "http://line.example:8080/series/u/p/9013.mp4",
            episodeNumber = 13
        )
        val s2ep1 = ep12.copy(
            id = "series_ep_900_201",
            number = 1,
            name = "HURMAT (2026) - S02E01",
            streamUrl = "http://line.example:8080/series/u/p/9201.mp4",
            seasonNumber = 2,
            episodeNumber = 1
        )

        assertTrue(ep12.isSeriesEpisode())
        assertFalse(ep12.isVodMovie())
        assertFalse(ep12.isLiveChannel())
        assertEquals(EntertainmentSection.SERIES, ep12.primarySection())

        // Section 13E & 18L: Series Seasons/Episodes & Auto-Next Episode resolution
        val seriesGroup = SeriesCatalogGroup(
            seriesId = 900,
            title = "HURMAT (2026)",
            category = "PAK: HUM TV",
            posterUrl = "https://cdn.example/hurmat.jpg",
            backdropUrl = "https://cdn.example/hurmat_bg.jpg",
            releaseYear = "2026",
            releaseDate = "2026-10-04",
            rating = "4.8",
            genre = "Drama / Family",
            cast = "Dananeer Mobeen, Shahveer Jaffery",
            director = "Nadeem Siddique",
            plot = "The world outside is never simple.",
            seasons = mapOf(
                1 to listOf(
                    SeriesEpisodeItem(ep12, 0, "HURMAT (2026)", 1, 12, "HURMAT (2026) - S01E12"),
                    SeriesEpisodeItem(ep13, 1, "HURMAT (2026)", 1, 13, "HURMAT (2026) - S01E13")
                ),
                2 to listOf(
                    SeriesEpisodeItem(s2ep1, 2, "HURMAT (2026)", 2, 1, "HURMAT (2026) - S02E01")
                )
            )
        )
        assertEquals(2, seriesGroup.seasonCount)
        assertEquals(3, seriesGroup.totalEpisodes)

        val nextAfterEp12 = MediaCatalogEngine.findNextEpisodeInSeries(seriesGroup, ep12)
        assertNotNull(nextAfterEp12)
        assertEquals("series_ep_900_13", nextAfterEp12?.channel?.id)

        val nextAfterEp13 = MediaCatalogEngine.findNextEpisodeInSeries(seriesGroup, ep13)
        assertNotNull(nextAfterEp13)
        assertEquals("series_ep_900_201", nextAfterEp13?.channel?.id)

        val nextAfterLast = MediaCatalogEngine.findNextEpisodeInSeries(seriesGroup, s2ep1)
        assertNull(nextAfterLast)
    }

    /**
     * Section 13D: Movie Details & Trailer validation tests.
     */
    @Test
    fun validatesMovieDetailsAndGenuineTrailerHandling() {
        val movieWithYtId = Channel(
            id = "vod_1",
            number = 1,
            name = "Test Movie (2025)",
            category = "Action",
            streamUrl = "http://line.example/movie/u/p/1.mp4",
            logoUrl = "",
            epgId = "",
            sourceType = ContentSourceType.XTREAM_VOD_MOVIE,
            trailerUrl = "dQw4w9WgXcQ"
        )
        assertTrue(movieWithYtId.hasValidTrailer())

        val movieWithoutTrailer = movieWithYtId.copy(trailerUrl = "   ")
        assertFalse(movieWithoutTrailer.hasValidTrailer())

        val movieWithNullStringTrailer = movieWithYtId.copy(trailerUrl = "null")
        assertFalse(movieWithNullStringTrailer.hasValidTrailer())
    }

    /**
     * Section 17A, 17C, 17E & 18I, 18K, 18M: Continue Watching, Category Sidebar Counts,
     * Sort Modes, and Low-Memory Mode configuration.
     */
    @Test
    fun buildsVodCategorySidebarCountsAndAppliesSortOrder() {
        val m1 = Channel(
            id = "vod_1",
            number = 1,
            name = "Zebra Action (2024)",
            category = "BOLLYWOOD (2025-2026)",
            streamUrl = "http://line.example/movie/u/p/1.mp4",
            logoUrl = "",
            epgId = "",
            sourceType = ContentSourceType.XTREAM_VOD_MOVIE,
            addedTimestamp = 1000L
        )
        val m2 = Channel(
            id = "vod_2",
            number = 2,
            name = "Alpha Thriller (2026)",
            category = "BOLLYWOOD (2025-2026)",
            streamUrl = "http://line.example/movie/u/p/2.mp4",
            logoUrl = "",
            epgId = "",
            sourceType = ContentSourceType.XTREAM_VOD_MOVIE,
            addedTimestamp = 5000L
        )
        val m3 = Channel(
            id = "vod_3",
            number = 3,
            name = "Beta Comedy (2025)",
            category = "SOUTH INDIAN",
            streamUrl = "http://line.example/movie/u/p/3.mp4",
            logoUrl = "",
            epgId = "",
            sourceType = ContentSourceType.XTREAM_VOD_MOVIE,
            addedTimestamp = 3000L
        )
        val movies = listOf(m1, m2, m3)

        val sidebar = MediaCatalogEngine.buildMovieCategorySidebar(
            vodMovies = movies,
            watchlistIds = setOf("vod_2"),
            continueWatchingIds = setOf("vod_1", "vod_3")
        )
        val favItem = sidebar.first { it.key == MediaCatalogEngine.CAT_FAVORITES }
        assertEquals(1, favItem.count)
        assertEquals("FAVORITES (1)", favItem.displayLabel(showCountForSpecial = true))

        val cwItem = sidebar.first { it.key == MediaCatalogEngine.CAT_CONTINUE_WATCHING }
        assertEquals(2, cwItem.count)

        val bollywoodItem = sidebar.first { it.key == "BOLLYWOOD (2025-2026)" }
        assertEquals(2, bollywoodItem.count)
        assertEquals("BOLLYWOOD (2025-2026) (2)", bollywoodItem.displayLabel())

        val sortedNewest = MediaCatalogEngine.sortChannels(movies, VodSortOrder.NEWEST_FIRST)
        assertEquals("vod_2", sortedNewest.first().id)

        val sortedOldest = MediaCatalogEngine.sortChannels(movies, VodSortOrder.OLDEST_FIRST)
        assertEquals("vod_1", sortedOldest.first().id)

        val sortedAZ = MediaCatalogEngine.sortChannels(movies, VodSortOrder.A_TO_Z)
        assertEquals("Alpha Thriller (2026)", sortedAZ.first().name)

        val sortedZA = MediaCatalogEngine.sortChannels(movies, VodSortOrder.Z_TO_A)
        assertEquals("Zebra Action (2024)", sortedZA.first().name)

        // Low-Memory Mode bounds verification
        assertEquals(144, PerformanceMode.LOW_MEMORY.posterWidthPx)
        assertEquals(210, PerformanceMode.LOW_MEMORY.posterHeightPx)
        assertFalse(PerformanceMode.LOW_MEMORY.enableFocusScaleAnimation)
    }

    @Test
    fun removesUtf8BomAndDeduplicatesIdenticalStreamUrls() {
        val playlist = "\uFEFF" + """#EXTM3U
#EXTINF:-1,First
https://stream.example/live.m3u8
#EXTINF:-1,Duplicate
https://stream.example/live.m3u8
"""
        val channels = M3uParser.parse(playlist)
        assertEquals(1, channels.size)
        assertEquals("First", channels.first().name)
    }

    @Test
    fun supportsReaderInputAndChannelLimit() {
        val playlist = """#EXTM3U
#EXTINF:-1,One
https://stream.example/1.m3u8
#EXTINF:-1,Two
https://stream.example/2.m3u8
"""
        val channels = M3uParser.parse(playlist.reader(), maxChannels = 1)
        assertEquals(1, channels.size)
        assertTrue(channels.first().number == 1)
    }

    @Test
    fun attachesSecondDistinctStreamUrlAsBackupUrlForSameChannelName() {
        val playlist = """#EXTM3U
#EXTINF:-1 group-title="Sports",Sports 18 HD
https://stream.example/primary.m3u8
#EXTINF:-1 group-title="Sports",Sports 18 HD
https://stream.example/backup.m3u8
"""
        val channels = M3uParser.parse(playlist)
        assertEquals(1, channels.size)
        assertEquals("https://stream.example/primary.m3u8", channels[0].streamUrl)
        assertEquals("https://stream.example/backup.m3u8", channels[0].backupUrl)
    }

    @Test
    fun normalizedPairHashIsCaseAndWhitespaceInsensitive() {
        val h1 = M3uParser.fnv1a64NormalizedPair("  Sports ", "  Star Sports 1 HD ")
        val h2 = M3uParser.fnv1a64NormalizedPair("sports", "star sports 1 hd")
        val h3 = M3uParser.fnv1a64NormalizedPair("Movies", "star sports 1 hd")
        assertEquals(h1, h2)
        assertNotEquals(h1, h3)
    }

    @Test
    fun handlesInvalidAndBrokenEntriesGracefully() {
        val playlist = """#EXTM3U
#EXTINF:-1
ftp://unsupported.example/file.ts
#EXTINF:-1 group-title="Movies",Valid Cinema HD
https://stream.example/cinema/live.m3u8
not_a_valid_url_line
""".trimIndent()
        val channels = M3uParser.parse(playlist)
        assertEquals(1, channels.size)
        assertEquals("Valid Cinema HD", channels[0].name)
        assertEquals(ContentSourceType.M3U_LIVE, channels[0].sourceType)
    }

    @Test
    fun extractsPipeAndExtVlcOptCustomHeadersAndRedactsCredentials() {
        val playlist = """#EXTM3U
#EXTINF:-1 group-title="VIP",VIP Sports 1
#EXTVLCOPT:http-user-agent=CustomPlayer/2.0
#EXTVLCOPT:http-referrer=https://portal.example/
#EXTVLCOPT:http-origin=https://origin.example
https://edge.example/live/ch1.m3u8?token=secret123|Authorization=Bearer%20tok999&Cookie=sid=abc
""".trimIndent()

        val channels = M3uParser.parse(playlist)
        assertEquals(1, channels.size)
        assertEquals("https://edge.example/live/ch1.m3u8?token=secret123", channels[0].streamUrl)

        val headers = NetworkClient.headersForUrl(channels[0].streamUrl)
        assertEquals("CustomPlayer/2.0", headers["User-Agent"])
        assertEquals("https://portal.example/", headers["Referer"])
        assertEquals("https://origin.example", headers["Origin"])
        assertEquals("Bearer tok999", headers["Authorization"])
        assertEquals("sid=abc", headers["Cookie"])

        val redacted = NetworkClient.redactSensitiveUrl(
            "http://line.server.com:8080/live/harindra/mySecretPass/402.m3u8?token=xyz987&password=p1"
        )
        assertFalse(redacted.contains("mySecretPass"))
        assertFalse(redacted.contains("xyz987"))
        assertFalse(redacted.contains("p1"))
        assertTrue(redacted.contains("****"))

        val redactedVod = NetworkClient.redactSensitiveUrl(
            "http://line.server.com:8080/movie/harindra/vodPass99/901.mp4"
        )
        assertFalse(redactedVod.contains("vodPass99"))
        assertTrue(redactedVod.contains("****"))
    }

    @Test
    fun parses30kAnd60kLargePlaylistsWithinLimit() {
        val totalToGenerate = 60_000
        val syntheticReader = object : Reader() {
            private var currentChannel = 0
            private var buffer = "#EXTM3U\n"
            private var pos = 0

            override fun read(cbuf: CharArray, off: Int, len: Int): Int {
                if (pos >= buffer.length) {
                    if (currentChannel >= totalToGenerate) return -1
                    currentChannel++
                    buffer = "#EXTINF:-1 group-title=\"Group${currentChannel % 20}\",Channel $currentChannel\nhttps://cdn.example/live/$currentChannel.m3u8\n"
                    pos = 0
                }
                val toCopy = (buffer.length - pos).coerceAtMost(len)
                buffer.toCharArray(cbuf, off, pos, pos + toCopy)
                pos += toCopy
                return toCopy
            }

            override fun close() {}
        }

        var firstBatchCount = 0
        val parsed = M3uParser.parse(
            reader = syntheticReader,
            maxChannels = 60_000,
            onFirstBatch = { firstBatchCount = it.size }
        )
        assertEquals(80, firstBatchCount)
        assertEquals(60_000, parsed.size)
        assertEquals("Channel 1", parsed.first().name)
        assertEquals("Channel 60000", parsed.last().name)
        assertEquals(ContentSourceType.M3U_LIVE, parsed.first().sourceType)
    }

    @Test
    fun detectsStreamFormatsAndParsesHlsPreloadTargetsWithTokenPreservation() {
        assertEquals(StreamPreFetcher.StreamFormat.HLS, StreamPreFetcher.detectStreamFormat("https://cdn.example/live/ch1.m3u8?token=abc"))
        assertEquals(StreamPreFetcher.StreamFormat.DASH, StreamPreFetcher.detectStreamFormat("https://cdn.example/live/manifest.mpd"))
        assertEquals(StreamPreFetcher.StreamFormat.RTSP, StreamPreFetcher.detectStreamFormat("rtsp://192.168.1.10:554/live"))
        assertEquals(StreamPreFetcher.StreamFormat.MPEG_TS, StreamPreFetcher.detectStreamFormat("http://line.server.com:8080/live/user/pass/101.ts"))

        val masterM3u8 = """#EXTM3U
#EXT-X-STREAM-INF:BANDWIDTH=12000000,RESOLUTION=3840x2160
4k/index.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=4500000,RESOLUTION=1920x1080
1080p/index.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=2200000,RESOLUTION=1280x720
720p/index.m3u8
""".trimIndent()

        val masterPlan = StreamPreFetcher.parseHlsPlaylistTargets(
            "https://cdn.example/live/master.m3u8?wmsAuthSign=tok777",
            masterM3u8
        )
        assertTrue(masterPlan.isMasterPlaylist)
        assertEquals("https://cdn.example/live/1080p/index.m3u8?wmsAuthSign=tok777", masterPlan.variantPlaylistUrl)

        val mediaM3u8 = """#EXTM3U
#EXT-X-TARGETDURATION:4
#EXT-X-MAP:URI="init.mp4"
#EXTINF:4.0,
seg100.m4s
#EXTINF:4.0,
seg101.m4s
#EXTINF:4.0,
seg102.m4s
""".trimIndent()

        val mediaPlan = StreamPreFetcher.parseHlsPlaylistTargets(
            "https://cdn.example/live/1080p/index.m3u8?wmsAuthSign=tok777",
            mediaM3u8
        )
        assertFalse(mediaPlan.isMasterPlaylist)
        assertEquals("https://cdn.example/live/1080p/init.mp4?wmsAuthSign=tok777", mediaPlan.initSegmentUrl)
        assertNotNull(mediaPlan.firstMediaSegmentUrl)
        assertEquals("https://cdn.example/live/1080p/seg101.m4s?wmsAuthSign=tok777", mediaPlan.firstMediaSegmentUrl)
    }

    @Test
    fun classifiesHttpAuthAndServerErrorsAndValidatesMediaSegmentBytes() {
        assertNull(StreamPreFetcher.classifyHttpStatus(200))
        assertNull(StreamPreFetcher.classifyHttpStatus(206))
        assertEquals(StreamPreFetcher.PreloadState.AUTH_ERROR, StreamPreFetcher.classifyHttpStatus(401))
        assertEquals(StreamPreFetcher.PreloadState.AUTH_ERROR, StreamPreFetcher.classifyHttpStatus(403))
        assertEquals(StreamPreFetcher.PreloadState.NOT_FOUND, StreamPreFetcher.classifyHttpStatus(404))
        assertEquals(StreamPreFetcher.PreloadState.RATE_LIMITED, StreamPreFetcher.classifyHttpStatus(429))
        assertEquals(StreamPreFetcher.PreloadState.SERVER_ERROR, StreamPreFetcher.classifyHttpStatus(503))
        assertEquals(StreamPreFetcher.PreloadState.TIMEOUT, StreamPreFetcher.classifyException(SocketTimeoutException("Read timed out")))
        assertEquals(StreamPreFetcher.PreloadState.CANCELLED, StreamPreFetcher.classifyException(IOException("Canceled")))

        val tsPacket = ByteArray(376).apply {
            this[0] = 0x47
            this[188] = 0x47
        }
        assertTrue(StreamPreFetcher.isValidMediaSegmentBytes(tsPacket, "video/mp2t"))

        val fmp4Init = byteArrayOf(0, 0, 0, 24, 'f'.code.toByte(), 't'.code.toByte(), 'y'.code.toByte(), 'p'.code.toByte())
        assertTrue(StreamPreFetcher.isValidMediaSegmentBytes(fmp4Init, "video/mp4"))

        val htmlError = "<html><body>403 Forbidden</body></html>".toByteArray(Charsets.UTF_8)
        assertFalse(StreamPreFetcher.isValidMediaSegmentBytes(htmlError, "text/html"))
        assertFalse(StreamPreFetcher.isValidMediaSegmentBytes(htmlError, "video/mp2t"))
    }

    @Test
    fun verifiesSaltedParentalPinHashPerformanceModesAndProgressCalculation() {
        val salt = "0123456789abcdef0123456789abcdef"
        val hash = ProfileStore.computeSaltedPinHash("2580", salt)
        assertTrue(ProfileStore.verifySaltedPinHash("2580", salt, hash))
        assertFalse(ProfileStore.verifySaltedPinHash("1234", salt, hash))
        assertFalse(ProfileStore.verifySaltedPinHash("258", salt, hash))

        assertEquals(PerformanceMode.SMART_BALANCED, PerformanceMode.fromId(null, isLowRamDevice = true))
        assertEquals(PerformanceMode.LOW_MEMORY, PerformanceMode.fromId("LOW_MEMORY", isLowRamDevice = false))

        val prog = PlaybackProgressEntry(
            contentId = "vod_9001",
            positionMs = 1_800_000L,
            durationMs = 3_600_000L,
            updatedAtMs = 1000L
        )
        assertEquals(50, prog.progressPercent())
        assertTrue(prog.isResumable())

        // Completed movie (>=95%) should not be marked resumable in Continue Watching
        val completedProg = PlaybackProgressEntry(
            contentId = "vod_9001",
            positionMs = 3_500_000L,
            durationMs = 3_600_000L,
            updatedAtMs = 2000L
        )
        assertEquals(97, completedProg.progressPercent())
        assertFalse(completedProg.isResumable())

        assertEquals(
            "http://line.server.com:8080",
            XtreamRepository().normalizeServerBaseUrl("  \uFEFFline.server.com:8080/ ")
        )
        assertEquals("starsports1", XmltvParser.normalizeEpgKey("Star_Sports_1_HD.in"))
        val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        val tsMs = XmltvParser.parseXmltvTimestampFast("20261118120000 +0530", cal)
        assertTrue(tsMs > 0L)
    }

    @Test
    fun cancelsStaleGenerationAndTracksPreloadMissFallbackCleanly() {
        val genBefore = StreamPreFetcher.currentGenerationId()
        StreamPreFetcher.notifyChannelSwitched("https://cdn.example/live/ch10.m3u8", forwardDirection = true)
        val genAfter = StreamPreFetcher.currentGenerationId()
        assertTrue(genAfter > genBefore)

        val missedSource = StreamPreFetcher.consumePreparedMediaSource("https://cdn.example/live/unpreloaded.m3u8")
        assertNull(missedSource)
    }
}
