package com.harindra.iptvpro

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.ActivityManager
import android.app.PictureInPictureParams
import android.content.ComponentCallbacks2
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Debug
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.Log
import android.util.Rational
import android.util.SparseIntArray
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.upstream.DefaultAllocator
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.MemoryCategory
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Arrays
import java.util.Date
import java.util.Locale

data class TvThemePalette(
    val name: String,
    val subtitle: String,
    val accentHex: String,
    val badgeTextHex: String,
    val statusHex: String,
    val activeRowDrawableRes: Int
)

data class GlassModalOption(
    val iconRes: Int,
    val title: String,
    val subtitle: String,
    val badgeText: String = "",
    val isHighlighted: Boolean = false,
    val onClick: () -> Unit
)

data class GlassFormFieldSpec(
    val label: String,
    val hint: String,
    val iconRes: Int,
    val initialValue: String = "",
    val inputType: Int = InputType.TYPE_CLASS_TEXT
)

data class PosterCardBindItem(
    val key: String,
    val title: String,
    val subtitle: String,
    val posterUrl: String,
    val yearBadge: String,
    val qualityBadge: String,
    val progressPercent: Int,
    val isFavorite: Boolean,
    val vodMovieIndex: Int = -1,
    val seriesSummary: SeriesGroupSummary? = null
)

enum class BufferProfile(
    val id: String,
    val label: String,
    val subtitle: String,
    val minBufferMs: Int,
    val maxBufferMs: Int,
    val playBufferMs: Int,
    val rebufferMs: Int,
    val targetBytes: Int,
    val prioritizeTimeOverSize: Boolean
) {
    LOW_MEMORY_512MB(
        "LOW_MEM",
        "Hyper-Glass 512MB (150ms Start • 3.5MB Cap)",
        "Default for 512MB RAM Smart TVs • Fast start with anti-stall guard",
        2000, 6800, 150, 500, 3584 * 1024, false
    ),
    ULTRA_FAST_ZAP(
        "ULTRA_ZAP",
        "Turbo Zap 512MB (90ms Start • 3.2MB Cap)",
        "Instant channel switching on strong broadband Wi-Fi / Ethernet",
        1800, 5800, 90, 360, 3276 * 1024, false
    ),
    LOW_LATENCY(
        "LOW_LATENCY",
        "Extreme Sports Zap (60ms Start • 3MB Cap)",
        "Minimum live broadcast edge delay for live cricket & football",
        1600, 5000, 60, 260, 3 * 1024 * 1024, false
    ),
    BALANCED(
        "BALANCED",
        "Balanced HD (120ms Start • 8MB Cap)",
        "Ideal for Android phones & 1GB+ RAM TVs",
        3800, 11000, 120, 450, 8 * 1024 * 1024, false
    ),
    STABLE(
        "STABLE",
        "Stable Shield (320ms Start • 12MB Cap)",
        "Maximum cushion against fluctuating mobile hotspot / slow Wi-Fi",
        6000, 18000, 320, 950, 12 * 1024 * 1024, true
    );

    companion object {
        fun fromId(id: String?, isLowRamDevice: Boolean): BufferProfile {
            return values().firstOrNull { it.id == id }
                ?: if (isLowRamDevice) LOW_MEMORY_512MB else BALANCED
        }
    }
}

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private var exoPlayer: ExoPlayer? = null
    private var sharedAllocator: DefaultAllocator? = null
    private var hlsChunklessFactory: HlsMediaSource.Factory? = null
    private var defaultMediaSourceFactory: DefaultMediaSourceFactory? = null
    private var lastSwitchUsedPreload: Boolean = false
    private var activePlaybackToken: Long = 0L

    private lateinit var playerView: PlayerView
    private lateinit var topControlBar: View
    private lateinit var leftChannelDrawer: View
    private lateinit var channelListRecycler: RecyclerView
    private lateinit var tvEmptyDrawer: TextView
    private lateinit var osdBanner: View
    private lateinit var tvChannelNumber: TextView
    private lateinit var tvChannelName: TextView
    private lateinit var tvChannelCategory: TextView
    private lateinit var tvOsdStreamBadge: TextView
    private lateinit var tvEpgNow: TextView
    private lateinit var osdLiveProgressBar: ProgressBar
    private lateinit var tvActiveSectionBadge: TextView
    private lateinit var btnToggleFavorite: Button
    private lateinit var btnRecallChannel: Button
    private lateinit var btnToggleDrawer: Button
    private lateinit var btnSectionLiveTv: Button
    private lateinit var btnSectionMovies: Button
    private lateinit var btnSectionSeries: Button
    private lateinit var btnUnifiedSearch: Button
    private lateinit var tabAllChannels: Button
    private lateinit var tabFavorites: Button
    private lateinit var tabRecent: Button
    private lateinit var channelSearch: EditText
    private lateinit var categoryFilter: Spinner
    private lateinit var channelLogo: ImageView

    // v18.1 4D Movies & Series Poster Grid Hub Views (Left Category Sidebar + Right Poster Grid)
    private lateinit var vodPosterGridPanel: View
    private lateinit var tvVodLiveClockDate: TextView
    private lateinit var tvVodGridHeaderTitle: TextView
    private lateinit var btnVodContinueWatching: Button
    private lateinit var btnVodFavoritesFilter: Button
    private lateinit var btnVodSortOrder: Button
    private lateinit var btnVodFetchProvider: Button
    private lateinit var btnCloseVodGrid: Button
    private lateinit var vodPosterSearch: EditText
    private lateinit var vodCategorySpinner: Spinner
    private lateinit var vodCategorySidebarRecycler: RecyclerView
    private lateinit var tvVodEmptyState: TextView
    private lateinit var vodPosterRecycler: RecyclerView
    private lateinit var posterGridAdapter: VodPosterGridAdapter
    private lateinit var vodSidebarAdapter: VodCategorySidebarAdapter

    // DTH Set-Top-Box Startup Overlay Views
    private lateinit var dthBootOverlay: View
    private lateinit var vSignalWaveOuter: View
    private lateinit var vSignalWaveInner: View
    private lateinit var tvBootHeadline: TextView
    private lateinit var tvBootStageStatus: TextView
    private lateinit var tvBootSubDetail: TextView
    private lateinit var bootProgressBar: ProgressBar
    private var outerWaveAnimator: ObjectAnimator? = null
    private var innerWaveAnimator: ObjectAnimator? = null
    private var satellitePulseAnimator: ObjectAnimator? = null
    private var isBootOverlayVisible: Boolean = true
    private var hasRenderedVideoFrame: Boolean = false

    // Real Startup, Zapping & Buffering Benchmark Timings
    private var processStartElapsedMs: Long = 0L
    private var firstUiFrameMs: Long = 0L
    private var bootReadyElapsedMs: Long = 0L
    private var firstVideoFrameMs: Long = 0L
    private var lastPlaylistLoadDurationMs: Long = 0L
    private var lastRemoteKeyPressElapsedMs: Long = 0L
    private var lastKeyPressToSelectionMs: Long = 0L
    private var lastSwitchStartElapsedMs: Long = 0L
    private var lastSelectionToPrepareMs: Long = 0L
    private var lastChannelSwitchMs: Long = 0L
    private var bufferingStartElapsedMs: Long = 0L
    private var lastBufferingDurationMs: Long = 0L
    private var lastZapForward: Boolean = true
    private var isLowRamTvDevice: Boolean = true
    private var totalDeviceRamMb: Long = 512L
    private var maxPlaylistLimit: Int = 60_000

    private lateinit var channelAdapter: ChannelDrawerAdapter
    private var searchQuery: String = ""
    private var selectedCategory: String = "All categories"
    private var suppressCategoryCallback: Boolean = false
    private var epgMap: Map<String, Pair<String, String>> = emptyMap()

    // =========================================================================
    // v18.1 STRICTLY SEPARATED LIVE TV, VOD MOVIES & SERIES CATALOGS
    // =========================================================================
    private var activeEntertainmentSection: EntertainmentSection = EntertainmentSection.LIVE_TV
    private var vodSearchQuery: String = ""
    private var selectedVodCategory: String = "RECENTLY ADDED"
    private var suppressVodCategoryCallback: Boolean = false
    private var vodSpecialFilterMode: String = "ALL" // ALL, CONTINUE, FAV, RECENT_ADDED
    private var activeVodSortOrder: VodSortOrder = VodSortOrder.RECENTLY_ADDED

    // Separate, strictly typed VOD Movies & Series Catalogs (NEVER mixed into allChannels!)
    private var vodMoviesCatalog: List<Channel> = emptyList()
    private var vodMovieIndexById: Map<String, Int> = emptyMap()
    private var seriesCatalogRaw: List<Channel> = emptyList()
    private var seriesCatalogGroups: List<SeriesGroupSummary> = emptyList()
    private val loadedSeriesEpisodesCache = HashMap<String, Map<Int, List<SeriesEpisodeItem>>>(32)
    private var vodPosterFilterJob: Job? = null
    private var vodCatalogLoadJob: Job? = null
    private var seriesCatalogLoadJob: Job? = null

    // Predictable Navigation & Back-Stack Restoration State (Requirement 5, 6, 7)
    private enum class ActivePlaybackMode {
        LIVE_TV,
        VOD_MOVIE,
        VOD_TRAILER,
        SERIES_EPISODE
    }
    private var activePlaybackMode: ActivePlaybackMode = ActivePlaybackMode.LIVE_TV
    private var activeVodMovieItem: Channel? = null
    private var activeVodMovieIndex: Int = -1
    private var activeVodMovieDetailInfo: VodMovieDetailInfo? = null
    private var activeSeriesGroup: SeriesGroupSummary? = null
    private var activeSeriesSeasonNum: Int = 1
    private var activeSeriesEpisodeItem: SeriesEpisodeItem? = null
    private var lastFocusedPosterIndex: Int = 0
    private var autoNextPromptShownForEpisodeId: String = ""
    private var autoNextCountdownDialog: AlertDialog? = null
    private var autoNextCountdownJob: Job? = null

    // Primitive IntArray Windowed Pagination for Live TV
    private var fullFilteredIndices: IntArray = IntArray(0)
    private var currentPagedLimit: Int = 1200
    private val pageStepSize: Int = 1200

    private var filterJob: Job? = null
    private var loadChannelsJob: Job? = null
    private var epgLoadJob: Job? = null
    private var bgSyncJob: Job? = null

    private val xtreamRepo = XtreamRepository()
    private lateinit var profileStore: ProfileStore
    private lateinit var channelCache: ChannelCacheStore
    private lateinit var epgCache: EpgCacheStore
    private var connectivityManager: ConnectivityManager? = null
    private var networkCallbackRegistered: Boolean = false

    private var activeSourceType: ProfileType? = null
    private var activeXtreamCreds: XtreamCredentials? = null
    private var activeM3uInput: String = ""
    private var activeM3uLabel: String = "M3U"
    private var activeAccountScope: String = "default"

    private var liveResolutionLabel: String = "Auto HD"
    private var liveTelemetryDetail: String = ""
    private var liveStatusLabel: String = "🟢 Live"
    private var subtitlesEnabled: Boolean = false
    private var selectedQualityLabel: String = "Auto"
    private var activeBufferProfile: BufferProfile = BufferProfile.LOW_MEMORY_512MB
    private var activePerformanceMode: PerformanceMode = PerformanceMode.SMART_BALANCED
    private var autoBootEnabled: Boolean = true
    private var autoResumeEnabled: Boolean = true
    private var currentPlayingStreamUrl: String = ""
    private var currentPlayingSeriesKey: String = ""
    private var currentPlayingSeasonNum: Int = 0
    private var currentPlayingEpisodeNum: Int = 0
    private var pendingResumeSeekPositionMs: Long = 0L
    private var usingBackupStream: Boolean = false
    private var unlockedSessionCategories: MutableSet<String> = HashSet()

    // Ultra-Compact RGB_565 80x80 Glide options with 3D Live TV vector placeholder
    private val logoRequestOptions by lazy {
        RequestOptions()
            .format(DecodeFormat.PREFER_RGB_565)
            .override(80, 80)
            .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
            .dontAnimate()
            .dontTransform()
            .placeholder(R.drawable.ic_3d_live_tv)
            .error(R.drawable.ic_3d_live_tv)
    }

    // Bounded RGB_565 Poster Thumbnail options for 512MB RAM TVs (prevents full-res bitmap OOM)
    private fun currentPosterRequestOptions(): RequestOptions {
        val w = if (activePerformanceMode == PerformanceMode.LOW_MEMORY) 144 else 180
        val h = if (activePerformanceMode == PerformanceMode.LOW_MEMORY) 210 else 260
        return RequestOptions()
            .format(DecodeFormat.PREFER_RGB_565)
            .override(w, h)
            .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
            .dontAnimate()
            .centerCrop()
            .placeholder(R.drawable.ic_3d_movies)
            .error(R.drawable.ic_3d_movies)
    }

    private val themes = listOf(
        TvThemePalette("Cyan 4D Cyber Crystal", "Electric Sapphire Glow • Ultra Extreme Default", "#0284C7", "#38BDF8", "#34D399", R.drawable.bg_btn_3d_cyan),
        TvThemePalette("Royal Gold 4D VIP", "Luxury Amber-Gold Bevel & Warm Highlights", "#D97706", "#FBBF24", "#FDE047", R.drawable.bg_btn_3d_gold),
        TvThemePalette("Emerald 4D Matrix", "Bio-Neon Emerald Glass & Mint Status", "#059669", "#34D399", "#6EE7B7", R.drawable.bg_btn_3d_emerald),
        TvThemePalette("Purple 4D Synthwave", "Deep Amethyst Neon & Cyber Violet Rim", "#7C3AED", "#C084FC", "#38BDF8", R.drawable.bg_btn_3d_purple),
        TvThemePalette("Crimson 4D Cinema", "Ruby Velvet Broadcast & Rose-Gold Sheen", "#E11D48", "#FB7185", "#FBBF24", R.drawable.bg_btn_3d_crimson)
    )
    private var currentThemeIndex: Int = 0

    private val playlistPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                Log.w("StreamX", "Persistable URI permission note: ${e.message}")
            }
            importLocalM3uUri(uri)
        }
    }

    private val uiHandler = Handler(Looper.getMainLooper())

    private val hideOsdRunnable: Runnable = Runnable {
        osdBanner.animate()
            .alpha(0f)
            .setDuration(if (activePerformanceMode.reducedAnimations) 60L else 140L)
            .withLayer()
            .withEndAction {
                osdBanner.visibility = View.GONE
                osdBanner.alpha = 1f
            }
            .start()
        if (leftChannelDrawer.visibility != View.VISIBLE && vodPosterGridPanel.visibility != View.VISIBLE) {
            topControlBar.visibility = View.GONE
        }
    }

    // 25ms ultra-fast debounce during rapid TV remote key-repeat zapping
    private var pendingCommitToken: Long = 0L
    private val commitPlaybackRunnable: Runnable = Runnable {
        if (pendingCommitToken == activePlaybackToken) {
            startPlaybackForCurrentChannel(forceReload = false)
        }
    }

    private val retryPlaybackRunnable: Runnable = Runnable {
        val player = exoPlayer ?: return@Runnable
        if (allChannels.isNotEmpty() || activePlaybackMode != ActivePlaybackMode.LIVE_TV) {
            if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                player.seekToDefaultPosition()
            }
            player.prepare()
            player.playWhenReady = true
        }
    }

    // Periodic VOD/Series playback progress saver + Auto-Next Episode near-end detector + Live Clock updater
    private val vodProgressTrackerRunnable: Runnable = object : Runnable {
        override fun run() {
            recordCurrentVodOrSeriesProgress()
            checkSmartAutoNextEpisodeNearEnd()
            if (vodPosterGridPanel.visibility == View.VISIBLE) {
                updateVodHeaderClockText()
            }
            uiHandler.postDelayed(this, 4000L)
        }
    }

    // Live Heap Guard (<16MB free + unallocated JVM heap check)
    private val heapGuardRunnable: Runnable = object : Runnable {
        override fun run() {
            val rt = Runtime.getRuntime()
            val freeAndUnallocated = rt.maxMemory() - (rt.totalMemory() - rt.freeMemory())
            if (freeAndUnallocated < 16L * 1024L * 1024L) {
                StreamPreFetcher.trimIdleCacheOnLowMemory()
                ChannelCacheStore.trimMemoryCache()
                sharedAllocator?.trim()
                runCatching { Glide.get(this@PlayerActivity).clearMemory() }
            }
            uiHandler.postDelayed(this, 5000L)
        }
    }

    // Fast 2.5s Playback Stall Watchdog + Smart Auto-Failover to backupUrl
    private var stallRecoveryCount: Int = 0
    private val stallWatchdogRunnable: Runnable = object : Runnable {
        override fun run() {
            val player = exoPlayer ?: return
            if (player.playbackState == Player.STATE_BUFFERING) {
                if (activePlaybackMode == ActivePlaybackMode.LIVE_TV && allChannels.isNotEmpty()) {
                    val ch = allChannels.getOrNull(currentChannelIndex)
                    if (ch != null && !usingBackupStream && ch.backupUrl.isNotBlank()) {
                        usingBackupStream = true
                        stallRecoveryCount = 0
                        Log.w("StreamX", "2.5s Watchdog failover to backupUrl for ${ch.name}")
                        liveStatusLabel = "⚡ Backup Stream"
                        updateOsdForCurrentChannel()
                        playSpecificStreamUrl(ch.backupUrl)
                        return
                    }
                }
                if (stallRecoveryCount < 3) {
                    StreamPreFetcher.updateNetworkState(connected = true, degraded = true)
                    stallRecoveryCount++
                    Log.w("StreamX", "2.5s Stall Watchdog triggered (${stallRecoveryCount}/3): recovering stream")
                    liveStatusLabel = "🔄 Fast Recovery ${stallRecoveryCount}/3..."
                    updateOsdForCurrentChannel()
                    if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                        player.seekToDefaultPosition()
                    }
                    player.prepare()
                    player.playWhenReady = true
                    uiHandler.postDelayed(this, 3000L)
                } else {
                    liveStatusLabel = "⚠️ Slow Server / Stream Stalled"
                    updateOsdForCurrentChannel()
                }
            }
        }
    }

    // Safety guard so user is never permanently stuck on the DTH startup overlay
    private val dismissBootSafetyRunnable: Runnable = Runnable {
        if (hasRenderedVideoFrame) return@Runnable
        if (allChannels.isNotEmpty()) {
            liveStatusLabel = "⏳ Connecting..."
            updateOsdForCurrentChannel()
            showZappingOsd()
            dismissDthBootOverlay("PLAYER READY • CONNECTING")
        } else {
            dismissDthBootOverlay("READY TO ADD PLAYLIST")
        }
    }

    private val persistStateRunnable: Runnable = Runnable {
        if (allChannels.isEmpty() || currentChannelIndex !in allChannels.indices) return@Runnable
        val ch = allChannels[currentChannelIndex]
        getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE).edit()
            .putString("recent_ids", recentIds.joinToString("\n"))
            .putString("last_channel_id", ch.id)
            .putInt("last_channel_index", currentChannelIndex)
            .apply()
        recordCurrentVodOrSeriesProgress()
    }

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            StreamPreFetcher.updateNetworkState(connected = true, degraded = false)
            uiHandler.post {
                val player = exoPlayer ?: return@post
                if ((allChannels.isNotEmpty() || activePlaybackMode != ActivePlaybackMode.LIVE_TV) &&
                    (player.playbackState == Player.STATE_IDLE || liveStatusLabel.startsWith("⚠️") || liveStatusLabel.startsWith("🔄"))
                ) {
                    playbackRetryCount = 0
                    stallRecoveryCount = 0
                    liveStatusLabel = "🔄 Network Restored..."
                    updateOsdForCurrentChannel()
                    if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                        player.seekToDefaultPosition()
                    }
                    player.prepare()
                    player.playWhenReady = true
                }
            }
        }

        override fun onLost(network: Network) {
            StreamPreFetcher.updateNetworkState(connected = false)
            uiHandler.post {
                liveStatusLabel = "⚠️ Waiting for Network..."
                updateOsdForCurrentChannel()
            }
        }
    }

    // Default Built-in Live TV Test Streams (ALL strictly M3U_LIVE — never pollute Movies or Series!)
    private var allChannels: List<Channel> = listOf(
        Channel("1", 1, "Sports 18 HD (Test Stream)", "Sports", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8", sourceType = ContentSourceType.M3U_LIVE),
        Channel("2", 2, "Cinema Gold 24x7 HD (Live TV)", "Movies", "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8", sourceType = ContentSourceType.M3U_LIVE),
        Channel("3", 3, "Bharat News 24x7 HD", "News", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8", sourceType = ContentSourceType.M3U_LIVE),
        Channel("4", 4, "Music Beats Dolby HD", "Music", "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8", sourceType = ContentSourceType.M3U_LIVE)
    )
    private var allSequentialIndices: IntArray = IntArray(4) { it }
    private var channelsByCategory: Map<String, IntArray> = emptyMap()
    private var channelIndexById: Map<String, Int> = emptyMap()
    private var nonSequentialNumberMap: SparseIntArray = SparseIntArray(0)
    private var knownEpgAndChannelIds: Set<String> = emptySet()

    private var favoriteIds: MutableSet<String> = mutableSetOf("1")
    private var recentIds: MutableList<String> = mutableListOf()
    private var activeTab: String = "ALL"

    private var currentChannelIndex: Int = 0
    private var previousChannelIndex: Int = 0
    private var playbackRetryCount: Int = 0
    private var resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    )
    private var currentResizeIndex = 0
    private var sleepMinutes = 0
    private val sleepRunnable: Runnable = Runnable {
        exoPlayer?.pause()
        Toast.makeText(this, "Sleep Timer: Playback Paused", Toast.LENGTH_LONG).show()
    }

    // Direct O(1) Channel Number Entry with 0.75s (750ms) Auto-Tune Timer
    private var numberInputBuffer: String = ""
    private val numberJumpRunnable: Runnable = Runnable {
        val targetNum = numberInputBuffer.toIntOrNull()
        numberInputBuffer = ""
        if (targetNum != null) {
            val idx = findChannelIndexByNumberFast(targetNum)
            if (idx != -1) {
                switchChannel(idx, immediatePlayback = true)
            } else {
                Toast.makeText(this, "Channel #$targetNum not found", Toast.LENGTH_SHORT).show()
                updateOsdForCurrentChannel()
            }
        }
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics).toInt()

    private fun attach4dFocusMicroInteraction(view: View, focusedScale: Float = 1.035f) {
        view.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
            if (activePerformanceMode.reducedAnimations) {
                v.scaleX = if (hasFocus) 1.015f else 1.0f
                v.scaleY = if (hasFocus) 1.015f else 1.0f
            } else {
                val target = if (hasFocus) focusedScale else 1.0f
                v.animate()
                    .scaleX(target)
                    .scaleY(target)
                    .setDuration(105L)
                    .start()
            }
        }
    }

    private fun findChannelIndexByNumberFast(targetNum: Int): Int {
        val directIdx = targetNum - 1
        if (directIdx in allChannels.indices && allChannels[directIdx].number == targetNum) {
            return directIdx
        }
        val mapped = nonSequentialNumberMap.get(targetNum, -1)
        if (mapped != -1 && mapped in allChannels.indices) return mapped
        return allChannels.indexOfFirst { it.number == targetNum }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        processStartElapsedMs = SystemClock.elapsedRealtime()
        hasRenderedVideoFrame = false
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        dthBootOverlay = findViewById(R.id.dthBootOverlay)
        vSignalWaveOuter = findViewById(R.id.vSignalWaveOuter)
        vSignalWaveInner = findViewById(R.id.vSignalWaveInner)
        tvBootHeadline = findViewById(R.id.tvBootHeadline)
        tvBootStageStatus = findViewById(R.id.tvBootStageStatus)
        tvBootSubDetail = findViewById(R.id.tvBootSubDetail)
        bootProgressBar = findViewById(R.id.bootProgressBar)

        detectDeviceMemoryProfile()
        runCatching { Glide.get(this).setMemoryCategory(MemoryCategory.LOW) }

        startDthBootSignalAnimation()
        updateBootStage(8, "Starting StreamX v18.1 Next-Gen Ultra Extreme...", "Fast SXB2 Cache • 512MB Low-RAM Guard")

        findViewById<Button>(R.id.btnProfiles).setOnClickListener { showProfilesDialog() }
        playerView = findViewById(R.id.media3PlayerView)
        playerView.keepScreenOn = true
        playerView.subtitleView?.let { subView ->
            subView.setStyle(
                CaptionStyleCompat(
                    Color.WHITE,
                    Color.parseColor("#B8040B18"),
                    Color.TRANSPARENT,
                    CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW,
                    Color.parseColor("#FF0284C7"),
                    Typeface.DEFAULT_BOLD
                )
            )
            subView.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        }
        topControlBar = findViewById(R.id.topControlBar)
        leftChannelDrawer = findViewById(R.id.leftChannelDrawer)
        channelListRecycler = findViewById(R.id.channelListRecycler)
        tvEmptyDrawer = findViewById(R.id.tvEmptyDrawer)
        osdBanner = findViewById(R.id.zappingOsdContainer)
        tvChannelNumber = findViewById(R.id.tvChannelNumber)
        tvChannelName = findViewById(R.id.tvChannelName)
        tvChannelCategory = findViewById(R.id.tvChannelCategory)
        tvOsdStreamBadge = findViewById(R.id.tvOsdStreamBadge)
        tvEpgNow = findViewById(R.id.tvEpgNow)
        osdLiveProgressBar = findViewById(R.id.osdLiveProgressBar)
        tvActiveSectionBadge = findViewById(R.id.tvActiveSectionBadge)
        btnToggleFavorite = findViewById(R.id.btnToggleFavorite)
        btnRecallChannel = findViewById(R.id.btnRecallChannel)
        btnToggleDrawer = findViewById(R.id.btnToggleDrawer)
        btnSectionLiveTv = findViewById(R.id.btnSectionLiveTv)
        btnSectionMovies = findViewById(R.id.btnSectionMovies)
        btnSectionSeries = findViewById(R.id.btnSectionSeries)
        btnUnifiedSearch = findViewById(R.id.btnUnifiedSearch)
        tabAllChannels = findViewById(R.id.tabAllChannels)
        tabFavorites = findViewById(R.id.tabFavorites)
        tabRecent = findViewById(R.id.tabRecent)
        channelSearch = findViewById(R.id.channelSearch)
        categoryFilter = findViewById(R.id.categoryFilter)
        channelLogo = findViewById(R.id.channelLogo)

        // Bind v18.1 4D Movies & Series Hub views
        vodPosterGridPanel = findViewById(R.id.vodPosterGridPanel)
        tvVodLiveClockDate = findViewById(R.id.tvVodLiveClockDate)
        tvVodGridHeaderTitle = findViewById(R.id.tvVodGridHeaderTitle)
        btnVodContinueWatching = findViewById(R.id.btnVodContinueWatching)
        btnVodFavoritesFilter = findViewById(R.id.btnVodFavoritesFilter)
        btnVodSortOrder = findViewById(R.id.btnVodSortOrder)
        btnVodFetchProvider = findViewById(R.id.btnVodFetchProvider)
        btnCloseVodGrid = findViewById(R.id.btnCloseVodGrid)
        vodPosterSearch = findViewById(R.id.vodPosterSearch)
        vodCategorySpinner = findViewById(R.id.vodCategorySpinner)
        vodCategorySidebarRecycler = findViewById(R.id.vodCategorySidebarRecycler)
        tvVodEmptyState = findViewById(R.id.tvVodEmptyState)
        vodPosterRecycler = findViewById(R.id.vodPosterRecycler)

        // Live TV Channel Drawer Adapter — strictly switches Live TV channels
        channelAdapter = ChannelDrawerAdapter(
            channelProvider = { idx -> allChannels.getOrNull(idx) },
            isFavorite = { id -> favoriteIds.contains(id) },
            epgProvider = { ch -> lookupEpgForChannel(ch)?.first },
            logoOptions = logoRequestOptions,
            onChannelClick = { globalIdx ->
                activePlaybackMode = ActivePlaybackMode.LIVE_TV
                switchChannel(globalIdx, immediatePlayback = true)
            },
            onChannelFocused = { globalIdx ->
                val focusedCh = allChannels.getOrNull(globalIdx)
                if (focusedCh != null && focusedCh.streamUrl != currentPlayingStreamUrl) {
                    StreamPreFetcher.scheduleFocusPrefetch(
                        this@PlayerActivity,
                        focusedCh.streamUrl,
                        hlsChunklessFactory,
                        defaultMediaSourceFactory
                    )
                }
            }
        )
        val linearLm = LinearLayoutManager(this)
        channelListRecycler.layoutManager = linearLm
        channelListRecycler.setHasFixedSize(true)
        val cacheViews = if (isLowRamTvDevice) 5 else 8
        val poolViews = if (isLowRamTvDevice) 10 else 14
        channelListRecycler.setItemViewCacheSize(cacheViews)
        channelListRecycler.recycledViewPool.setMaxRecycledViews(0, poolViews)
        channelListRecycler.itemAnimator = null
        channelListRecycler.adapter = channelAdapter

        // Left VOD Category Sidebar Adapter (matches reference screenshots: FAVORITES, RECENTLY ADDED, CONTINUE WATCHING, BOLLYWOOD (297), etc.)
        vodSidebarAdapter = VodCategorySidebarAdapter(
            reducedAnimations = { activePerformanceMode.reducedAnimations },
            onCategorySelected = { catItem ->
                selectedVodCategory = catItem.categoryName
                vodSpecialFilterMode = when (catItem.categoryName) {
                    "CONTINUE WATCHING" -> "CONTINUE"
                    "FAVORITES / WATCHLIST" -> "FAV"
                    "RECENTLY ADDED" -> "RECENT_ADDED"
                    else -> "ALL"
                }
                vodSidebarAdapter.setSelectedCategory(catItem.categoryName)
                renderVodPosterGrid()
            }
        )
        vodCategorySidebarRecycler.layoutManager = LinearLayoutManager(this)
        vodCategorySidebarRecycler.setHasFixedSize(true)
        vodCategorySidebarRecycler.itemAnimator = null
        vodCategorySidebarRecycler.adapter = vodSidebarAdapter

        // Right 5-Column Responsive TV Poster Grid for Movies & Series (matches reference screenshots with left sidebar)
        val posterColumns = computeResponsivePosterSpanCount()
        val gridLm = GridLayoutManager(this, posterColumns)
        vodPosterRecycler.layoutManager = gridLm
        vodPosterRecycler.setHasFixedSize(true)
        vodPosterRecycler.setItemViewCacheSize(if (isLowRamTvDevice) 5 else 10)
        vodPosterRecycler.recycledViewPool.setMaxRecycledViews(0, if (isLowRamTvDevice) 10 else 16)
        vodPosterRecycler.itemAnimator = null
        posterGridAdapter = VodPosterGridAdapter(
            posterOptionsProvider = { currentPosterRequestOptions() },
            reducedAnimations = { activePerformanceMode.reducedAnimations },
            onPosterFocused = { pos -> lastFocusedPosterIndex = pos },
            onPosterClicked = { item ->
                if (item.seriesSummary != null) {
                    showSeriesDetailModal(item.seriesSummary)
                } else if (item.vodMovieIndex in vodMoviesCatalog.indices) {
                    showMovieDetailModal(item.vodMovieIndex)
                }
            }
        )
        vodPosterRecycler.adapter = posterGridAdapter

        channelListRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                runCatching {
                    if (newState == RecyclerView.SCROLL_STATE_SETTLING) {
                        Glide.with(this@PlayerActivity).pauseRequests()
                    } else {
                        Glide.with(this@PlayerActivity).resumeRequests()
                    }
                }
            }

            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                if (dy <= 0) return
                val totalLoadedInAdapter = channelAdapter.itemCount
                if (totalLoadedInAdapter < fullFilteredIndices.size) {
                    val lastVisible = linearLm.findLastVisibleItemPosition()
                    if (lastVisible >= totalLoadedInAdapter - 25) {
                        currentPagedLimit = (currentPagedLimit + pageStepSize).coerceAtMost(fullFilteredIndices.size)
                        channelAdapter.submitIndices(
                            fullFilteredIndices.copyOfRange(0, currentPagedLimit),
                            currentChannelIndex,
                            null
                        )
                    }
                }
            }
        })

        vodPosterRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                runCatching {
                    if (newState == RecyclerView.SCROLL_STATE_SETTLING) {
                        Glide.with(this@PlayerActivity).pauseRequests()
                    } else {
                        Glide.with(this@PlayerActivity).resumeRequests()
                    }
                }
            }
        })

        setupUiListeners()

        window.decorView.post {
            firstUiFrameMs = SystemClock.elapsedRealtime() - processStartElapsedMs
            startStagedBootSequence()
        }
    }

    private fun computeResponsivePosterSpanCount(): Int {
        val dm = resources.displayMetrics
        val screenWidthDp = (dm.widthPixels / dm.density).toInt()
        return when {
            screenWidthDp >= 900 -> 5 // 5 posters per row alongside the 248dp left category sidebar (matches reference screenshots!)
            screenWidthDp >= 720 -> 4
            else -> 3
        }
    }

    private fun updateVodHeaderClockText() {
        runCatching {
            val sdf = SimpleDateFormat("hh:mm:ss a • EEE, dd MMM yyyy", Locale.US)
            tvVodLiveClockDate.text = sdf.format(Date())
        }
    }

    private fun detectDeviceMemoryProfile() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        if (am != null) {
            val memInfo = ActivityManager.MemoryInfo()
            am.getMemoryInfo(memInfo)
            totalDeviceRamMb = (memInfo.totalMem / (1024L * 1024L)).coerceAtLeast(256L)
            isLowRamTvDevice = am.isLowRamDevice || totalDeviceRamMb <= 850L
        } else {
            isLowRamTvDevice = true
        }
        maxPlaylistLimit = 60_000
    }

    private fun startDthBootSignalAnimation() {
        val satellite = findViewById<View>(R.id.ivBootSatellite)
        satellite.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        satellitePulseAnimator = ObjectAnimator.ofPropertyValuesHolder(
            satellite,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 0.97f, 1.03f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.97f, 1.03f),
            PropertyValuesHolder.ofFloat(View.ALPHA, 0.88f, 1.0f)
        ).apply {
            duration = 2200L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }
        if (isLowRamTvDevice) return
        val scaleXOuter = PropertyValuesHolder.ofFloat(View.SCALE_X, 0.90f, 1.10f)
        val scaleYOuter = PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.90f, 1.10f)
        val alphaOuter = PropertyValuesHolder.ofFloat(View.ALPHA, 0.70f, 0.20f)
        outerWaveAnimator = ObjectAnimator.ofPropertyValuesHolder(
            vSignalWaveOuter,
            scaleXOuter,
            scaleYOuter,
            alphaOuter
        ).apply {
            duration = 1500L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
            start()
        }

        val alphaInner = PropertyValuesHolder.ofFloat(View.ALPHA, 0.40f, 0.85f)
        innerWaveAnimator = ObjectAnimator.ofPropertyValuesHolder(
            vSignalWaveInner,
            alphaInner
        ).apply {
            duration = 1100L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }
    }

    private fun cancelBootAnimators() {
        outerWaveAnimator?.cancel()
        innerWaveAnimator?.cancel()
        satellitePulseAnimator?.cancel()
        outerWaveAnimator = null
        innerWaveAnimator = null
        satellitePulseAnimator = null
    }

    private fun updateBootStage(progress: Int, stageText: String, subDetail: String? = null) {
        if (!isBootOverlayVisible) return
        bootProgressBar.progress = progress.coerceIn(0, 100)
        tvBootStageStatus.text = stageText
        if (subDetail != null) {
            tvBootSubDetail.text = subDetail
        }
    }

    private fun dismissDthBootOverlay(finalMessage: String = "READY TO WATCH") {
        if (!isBootOverlayVisible) return
        isBootOverlayVisible = false
        uiHandler.removeCallbacks(dismissBootSafetyRunnable)
        bootReadyElapsedMs = SystemClock.elapsedRealtime() - processStartElapsedMs
        bootProgressBar.progress = 100
        tvBootHeadline.text = finalMessage
        tvBootStageStatus.text = "StreamX v18.1 Next-Gen Ready • ${bootReadyElapsedMs}ms"
        cancelBootAnimators()
        dthBootOverlay.animate()
            .alpha(0f)
            .setDuration(150L)
            .withLayer()
            .withEndAction {
                dthBootOverlay.visibility = View.GONE
                dthBootOverlay.alpha = 1f
            }
            .start()
    }

    private fun isNetworkConnectedNow(): Boolean {
        val cm = connectivityManager ?: return true
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val net = cm.activeNetwork ?: return false
                val caps = cm.getNetworkCapabilities(net) ?: return false
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            } else {
                @Suppress("DEPRECATION")
                cm.activeNetworkInfo?.isConnected == true
            }
        } catch (_: Exception) {
            true
        }
    }

    private fun startStagedBootSequence() {
        uiHandler.postDelayed(dismissBootSafetyRunnable, 20_000L)
        uiHandler.postDelayed(heapGuardRunnable, 5000L)
        uiHandler.postDelayed(vodProgressTrackerRunnable, 4000L)

        lifecycleScope.launch {
            updateBootStage(
                20,
                "Loading saved settings...",
                "RAM Profile: ${totalDeviceRamMb}MB (${if (isLowRamTvDevice) "512MB Ultra Extreme" else "Standard"})"
            )
            val prefs = getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
            val bootSettings = withContext(Dispatchers.IO) {
                profileStore = ProfileStore(this@PlayerActivity)
                channelCache = ChannelCacheStore(this@PlayerActivity)
                epgCache = EpgCacheStore(this@PlayerActivity)

                val favs = prefs.getStringSet("fav_ids", null)?.toHashSet() ?: hashSetOf("1")
                val recents = prefs.getString("recent_ids", "")
                    ?.lines()
                    ?.filter { it.isNotBlank() }
                    ?.take(20) ?: emptyList()
                val themeIdx = prefs.getInt("theme_index", 0)
                val perfMode = profileStore.getPerformanceMode(isLowRamTvDevice)
                val bufId = prefs.getString("buffer_profile_id", null) ?: perfMode.recommendedBufferProfileId
                val autoBoot = prefs.getBoolean("auto_boot_enabled", true)
                val autoResume = prefs.getBoolean("auto_resume_enabled", true)
                val savedEpgUrl = prefs.getString("last_epg_url", "") ?: ""
                val cachedEpg = epgCache.loadEpg()

                BootSettingsBundle(
                    favs = favs,
                    recents = recents,
                    themeIndex = themeIdx,
                    performanceMode = perfMode,
                    bufferProfile = BufferProfile.fromId(bufId, isLowRamTvDevice),
                    autoBoot = autoBoot,
                    autoResume = autoResume,
                    savedEpgUrl = savedEpgUrl,
                    cachedEpg = cachedEpg
                )
            }

            favoriteIds.clear()
            favoriteIds.addAll(bootSettings.favs)
            recentIds.clear()
            recentIds.addAll(bootSettings.recents)
            activePerformanceMode = bootSettings.performanceMode
            StreamPreFetcher.setPerformanceMode(activePerformanceMode)
            activeBufferProfile = bootSettings.bufferProfile
            autoBootEnabled = bootSettings.autoBoot
            autoResumeEnabled = bootSettings.autoResume
            applyTheme(bootSettings.themeIndex)
            updateSectionButtonsUi(EntertainmentSection.LIVE_TV)

            if (bootSettings.cachedEpg != null) {
                epgMap = bootSettings.cachedEpg.entries
            }

            updateBootStage(
                45,
                "Initializing Direct-RAM Media Engine...",
                "Mode: ${activePerformanceMode.title} • ${activeBufferProfile.label}"
            )
            initializeMedia3ProEngine()
            rebuildChannelIndicesSync(allChannels)

            val hasNet = isNetworkConnectedNow()
            val epgUrlToRefresh = bootSettings.savedEpgUrl.ifBlank { bootSettings.cachedEpg?.sourceUrl.orEmpty() }
            if (hasNet && epgUrlToRefresh.isNotBlank()) {
                val epgAge = System.currentTimeMillis() - (bootSettings.cachedEpg?.timestampMs ?: 0L)
                if (epgAge > EpgCacheStore.EPG_REFRESH_INTERVAL_MS) {
                    loadXmltvEpg(epgUrlToRefresh, silentBackground = true)
                }
            }

            updateBootStage(65, "Restoring Channels from Fast SXB2 Cache...", "Instant Direct-RAM Boot")
            restoreSavedDataFromBoot(prefs, hasNet)
        }
    }

    private data class BootSettingsBundle(
        val favs: Set<String>,
        val recents: List<String>,
        val themeIndex: Int,
        val performanceMode: PerformanceMode,
        val bufferProfile: BufferProfile,
        val autoBoot: Boolean,
        val autoResume: Boolean,
        val savedEpgUrl: String,
        val cachedEpg: CachedEpgData?
    )

    private fun updateTabButton3dSelection(selectedTab: String) {
        val activeRes = themes[currentThemeIndex].activeRowDrawableRes
        tabAllChannels.isSelected = selectedTab == "ALL"
        tabFavorites.isSelected = selectedTab == "FAV"
        tabRecent.isSelected = selectedTab == "RECENT"
        tabAllChannels.setBackgroundResource(if (selectedTab == "ALL") activeRes else R.drawable.bg_btn_3d_slate)
        tabFavorites.setBackgroundResource(if (selectedTab == "FAV") R.drawable.bg_btn_3d_gold else R.drawable.bg_btn_3d_slate)
        tabRecent.setBackgroundResource(if (selectedTab == "RECENT") activeRes else R.drawable.bg_btn_3d_slate)
    }

    private fun updateSectionButtonsUi(section: EntertainmentSection) {
        activeEntertainmentSection = section
        btnSectionLiveTv.isSelected = section == EntertainmentSection.LIVE_TV
        btnSectionMovies.isSelected = section == EntertainmentSection.MOVIES
        btnSectionSeries.isSelected = section == EntertainmentSection.SERIES
        btnSectionLiveTv.setBackgroundResource(
            if (section == EntertainmentSection.LIVE_TV) R.drawable.bg_btn_3d_cyan else R.drawable.bg_btn_3d_slate
        )
        btnSectionMovies.setBackgroundResource(
            if (section == EntertainmentSection.MOVIES) R.drawable.bg_btn_3d_crimson else R.drawable.bg_btn_3d_slate
        )
        btnSectionSeries.setBackgroundResource(
            if (section == EntertainmentSection.SERIES) R.drawable.bg_btn_3d_purple else R.drawable.bg_btn_3d_slate
        )
    }

    private fun createGlassCategoryAdapter(categories: List<String>, prefixLabel: String = "Category"): ArrayAdapter<String> {
        return object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val tv = (convertView as? TextView) ?: TextView(this@PlayerActivity).apply {
                    setSingleLine(true)
                    ellipsize = TextUtils.TruncateAt.END
                    gravity = Gravity.CENTER_VERTICAL
                    textSize = 12f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(Color.parseColor("#E0F2FE"))
                    setPadding(dp(10), dp(6), dp(10), dp(6))
                    setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_3d_category, 0, 0, 0)
                    compoundDrawablePadding = dp(8)
                }
                val item = getItem(position) ?: "All categories"
                tv.text = "$prefixLabel: $item"
                return tv
            }

            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                val tv = (convertView as? TextView) ?: TextView(this@PlayerActivity).apply {
                    setSingleLine(true)
                    ellipsize = TextUtils.TruncateAt.END
                    gravity = Gravity.CENTER_VERTICAL
                    textSize = 13f
                    setTypeface(typeface, Typeface.BOLD)
                    setPadding(dp(14), dp(11), dp(14), dp(11))
                    setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_3d_category, 0, 0, 0)
                    compoundDrawablePadding = dp(10)
                }
                val item = getItem(position) ?: "All categories"
                val activeSel = if (prefixLabel == "Category") selectedCategory else selectedVodCategory
                val isSelected = item == activeSel
                tv.text = if (isSelected) "● $item  ✓" else item
                tv.setTextColor(if (isSelected) Color.parseColor("#38BDF8") else Color.parseColor("#F8FAFC"))
                tv.setBackgroundColor(if (isSelected) Color.parseColor("#FF0D213F") else Color.parseColor("#FF071022"))
                return tv
            }
        }
    }

    private fun setupUiListeners() {
        channelSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchQuery = s?.toString().orEmpty()
                renderDrawerList(debounceMs = 110L)
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        categoryFilter.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (suppressCategoryCallback) return
                selectedCategory = parent?.getItemAtPosition(position)?.toString() ?: "All categories"
                renderDrawerList()
            }
        }

        vodPosterSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                vodSearchQuery = s?.toString().orEmpty()
                renderVodPosterGrid(debounceMs = 110L)
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        vodCategorySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (suppressVodCategoryCallback) return
                val rawLabel = parent?.getItemAtPosition(position)?.toString() ?: "RECENTLY ADDED"
                val cleanCat = rawLabel.substringBeforeLast(" (").trim()
                selectedVodCategory = cleanCat
                vodSpecialFilterMode = when (cleanCat) {
                    "CONTINUE WATCHING" -> "CONTINUE"
                    "FAVORITES / WATCHLIST" -> "FAV"
                    "RECENTLY ADDED" -> "RECENT_ADDED"
                    else -> "ALL"
                }
                vodSidebarAdapter.setSelectedCategory(cleanCat)
                renderVodPosterGrid()
            }
        }

        btnToggleDrawer.setOnClickListener {
            if (leftChannelDrawer.visibility == View.VISIBLE) {
                closeDrawerAndRestoreFocus()
            } else {
                vodPosterGridPanel.visibility = View.GONE
                updateSectionButtonsUi(EntertainmentSection.LIVE_TV)
                openDrawerAndRequestFocus()
            }
        }

        // Primary Entertainment Section 1: LIVE TV
        btnSectionLiveTv.setOnClickListener {
            switchToEntertainmentSection(EntertainmentSection.LIVE_TV)
        }

        // Primary Entertainment Section 2: MOVIES (Left Category Sidebar + Poster Grid Hub)
        btnSectionMovies.setOnClickListener {
            switchToEntertainmentSection(EntertainmentSection.MOVIES)
        }

        // Primary Entertainment Section 3: SERIES (Left Category Sidebar + Poster Grid Hub)
        btnSectionSeries.setOnClickListener {
            switchToEntertainmentSection(EntertainmentSection.SERIES)
        }

        // Universal Smart Search Hub Button
        btnUnifiedSearch.setOnClickListener {
            showUnifiedSearchDialog()
        }

        btnVodContinueWatching.setOnClickListener {
            selectedVodCategory = "CONTINUE WATCHING"
            vodSpecialFilterMode = "CONTINUE"
            vodSidebarAdapter.setSelectedCategory("CONTINUE WATCHING")
            renderVodPosterGrid()
        }

        btnVodFavoritesFilter.setOnClickListener {
            selectedVodCategory = "FAVORITES / WATCHLIST"
            vodSpecialFilterMode = "FAV"
            vodSidebarAdapter.setSelectedCategory("FAVORITES / WATCHLIST")
            renderVodPosterGrid()
        }

        btnVodSortOrder.setOnClickListener {
            activeVodSortOrder = activeVodSortOrder.nextOrder()
            btnVodSortOrder.text = "↓ ${activeVodSortOrder.badgeLabel}"
            Toast.makeText(this, "Sort: ${activeVodSortOrder.fullTitle}", Toast.LENGTH_SHORT).show()
            renderVodPosterGrid()
        }

        btnVodFetchProvider.setOnClickListener {
            val creds = activeXtreamCreds
            if (activeSourceType == ProfileType.XTREAM && creds != null) {
                if (activeEntertainmentSection == EntertainmentSection.SERIES) {
                    loadXtreamSeriesCatalog(creds, forceNetworkRefresh = true)
                } else {
                    loadXtreamVodMovies(creds, forceNetworkRefresh = true)
                }
            } else {
                showXtreamLoginDialog()
            }
        }

        btnCloseVodGrid.setOnClickListener {
            closeVodGridAndReturnToLiveTv()
        }

        tabAllChannels.setOnClickListener {
            activeTab = "ALL"
            updateTabButton3dSelection("ALL")
            tvActiveSectionBadge.text = "StreamX v18.1 • All Live TV (${allChannels.size})"
            renderDrawerList()
        }
        tabFavorites.setOnClickListener {
            activeTab = "FAV"
            updateTabButton3dSelection("FAV")
            tvActiveSectionBadge.text = "StreamX v18.1 • ★ Favorites (${favoriteIds.size})"
            renderDrawerList()
        }
        tabRecent.setOnClickListener {
            activeTab = "RECENT"
            updateTabButton3dSelection("RECENT")
            tvActiveSectionBadge.text = "StreamX v18.1 • Recent Watched"
            renderDrawerList()
        }

        val btnProfiles = findViewById<Button>(R.id.btnProfiles)
        val btnXtream = findViewById<Button>(R.id.btnXtreamLogin)
        val btnM3u = findViewById<Button>(R.id.btnM3uLoad)
        val btnRefresh = findViewById<Button>(R.id.btnRefreshChannels)
        val btnAudio = findViewById<Button>(R.id.btnAudioQuality)
        val btnTheme = findViewById<Button>(R.id.btnThemeToggle)
        val btnEpg = findViewById<Button>(R.id.btnEpg)
        val btnSleep = findViewById<Button>(R.id.btnSleepTimer)
        val btnAspect = findViewById<Button>(R.id.btnAspectToggle)
        val btnZapUp = findViewById<Button>(R.id.btnZapUp)
        val btnZapDown = findViewById<Button>(R.id.btnZapDown)

        for (btn in listOf(
            btnToggleDrawer, btnSectionLiveTv, btnSectionMovies, btnSectionSeries, btnUnifiedSearch,
            btnProfiles, btnXtream, btnM3u, btnRefresh,
            btnAudio, btnTheme, btnEpg, btnSleep, btnAspect,
            tabAllChannels, tabFavorites, tabRecent,
            btnVodContinueWatching, btnVodFavoritesFilter, btnVodSortOrder, btnVodFetchProvider, btnCloseVodGrid,
            btnRecallChannel, btnToggleFavorite, btnZapDown, btnZapUp
        )) {
            attach4dFocusMicroInteraction(btn)
        }

        btnXtream.setOnClickListener { showXtreamLoginDialog() }
        btnM3u.setOnClickListener { showM3uLoadDialog() }
        btnRefresh.setOnClickListener { forceRefreshActivePlaylist() }
        btnAudio.setOnClickListener { showAudioAndQualityDialog() }
        btnTheme.setOnClickListener { showThemeAndPipDialog() }

        btnZapUp.setOnClickListener {
            if (activePlaybackMode != ActivePlaybackMode.LIVE_TV) {
                activePlaybackMode = ActivePlaybackMode.LIVE_TV
            }
            lastRemoteKeyPressElapsedMs = SystemClock.elapsedRealtime()
            lastZapForward = true
            switchChannel(currentChannelIndex + 1, immediatePlayback = true)
        }
        btnZapDown.setOnClickListener {
            if (activePlaybackMode != ActivePlaybackMode.LIVE_TV) {
                activePlaybackMode = ActivePlaybackMode.LIVE_TV
            }
            lastRemoteKeyPressElapsedMs = SystemClock.elapsedRealtime()
            lastZapForward = false
            switchChannel(currentChannelIndex - 1, immediatePlayback = true)
        }
        btnRecallChannel.setOnClickListener { recallPreviousChannel() }
        btnToggleFavorite.setOnClickListener { toggleCurrentChannelFavorite() }

        btnEpg.setOnClickListener { showEpgGuideHubDialog() }
        btnEpg.setOnLongClickListener { showEpgUrlDialog(); true }

        btnSleep.setOnLongClickListener { showEpgUrlDialog(); true }
        btnSleep.setOnClickListener {
            sleepMinutes = when (sleepMinutes) {
                0 -> 15
                15 -> 30
                30 -> 60
                60 -> 90
                else -> 0
            }
            uiHandler.removeCallbacks(sleepRunnable)
            if (sleepMinutes > 0) {
                uiHandler.postDelayed(sleepRunnable, sleepMinutes * 60 * 1000L)
                btnSleep.text = "Sleep: ${sleepMinutes}m"
                Toast.makeText(this, "Sleep Timer set for $sleepMinutes mins", Toast.LENGTH_SHORT).show()
            } else {
                btnSleep.text = "Sleep: OFF"
            }
        }

        btnAspect.setOnClickListener {
            currentResizeIndex = (currentResizeIndex + 1) % resizeModes.size
            playerView.resizeMode = resizeModes[currentResizeIndex]
            btnAspect.text = when (currentResizeIndex) {
                0 -> "16:9 Fit"
                1 -> "Full Stretch"
                else -> "Cinema Zoom"
            }
        }

        playerView.setOnClickListener {
            when {
                vodPosterGridPanel.visibility == View.VISIBLE -> closeVodGridAndReturnToLiveTv()
                leftChannelDrawer.visibility == View.VISIBLE -> closeDrawerAndRestoreFocus()
                else -> showZappingOsd()
            }
        }
    }

    // =========================================================================
    // v18.1 THREE PRIMARY ENTERTAINMENT SECTIONS: LIVE TV | MOVIES | SERIES
    // =========================================================================

    private fun switchToEntertainmentSection(section: EntertainmentSection) {
        updateSectionButtonsUi(section)
        when (section) {
            EntertainmentSection.LIVE_TV -> {
                vodPosterGridPanel.visibility = View.GONE
                if (activePlaybackMode != ActivePlaybackMode.LIVE_TV) {
                    activePlaybackMode = ActivePlaybackMode.LIVE_TV
                    startPlaybackForCurrentChannel(forceReload = true)
                }
                tvActiveSectionBadge.text = "StreamX v18.1 • LIVE TV (${allChannels.size})"
                openDrawerAndRequestFocus()
            }
            EntertainmentSection.MOVIES -> {
                leftChannelDrawer.visibility = View.GONE
                topControlBar.visibility = View.VISIBLE
                vodSpecialFilterMode = "RECENT_ADDED"
                selectedVodCategory = "RECENTLY ADDED"
                vodPosterSearch.setText("")
                vodSearchQuery = ""
                openVodPosterHub(EntertainmentSection.MOVIES)
            }
            EntertainmentSection.SERIES -> {
                leftChannelDrawer.visibility = View.GONE
                topControlBar.visibility = View.VISIBLE
                vodSpecialFilterMode = "RECENT_ADDED"
                selectedVodCategory = "RECENTLY ADDED"
                vodPosterSearch.setText("")
                vodSearchQuery = ""
                openVodPosterHub(EntertainmentSection.SERIES)
            }
        }
    }

    private fun openVodPosterHub(section: EntertainmentSection, restoreFocusIndex: Int = 0) {
        updateVodHeaderClockText()
        vodPosterGridPanel.alpha = 0f
        vodPosterGridPanel.visibility = View.VISIBLE
        vodPosterGridPanel.animate()
            .alpha(1f)
            .setDuration(if (activePerformanceMode.reducedAnimations) 60L else 130L)
            .withLayer()
            .start()

        val isMovies = section == EntertainmentSection.MOVIES
        tvVodGridHeaderTitle.setCompoundDrawablesWithIntrinsicBounds(
            if (isMovies) R.drawable.ic_3d_movies else R.drawable.ic_3d_series,
            0, 0, 0
        )

        val sidebarItems = buildVodSidebarCategories(section)
        vodSidebarAdapter.submitCategories(sidebarItems, selectedVodCategory)

        val spinnerLabels = sidebarItems.map { item ->
            if (item.isSpecialSection) item.categoryName else "${item.categoryName} (${item.count})"
        }
        suppressVodCategoryCallback = true
        vodCategorySpinner.adapter = createGlassCategoryAdapter(
            spinnerLabels,
            prefixLabel = if (isMovies) "Movies" else "Series"
        )
        val selPos = sidebarItems.indexOfFirst { it.categoryName == selectedVodCategory }.coerceAtLeast(0)
        vodCategorySpinner.setSelection(selPos, false)
        suppressVodCategoryCallback = false

        renderVodPosterGrid(requestFocusPosterIndex = restoreFocusIndex)

        // If connected to an Xtream account and the requested VOD catalog hasn't been fetched yet, fetch it now
        val creds = activeXtreamCreds
        if (activeSourceType == ProfileType.XTREAM && creds != null) {
            if (isMovies && vodMoviesCatalog.isEmpty()) {
                loadXtreamVodMovies(creds, forceNetworkRefresh = false)
            } else if (!isMovies && seriesCatalogGroups.isEmpty()) {
                loadXtreamSeriesCatalog(creds, forceNetworkRefresh = false)
            }
        }
    }

    private fun buildVodSidebarCategories(section: EntertainmentSection): List<VodCategorySidebarItem> {
        // Strict M3U rule: M3U-only accounts have NO VOD Movies or Series categories
        if (activeSourceType != ProfileType.XTREAM) {
            return listOf(
                VodCategorySidebarItem("FAVORITES / WATCHLIST", 0, isSpecialSection = true),
                VodCategorySidebarItem("RECENTLY ADDED", 0, isSpecialSection = true),
                VodCategorySidebarItem("CONTINUE WATCHING", 0, isSpecialSection = true)
            )
        }

        val continueEntries = if (::profileStore.isInitialized) {
            profileStore.getContinueWatchingEntries(activeAccountScope)
        } else emptyList()

        return if (section == EntertainmentSection.MOVIES) {
            val watchlistIds = if (::profileStore.isInitialized) {
                profileStore.getMovieWatchlistIds(activeAccountScope)
            } else emptySet()
            val favMovieCount = vodMoviesCatalog.count { watchlistIds.contains(it.id) || favoriteIds.contains(it.id) }
            val contMovieCount = continueEntries.count { it.contentType == ContentSourceType.XTREAM_VOD_MOVIE && vodMovieIndexById.containsKey(it.contentId) }
            val countByCat = LinkedHashMap<String, Int>(64)
            for (movie in vodMoviesCatalog) {
                if (movie.sourceType != ContentSourceType.XTREAM_VOD_MOVIE) continue
                val cat = movie.category.trim().ifBlank { "Movies" }
                countByCat[cat] = (countByCat[cat] ?: 0) + 1
            }
            val list = ArrayList<VodCategorySidebarItem>(countByCat.size + 4)
            list.add(VodCategorySidebarItem("FAVORITES / WATCHLIST", favMovieCount, isSpecialSection = true))
            list.add(VodCategorySidebarItem("RECENTLY ADDED", vodMoviesCatalog.size, isSpecialSection = true))
            list.add(VodCategorySidebarItem("CONTINUE WATCHING", contMovieCount, isSpecialSection = true))
            list.add(VodCategorySidebarItem("ALL MOVIES", vodMoviesCatalog.size, isSpecialSection = true))
            for ((catName, count) in countByCat) {
                list.add(VodCategorySidebarItem(catName, count, isSpecialSection = false))
            }
            list
        } else {
            val watchlistSeriesIds = if (::profileStore.isInitialized) {
                profileStore.getSeriesWatchlistIds(activeAccountScope)
            } else emptySet()
            val favSeriesCount = seriesCatalogGroups.count { grp ->
                watchlistSeriesIds.contains(grp.seriesKey) || watchlistSeriesIds.contains(grp.seriesId)
            }
            val activeSeriesKeys = continueEntries
                .filter { it.contentType == ContentSourceType.XTREAM_SERIES_EPISODE }
                .mapNotNull { it.seriesKey.takeIf { k -> k.isNotBlank() } }
                .toSet()
            val contSeriesCount = seriesCatalogGroups.count { it.seriesKey in activeSeriesKeys }
            val countByCat = LinkedHashMap<String, Int>(64)
            for (grp in seriesCatalogGroups) {
                val cat = grp.category.trim().ifBlank { "Series" }
                countByCat[cat] = (countByCat[cat] ?: 0) + 1
            }
            val list = ArrayList<VodCategorySidebarItem>(countByCat.size + 4)
            list.add(VodCategorySidebarItem("FAVORITES / WATCHLIST", favSeriesCount, isSpecialSection = true))
            list.add(VodCategorySidebarItem("RECENTLY ADDED", seriesCatalogGroups.size, isSpecialSection = true))
            list.add(VodCategorySidebarItem("CONTINUE WATCHING", contSeriesCount, isSpecialSection = true))
            list.add(VodCategorySidebarItem("ALL SERIES", seriesCatalogGroups.size, isSpecialSection = true))
            for ((catName, count) in countByCat) {
                list.add(VodCategorySidebarItem(catName, count, isSpecialSection = false))
            }
            list
        }
    }

    private fun renderVodPosterGrid(debounceMs: Long = 0L, requestFocusPosterIndex: Int = -1) {
        vodPosterFilterJob?.cancel()
        vodPosterFilterJob = lifecycleScope.launch {
            if (debounceMs > 0L) delay(debounceMs)
            val section = activeEntertainmentSection
            val isMovies = section == EntertainmentSection.MOVIES

            // Requirement 2A: M3U-only accounts MUST show a clean empty state in Movies and Series!
            if (activeSourceType != ProfileType.XTREAM) {
                val heading = if (isMovies) "No Movies Available" else "No Series Available"
                tvVodGridHeaderTitle.text = "$heading • M3U Live TV Active"
                tvVodEmptyState.text = "$heading\n\nMovies and Series are available when you connect an Xtream Codes account containing VOD content."
                tvVodEmptyState.visibility = View.VISIBLE
                vodPosterRecycler.visibility = View.GONE
                posterGridAdapter.submitItems(emptyList())
                return@launch
            }

            val query = vodSearchQuery.trim()
            val selectedCat = selectedVodCategory
            val specialMode = vodSpecialFilterMode
            val sortOrder = activeVodSortOrder
            val scope = activeAccountScope
            val continueEntries = if (::profileStore.isInitialized) {
                profileStore.getContinueWatchingEntries(scope)
            } else emptyList()
            val continueById = continueEntries.associateBy { it.contentId }
            val movieWatchlist = if (::profileStore.isInitialized) {
                profileStore.getMovieWatchlistIds(scope)
            } else emptySet()
            val seriesWatchlist = if (::profileStore.isInitialized) {
                profileStore.getSeriesWatchlistIds(scope)
            } else emptySet()
            val favSnapshot = HashSet(favoriteIds)

            val items = withContext(Dispatchers.Default) {
                val result = ArrayList<PosterCardBindItem>(256)
                if (isMovies) {
                    val baseIndices: List<Int> = when {
                        specialMode == "CONTINUE" || selectedCat == "CONTINUE WATCHING" -> {
                            continueEntries
                                .filter { it.contentType == ContentSourceType.XTREAM_VOD_MOVIE }
                                .mapNotNull { vodMovieIndexById[it.contentId] }
                        }
                        specialMode == "FAV" || selectedCat == "FAVORITES / WATCHLIST" -> {
                            vodMoviesCatalog.indices.filter { idx ->
                                val m = vodMoviesCatalog[idx]
                                movieWatchlist.contains(m.id) || favSnapshot.contains(m.id)
                            }
                        }
                        else -> vodMoviesCatalog.indices.toList()
                    }

                    val matchedMovies = ArrayList<Pair<Int, Channel>>(baseIndices.size.coerceAtMost(1200))
                    for (idx in baseIndices) {
                        val movie = vodMoviesCatalog.getOrNull(idx) ?: continue
                        if (movie.sourceType != ContentSourceType.XTREAM_VOD_MOVIE) continue
                        val catMatches = selectedCat in setOf(
                            "ALL MOVIES", "RECENTLY ADDED", "CONTINUE WATCHING", "FAVORITES / WATCHLIST"
                        ) || movie.category.equals(selectedCat, ignoreCase = true)
                        val queryMatches = query.isEmpty() ||
                            movie.name.contains(query, ignoreCase = true) ||
                            movie.category.contains(query, ignoreCase = true)
                        if (catMatches && queryMatches) {
                            matchedMovies.add(idx to movie)
                        }
                    }

                    val sortedMovies = when {
                        specialMode == "CONTINUE" || selectedCat == "CONTINUE WATCHING" -> matchedMovies
                        sortOrder == VodSortOrder.RECENTLY_ADDED || selectedCat == "RECENTLY ADDED" && sortOrder == VodSortOrder.RECENTLY_ADDED ->
                            matchedMovies.sortedByDescending { it.second.addedTimestamp }
                        sortOrder == VodSortOrder.NEW_TO_OLD ->
                            matchedMovies.sortedWith(
                                compareByDescending<Pair<Int, Channel>> { it.second.extractReleaseYear().toIntOrNull() ?: 0 }
                                    .thenByDescending { it.second.addedTimestamp }
                            )
                        sortOrder == VodSortOrder.OLD_TO_NEW ->
                            matchedMovies.sortedWith(
                                compareBy<Pair<Int, Channel>> { it.second.extractReleaseYear().toIntOrNull() ?: 9999 }
                                    .thenBy { it.second.addedTimestamp }
                            )
                        sortOrder == VodSortOrder.A_TO_Z ->
                            matchedMovies.sortedBy { it.second.cleanMovieDisplayTitle().lowercase(Locale.ROOT) }
                        sortOrder == VodSortOrder.Z_TO_A ->
                            matchedMovies.sortedByDescending { it.second.cleanMovieDisplayTitle().lowercase(Locale.ROOT) }
                        else -> matchedMovies
                    }

                    for ((idx, movie) in sortedMovies) {
                        val prog = continueById[movie.id]?.progressPercent() ?: 0
                        val year = movie.extractReleaseYear()
                        val qual = movie.extractQualityBadge()
                        val inWl = movieWatchlist.contains(movie.id) || favSnapshot.contains(movie.id)
                        result.add(
                            PosterCardBindItem(
                                key = movie.id,
                                title = movie.cleanMovieDisplayTitle(),
                                subtitle = if (year.isNotBlank()) "${movie.category} • $year" else movie.category,
                                posterUrl = movie.logoUrl,
                                yearBadge = year,
                                qualityBadge = qual,
                                progressPercent = prog,
                                isFavorite = inWl,
                                vodMovieIndex = idx,
                                seriesSummary = null
                            )
                        )
                        if (result.size >= 800) break
                    }
                } else {
                    val activeSeriesProgressByKey = continueEntries
                        .filter { it.contentType == ContentSourceType.XTREAM_SERIES_EPISODE && it.seriesKey.isNotBlank() }
                        .groupBy { it.seriesKey }
                    val sourceGroups: List<SeriesGroupSummary> = when {
                        specialMode == "CONTINUE" || selectedCat == "CONTINUE WATCHING" -> {
                            seriesCatalogGroups.filter { grp -> activeSeriesProgressByKey.containsKey(grp.seriesKey) }
                        }
                        specialMode == "FAV" || selectedCat == "FAVORITES / WATCHLIST" -> {
                            seriesCatalogGroups.filter { grp ->
                                seriesWatchlist.contains(grp.seriesKey) || seriesWatchlist.contains(grp.seriesId)
                            }
                        }
                        else -> seriesCatalogGroups
                    }

                    val matchedGroups = ArrayList<SeriesGroupSummary>(sourceGroups.size)
                    for (grp in sourceGroups) {
                        val catMatches = selectedCat in setOf(
                            "ALL SERIES", "RECENTLY ADDED", "CONTINUE WATCHING", "FAVORITES / WATCHLIST"
                        ) || grp.category.equals(selectedCat, ignoreCase = true)
                        val queryMatches = query.isEmpty() ||
                            grp.title.contains(query, ignoreCase = true) ||
                            grp.category.contains(query, ignoreCase = true)
                        if (catMatches && queryMatches) {
                            matchedGroups.add(grp)
                        }
                    }

                    val sortedGroups = when {
                        specialMode == "CONTINUE" || selectedCat == "CONTINUE WATCHING" -> matchedGroups
                        sortOrder == VodSortOrder.RECENTLY_ADDED ->
                            matchedGroups.sortedByDescending { it.addedTimestamp }
                        sortOrder == VodSortOrder.NEW_TO_OLD ->
                            matchedGroups.sortedWith(
                                compareByDescending<SeriesGroupSummary> { it.releaseYear.toIntOrNull() ?: 0 }
                                    .thenByDescending { it.addedTimestamp }
                            )
                        sortOrder == VodSortOrder.OLD_TO_NEW ->
                            matchedGroups.sortedWith(
                                compareBy<SeriesGroupSummary> { it.releaseYear.toIntOrNull() ?: 9999 }
                                    .thenBy { it.addedTimestamp }
                            )
                        sortOrder == VodSortOrder.A_TO_Z ->
                            matchedGroups.sortedBy { it.title.lowercase(Locale.ROOT) }
                        sortOrder == VodSortOrder.Z_TO_A ->
                            matchedGroups.sortedByDescending { it.title.lowercase(Locale.ROOT) }
                        else -> matchedGroups
                    }

                    for (grp in sortedGroups) {
                        val isFav = seriesWatchlist.contains(grp.seriesKey) || seriesWatchlist.contains(grp.seriesId)
                        val latestEpProg = activeSeriesProgressByKey[grp.seriesKey]
                            ?.maxByOrNull { it.updatedAtMs }
                            ?.progressPercent() ?: 0
                        result.add(
                            PosterCardBindItem(
                                key = "series_${grp.seriesKey}",
                                title = grp.title,
                                subtitle = if (grp.releaseYear.isNotBlank()) "${grp.category} • ${grp.releaseYear}" else grp.category,
                                posterUrl = grp.posterUrl,
                                yearBadge = grp.releaseYear,
                                qualityBadge = grp.qualityBadge.ifBlank { "SERIES" },
                                progressPercent = latestEpProg,
                                isFavorite = isFav,
                                vodMovieIndex = -1,
                                seriesSummary = grp
                            )
                        )
                        if (result.size >= 800) break
                    }
                }
                result
            }

            tvVodGridHeaderTitle.text = if (isMovies) {
                "$selectedVodCategory • MOVIES (${items.size})"
            } else {
                "$selectedVodCategory • SERIES (${items.size})"
            }
            tvActiveSectionBadge.text = if (isMovies) {
                "StreamX v18.1 • MOVIES (${vodMoviesCatalog.size})"
            } else {
                "StreamX v18.1 • SERIES (${seriesCatalogGroups.size})"
            }

            if (items.isEmpty()) {
                val emptyHeadline = if (isMovies) "No Movies Available" else "No Series Available"
                val emptyBody = when {
                    isMovies && vodMoviesCatalog.isEmpty() ->
                        "$emptyHeadline\n\nTap 'Sync VOD' to load Movies from your Xtream Codes account, or check if your provider includes VOD Movies."
                    !isMovies && seriesCatalogGroups.isEmpty() ->
                        "$emptyHeadline\n\nTap 'Sync VOD' to load Series from your Xtream Codes account, or check if your provider includes VOD Series."
                    else ->
                        "No entries found in '$selectedVodCategory'${if (query.isNotBlank()) " matching \"$query\"" else ""}."
                }
                tvVodEmptyState.text = emptyBody
                tvVodEmptyState.visibility = View.VISIBLE
                vodPosterRecycler.visibility = View.GONE
                posterGridAdapter.submitItems(emptyList())
            } else {
                tvVodEmptyState.visibility = View.GONE
                vodPosterRecycler.visibility = View.VISIBLE
                posterGridAdapter.submitItems(items)
                if (requestFocusPosterIndex >= 0) {
                    val targetPos = requestFocusPosterIndex.coerceIn(0, items.lastIndex)
                    vodPosterRecycler.post {
                        vodPosterRecycler.scrollToPosition(targetPos)
                        vodPosterRecycler.post {
                            vodPosterRecycler.findViewHolderForAdapterPosition(targetPos)?.itemView?.requestFocus()
                                ?: vodPosterRecycler.requestFocus()
                        }
                    }
                }
            }
        }
    }

    private fun closeVodGridAndReturnToLiveTv() {
        vodPosterGridPanel.visibility = View.GONE
        updateSectionButtonsUi(EntertainmentSection.LIVE_TV)
        tvActiveSectionBadge.text = "StreamX v18.1 • LIVE TV (${allChannels.size})"
        if (activePlaybackMode != ActivePlaybackMode.LIVE_TV) {
            activePlaybackMode = ActivePlaybackMode.LIVE_TV
            startPlaybackForCurrentChannel(forceReload = true)
        }
        playerView.requestFocus()
    }

    // =========================================================================
    // v18.1 PREMIUM MOVIE DETAILS SCREEN (Matches Reference Screenshot 25371.jpg:
    // Poster, Title (Year), Rating Stars, Release Date, Genre, Cast, Plot, Director,
    // TRAILER + PLAY Buttons, Resume Watching & Personal Watchlist)
    // =========================================================================

    private fun showMovieDetailModal(vodMovieIndex: Int, preloadedDetail: VodMovieDetailInfo? = null) {
        val movie = vodMoviesCatalog.getOrNull(vodMovieIndex) ?: return
        if (movie.sourceType != ContentSourceType.XTREAM_VOD_MOVIE) return

        activeVodMovieIndex = vodMovieIndex
        activeVodMovieItem = movie
        val creds = activeXtreamCreds

        // If `get_vod_info` metadata hasn't been fetched yet for this movie and we have Xtream credentials,
        // fetch real movie metadata (plot, cast, director, rating, genuine trailer URL) asynchronously
        if (preloadedDetail == null && creds != null) {
            lifecycleScope.launch {
                val infoRes = xtreamRepo.fetchVodMovieInfo(creds, movie)
                val resolvedDetail = infoRes.getOrElse {
                    VodMovieDetailInfo(
                        streamId = movie.id.removePrefix("vod_"),
                        title = movie.cleanMovieDisplayTitle(),
                        posterUrl = movie.logoUrl,
                        releaseDate = movie.releaseDate.ifBlank { movie.extractReleaseYear() },
                        rating = movie.rating,
                        genre = movie.category,
                        plot = movie.plot,
                        cast = movie.cast,
                        director = movie.director,
                        durationLabel = movie.durationLabel,
                        containerExtension = movie.containerExtension.ifBlank { "mp4" },
                        trailerUrl = movie.trailerUrl
                    )
                }
                activeVodMovieDetailInfo = resolvedDetail
                presentMovieDetailOverlayDialog(vodMovieIndex, movie, resolvedDetail)
            }
            return
        }

        val detail = preloadedDetail ?: VodMovieDetailInfo(
            streamId = movie.id.removePrefix("vod_"),
            title = movie.cleanMovieDisplayTitle(),
            posterUrl = movie.logoUrl,
            releaseDate = movie.releaseDate.ifBlank { movie.extractReleaseYear() },
            rating = movie.rating,
            genre = movie.category,
            plot = movie.plot,
            cast = movie.cast,
            director = movie.director,
            durationLabel = movie.durationLabel,
            containerExtension = movie.containerExtension.ifBlank { "mp4" },
            trailerUrl = movie.trailerUrl
        )
        activeVodMovieDetailInfo = detail
        presentMovieDetailOverlayDialog(vodMovieIndex, movie, detail)
    }

    private fun presentMovieDetailOverlayDialog(
        vodMovieIndex: Int,
        movie: Channel,
        detail: VodMovieDetailInfo
    ) {
        var dialogRef: AlertDialog? = null
        val savedProg = if (::profileStore.isInitialized) {
            profileStore.getPlaybackProgress(movie.id, activeAccountScope)
        } else null
        val isWatchlisted = if (::profileStore.isInitialized) {
            profileStore.isMovieInWatchlist(movie.id, activeAccountScope)
        } else false

        val rootCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_dialog_4d_glass)
            setPadding(dp(22), dp(18), dp(22), dp(18))
        }

        // Top Row: Left Movie Poster + Right Metadata Column (Matches Night Silence (2024) screenshot)
        val topContentRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val ivPoster = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundResource(R.drawable.bg_channel_logo_frame)
            setPadding(dp(4), dp(4), dp(4), dp(4))
            layoutParams = LinearLayout.LayoutParams(dp(145), dp(212)).apply {
                marginEnd = dp(18)
            }
        }
        if (detail.posterUrl.isNotBlank()) {
            Glide.with(this)
                .load(detail.posterUrl)
                .apply(currentPosterRequestOptions())
                .into(ivPoster)
        } else {
            ivPoster.scaleType = ImageView.ScaleType.FIT_CENTER
            ivPoster.setImageResource(R.drawable.ic_3d_movies)
        }
        topContentRow.addView(ivPoster)

        val metaCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        val yearStr = movie.extractReleaseYear().ifBlank {
            detail.releaseDate.take(4).takeIf { it.length == 4 && it.all { c -> c.isDigit() } }.orEmpty()
        }
        val displayHeadline = if (yearStr.isNotBlank() && !detail.title.contains("($yearStr)")) {
            "${detail.title} ($yearStr)"
        } else {
            detail.title
        }

        val tvTitle = TextView(this).apply {
            text = displayHeadline
            textSize = 21f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        metaCol.addView(tvTitle)

        if (detail.rating.isNotBlank()) {
            val tvRating = TextView(this).apply {
                text = "★★★★★ (${detail.rating})"
                textSize = 13f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#FBBF24"))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(4) }
            }
            metaCol.addView(tvRating)
        }

        val dateAndDuration = listOfNotNull(
            detail.releaseDate.takeIf { it.isNotBlank() },
            detail.durationLabel.takeIf { it.isNotBlank() },
            detail.containerExtension.uppercase(Locale.ROOT).takeIf { it.isNotBlank() }
        ).joinToString("  •  ")
        if (dateAndDuration.isNotBlank()) {
            val tvDate = TextView(this).apply {
                text = dateAndDuration
                textSize = 12f
                setTextColor(Color.parseColor("#38BDF8"))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(4) }
            }
            metaCol.addView(tvDate)
        }

        val tvGenre = TextView(this).apply {
            text = detail.genre.ifBlank { movie.category }
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#F8FAFC"))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) }
        }
        metaCol.addView(tvGenre)

        if (detail.cast.isNotBlank()) {
            val tvCast = TextView(this).apply {
                text = detail.cast
                textSize = 12f
                setTextColor(Color.parseColor("#86EFAC"))
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(5) }
            }
            metaCol.addView(tvCast)
        }

        if (detail.plot.isNotBlank()) {
            val tvPlot = TextView(this).apply {
                text = detail.plot
                textSize = 12.5f
                setTextColor(Color.parseColor("#E2E8F0"))
                maxLines = 4
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(7) }
            }
            metaCol.addView(tvPlot)
        }

        if (detail.director.isNotBlank()) {
            val tvDirector = TextView(this).apply {
                text = "Director: ${detail.director}"
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#93C5FD"))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(6) }
            }
            metaCol.addView(tvDirector)
        }

        topContentRow.addView(metaCol)
        rootCard.addView(topContentRow)

        // Primary Action Bar: TRAILER & PLAY MOVIE (Matches Night Silence screenshot + Resume/Watchlist options)
        val primaryButtonRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(18)
            }
        }

        val hasRealTrailer = detail.hasGenuineTrailer()
        val btnTrailer = Button(this).apply {
            text = if (hasRealTrailer) "🎬 TRAILER" else "TRAILER UNAVAILABLE"
            isAllCaps = false
            textSize = 13.5f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(if (hasRealTrailer) Color.WHITE else Color.parseColor("#94A3B8"))
            setBackgroundResource(if (hasRealTrailer) R.drawable.bg_btn_3d_slate else R.drawable.bg_dialog_item_4d)
            backgroundTintList = null
            isFocusable = true
            layoutParams = LinearLayout.LayoutParams(0, dp(46), 1f).apply {
                marginEnd = dp(10)
            }
            attach4dFocusMicroInteraction(this)
            setOnClickListener {
                if (!hasRealTrailer) {
                    Toast.makeText(
                        this@PlayerActivity,
                        "Trailer unavailable from provider for this movie",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    dialogRef?.dismiss()
                    launchGenuineMovieTrailer(detail)
                }
            }
        }

        val hasResumable = savedProg != null && savedProg.isResumable()
        val btnPlayMovie = Button(this).apply {
            text = if (hasResumable) {
                "▶ RESUME MOVIE (${savedProg!!.progressPercent()}%)"
            } else {
                "▶ PLAY MOVIE"
            }
            isAllCaps = false
            textSize = 13.5f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setBackgroundResource(R.drawable.bg_btn_3d_cyan)
            backgroundTintList = null
            isFocusable = true
            layoutParams = LinearLayout.LayoutParams(0, dp(46), 1f)
            attach4dFocusMicroInteraction(this)
            setOnClickListener {
                dialogRef?.dismiss()
                startFullScreenVodMoviePlayback(
                    vodIndex = vodMovieIndex,
                    movie = movie,
                    detail = detail,
                    resumePositionMs = if (hasResumable) savedProg!!.positionMs else 0L
                )
            }
        }

        primaryButtonRow.addView(btnTrailer)
        primaryButtonRow.addView(btnPlayMovie)
        rootCard.addView(primaryButtonRow)

        // Secondary Row: Start from Beginning (when resumable), Add/Remove Watchlist, Back
        val secondaryRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(10)
            }
        }

        if (hasResumable) {
            secondaryRow.addView(
                create4dActionCapsuleButton("⏮ Start from Beginning", R.drawable.bg_btn_3d_emerald, R.drawable.ic_3d_play) {
                    dialogRef?.dismiss()
                    profileStore.clearPlaybackProgress(movie.id, activeAccountScope)
                    startFullScreenVodMoviePlayback(
                        vodIndex = vodMovieIndex,
                        movie = movie,
                        detail = detail,
                        resumePositionMs = 0L
                    )
                }.apply { (layoutParams as LinearLayout.LayoutParams).marginStart = 0 }
            )
        }

        val btnWatchlist = create4dActionCapsuleButton(
            label = if (isWatchlisted) "★ In Watchlist (Remove)" else "☆ Add to Watchlist",
            bgRes = if (isWatchlisted) R.drawable.bg_btn_3d_gold else R.drawable.bg_btn_3d_purple,
            iconRes = R.drawable.ic_3d_star
        ) {
            val nowAdded = profileStore.toggleMovieWatchlist(movie.id, movie.sourceType, activeAccountScope)
            Toast.makeText(
                this,
                if (nowAdded) "★ Added '${detail.title}' to Movies Watchlist" else "Removed from Movies Watchlist",
                Toast.LENGTH_SHORT
            ).show()
            dialogRef?.dismiss()
            if (vodPosterGridPanel.visibility == View.VISIBLE) {
                val sidebarItems = buildVodSidebarCategories(EntertainmentSection.MOVIES)
                vodSidebarAdapter.submitCategories(sidebarItems, selectedVodCategory)
                renderVodPosterGrid()
            }
            presentMovieDetailOverlayDialog(vodMovieIndex, movie, detail)
        }
        secondaryRow.addView(btnWatchlist)

        secondaryRow.addView(
            create4dActionCapsuleButton("Back to Movies", R.drawable.bg_btn_3d_slate) {
                dialogRef?.dismiss()
            }
        )
        rootCard.addView(secondaryRow)

        dialogRef = present4dGlassDialog(rootCard, widthDp = 680)
        btnPlayMovie.post { btnPlayMovie.requestFocus() }
    }

    private fun launchGenuineMovieTrailer(detail: VodMovieDetailInfo) {
        val rawUrl = detail.trailerUrl.trim()
        if (rawUrl.isEmpty()) {
            Toast.makeText(this, "Trailer unavailable", Toast.LENGTH_SHORT).show()
            return
        }
        // If the trailer is a direct media stream (.mp4 / .m3u8 / .mkv), play it in Media3; if YouTube link, open intent safely
        val lower = rawUrl.lowercase(Locale.ROOT)
        if (lower.contains("youtube.com/") || lower.contains("youtu.be/")) {
            runCatching {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(rawUrl)))
            }.onFailure {
                Toast.makeText(this, "No YouTube app available to open trailer", Toast.LENGTH_LONG).show()
            }
            return
        }
        vodPosterGridPanel.visibility = View.GONE
        leftChannelDrawer.visibility = View.GONE
        activePlaybackMode = ActivePlaybackMode.VOD_TRAILER
        currentPlayingSeriesKey = ""
        currentPlayingSeasonNum = 0
        currentPlayingEpisodeNum = 0
        pendingResumeSeekPositionMs = 0L
        tvChannelNumber.text = "TRL"
        tvChannelName.text = "Trailer: ${detail.title}"
        tvChannelCategory.text = "${detail.genre} • Trailer"
        tvEpgNow.text = "Press BACK to return to ${detail.title} Details"
        playSpecificStreamUrl(rawUrl, forceReload = true)
        showZappingOsd()
    }

    private fun startFullScreenVodMoviePlayback(
        vodIndex: Int,
        movie: Channel,
        detail: VodMovieDetailInfo,
        resumePositionMs: Long
    ) {
        recordCurrentVodOrSeriesProgress()
        activeVodMovieIndex = vodIndex
        activeVodMovieItem = movie
        activeVodMovieDetailInfo = detail
        activePlaybackMode = ActivePlaybackMode.VOD_MOVIE
        currentPlayingSeriesKey = ""
        currentPlayingSeasonNum = 0
        currentPlayingEpisodeNum = 0
        pendingResumeSeekPositionMs = resumePositionMs

        vodPosterGridPanel.visibility = View.GONE
        leftChannelDrawer.visibility = View.GONE
        playbackRetryCount = 0
        stallRecoveryCount = 0
        usingBackupStream = false

        tvChannelNumber.text = "VOD"
        tvChannelName.text = detail.title
        tvChannelCategory.text = "${detail.genre.ifBlank { movie.category }} • ${detail.containerExtension.uppercase(Locale.ROOT)}"
        tvEpgNow.text = "Playing Movie • Press BACK for Movie Details"
        osdLiveProgressBar.progress = if (resumePositionMs > 0L) 50 else 100

        playSpecificStreamUrl(movie.streamUrl, forceReload = true)
        showZappingOsd()
    }

    // =========================================================================
    // v18.1 PREMIUM SERIES DETAILS, SEASON SELECTOR & EPISODE LIST
    // (Matches Reference Screenshot 25379.jpg: HURMAT (2026), Poster, Date, Genre,
    // Cast, Plot, Director, SEASON 1 Selector, EPISODE NO: 12 / SEASON: 1 Rows)
    // =========================================================================

    private fun showSeriesDetailModal(group: SeriesGroupSummary, selectedSeasonNumber: Int? = null) {
        val creds = activeXtreamCreds
        val cachedSeasons = loadedSeriesEpisodesCache[group.seriesKey]
        val resolvedGroup = if (group.seasons.isEmpty() && cachedSeasons != null) {
            group.copy(seasons = cachedSeasons)
        } else {
            group
        }

        // Fetch real seasons and episodes via `get_series_info` using the actual `series_id`
        if (resolvedGroup.seasons.isEmpty() && creds != null) {
            lifecycleScope.launch {
                Toast.makeText(this@PlayerActivity, "📺 Loading seasons & episodes for ${resolvedGroup.title}...", Toast.LENGTH_SHORT).show()
                val res = xtreamRepo.fetchSeriesEpisodes(
                    creds = creds,
                    seriesId = resolvedGroup.seriesId,
                    seriesTitle = resolvedGroup.title,
                    seriesCategory = resolvedGroup.category,
                    fallbackCover = resolvedGroup.posterUrl
                )
                res.onSuccess { fetchedEps ->
                    if (fetchedEps.isNotEmpty()) {
                        val seasonMap = LinkedHashMap<Int, List<SeriesEpisodeItem>>()
                        fetchedEps.groupBy { it.seasonNumber }.toSortedMap().forEach { (sNum, list) ->
                            seasonMap[sNum] = list.sortedBy { it.episodeNumber }
                        }
                        loadedSeriesEpisodesCache[resolvedGroup.seriesKey] = seasonMap
                        val enrichedGroup = resolvedGroup.copy(seasons = seasonMap)
                        activeSeriesGroup = enrichedGroup
                        presentSeriesDetailOverlayDialog(enrichedGroup, selectedSeasonNumber ?: seasonMap.keys.firstOrNull() ?: 1)
                    } else {
                        Toast.makeText(this@PlayerActivity, "No episodes available from provider for ${resolvedGroup.title}", Toast.LENGTH_LONG).show()
                    }
                }.onFailure { err ->
                    Toast.makeText(this@PlayerActivity, "Series info error: ${err.message}", Toast.LENGTH_LONG).show()
                }
            }
            return
        }

        activeSeriesGroup = resolvedGroup
        val firstSeason = selectedSeasonNumber ?: resolvedGroup.seasons.keys.sorted().firstOrNull() ?: 1
        presentSeriesDetailOverlayDialog(resolvedGroup, firstSeason)
    }

    private fun presentSeriesDetailOverlayDialog(
        group: SeriesGroupSummary,
        selectedSeasonNumber: Int
    ) {
        var dialogRef: AlertDialog? = null
        val availableSeasons = group.seasons.keys.sorted()
        val activeSeason = if (selectedSeasonNumber in group.seasons) {
            selectedSeasonNumber
        } else {
            availableSeasons.firstOrNull() ?: 1
        }
        activeSeriesSeasonNum = activeSeason
        val episodesInSeason = group.seasons[activeSeason].orEmpty()
        val allEpisodesFlat = availableSeasons.flatMap { group.seasons[it].orEmpty() }

        val continueEntries = if (::profileStore.isInitialized) {
            profileStore.getContinueWatchingEntries(activeAccountScope)
        } else emptyList()
        val continueById = continueEntries.associateBy { it.contentId }
        val isWatchlisted = if (::profileStore.isInitialized) {
            profileStore.isSeriesInWatchlist(group.seriesKey, activeAccountScope)
        } else false

        val lastWatchedEp = allEpisodesFlat
            .mapNotNull { ep -> continueById[ep.channel.id]?.let { ep to it } }
            .maxByOrNull { it.second.updatedAtMs }

        val rootCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_dialog_4d_glass)
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }

        // Top Metadata Header (Matches HURMAT (2026) screenshot: Poster on left, Title, Date, Genre, Cast, Plot, Director on right)
        val topHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val ivPoster = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundResource(R.drawable.bg_channel_logo_frame)
            setPadding(dp(4), dp(4), dp(4), dp(4))
            layoutParams = LinearLayout.LayoutParams(dp(118), dp(170)).apply {
                marginEnd = dp(16)
            }
        }
        if (group.posterUrl.isNotBlank()) {
            Glide.with(this)
                .load(group.posterUrl)
                .apply(currentPosterRequestOptions().placeholder(R.drawable.ic_3d_series).error(R.drawable.ic_3d_series))
                .into(ivPoster)
        } else {
            ivPoster.scaleType = ImageView.ScaleType.FIT_CENTER
            ivPoster.setImageResource(R.drawable.ic_3d_series)
        }
        topHeaderRow.addView(ivPoster)

        val metaCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        val tvTitle = TextView(this).apply {
            text = group.title
            textSize = 18.5f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        metaCol.addView(tvTitle)

        val dateAndSeasons = listOfNotNull(
            group.releaseDate.takeIf { it.isNotBlank() } ?: group.releaseYear.takeIf { it.isNotBlank() },
            "${group.seasonCount} Seasons • ${group.totalEpisodes} Episodes",
            group.rating.takeIf { it.isNotBlank() }?.let { "★ $it" }
        ).joinToString("  •  ")
        val tvDate = TextView(this).apply {
            text = dateAndSeasons
            textSize = 11.5f
            setTextColor(Color.parseColor("#38BDF8"))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(3) }
        }
        metaCol.addView(tvDate)

        val tvGenre = TextView(this).apply {
            text = group.genre.ifBlank { group.category }
            textSize = 12.5f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#86EFAC"))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(3) }
        }
        metaCol.addView(tvGenre)

        if (group.cast.isNotBlank()) {
            val tvCast = TextView(this).apply {
                text = group.cast
                textSize = 11.5f
                setTextColor(Color.parseColor("#38BDF8"))
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(3) }
            }
            metaCol.addView(tvCast)
        }

        if (group.plot.isNotBlank()) {
            val tvPlot = TextView(this).apply {
                text = group.plot
                textSize = 11.5f
                setTextColor(Color.parseColor("#E2E8F0"))
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(4) }
            }
            metaCol.addView(tvPlot)
        }

        if (group.director.isNotBlank()) {
            val tvDirector = TextView(this).apply {
                text = group.director
                textSize = 11f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#93C5FD"))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(3) }
            }
            metaCol.addView(tvDirector)
        }

        topHeaderRow.addView(metaCol)
        rootCard.addView(topHeaderRow)

        // Season Selector Pills + Watchlist & Resume Controls
        val seasonBarRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(10)
                bottomMargin = dp(8)
            }
        }

        for (sNum in availableSeasons.take(6)) {
            val isCurrentSeason = sNum == activeSeason
            val seasonBtn = Button(this).apply {
                text = "SEASON $sNum"
                isAllCaps = false
                textSize = 11.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.WHITE)
                setBackgroundResource(
                    if (isCurrentSeason) R.drawable.bg_btn_3d_cyan else R.drawable.bg_btn_3d_slate
                )
                backgroundTintList = null
                isFocusable = true
                setPadding(dp(14), dp(6), dp(14), dp(6))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    dp(36)
                ).apply { marginEnd = dp(6) }
                attach4dFocusMicroInteraction(this)
                setOnClickListener {
                    if (sNum != activeSeason) {
                        dialogRef?.dismiss()
                        presentSeriesDetailOverlayDialog(group, sNum)
                    }
                }
            }
            seasonBarRow.addView(seasonBtn)
        }

        if (lastWatchedEp != null) {
            val (epItem, progEntry) = lastWatchedEp
            val resumeBtn = create4dActionCapsuleButton(
                label = "▶ Resume S${epItem.seasonNumber}E${epItem.episodeNumber} (${progEntry.progressPercent()}%)",
                bgRes = R.drawable.bg_btn_3d_emerald
            ) {
                dialogRef?.dismiss()
                playSeriesEpisodeItem(group, epItem, resumePositionMs = progEntry.positionMs)
            }
            seasonBarRow.addView(resumeBtn)
        }

        val watchlistBtn = create4dActionCapsuleButton(
            label = if (isWatchlisted) "★ Watchlisted" else "☆ + Watchlist",
            bgRes = if (isWatchlisted) R.drawable.bg_btn_3d_gold else R.drawable.bg_btn_3d_purple
        ) {
            val added = profileStore.toggleSeriesWatchlist(group.seriesKey, ContentSourceType.XTREAM_SERIES, activeAccountScope)
            Toast.makeText(
                this,
                if (added) "★ Added '${group.title}' to Series Watchlist" else "Removed from Series Watchlist",
                Toast.LENGTH_SHORT
            ).show()
            dialogRef?.dismiss()
            if (vodPosterGridPanel.visibility == View.VISIBLE) {
                val sidebarItems = buildVodSidebarCategories(EntertainmentSection.SERIES)
                vodSidebarAdapter.submitCategories(sidebarItems, selectedVodCategory)
                renderVodPosterGrid()
            }
            presentSeriesDetailOverlayDialog(group, activeSeason)
        }
        seasonBarRow.addView(watchlistBtn)
        rootCard.addView(seasonBarRow)

        // Scrollable Episode Rows (Matches HURMAT (2026) - S01E12 / EPISODE NO: 12  SEASON: 1 layout)
        val maxScrollHeight = (resources.displayMetrics.heightPixels * 0.44f).toInt().coerceAtLeast(dp(150))
        val scroll = ScrollView(this).apply {
            isFillViewport = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        val epContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        var firstEpisodeFocusView: View? = null
        val targetEpisodeIdToFocus = activeSeriesEpisodeItem?.channel?.id

        for (ep in episodesInSeason) {
            val epProg = continueById[ep.channel.id]
            val isHighlighted = (targetEpisodeIdToFocus != null && ep.channel.id == targetEpisodeIdToFocus) || epProg != null

            val epRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isFocusable = true
                isClickable = true
                isSelected = isHighlighted
                setBackgroundResource(
                    if (isHighlighted) R.drawable.bg_btn_3d_cyan else R.drawable.bg_dialog_item_4d
                )
                setPadding(dp(14), dp(10), dp(14), dp(10))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(6) }
                attach4dFocusMicroInteraction(this, focusedScale = 1.015f)
                setOnClickListener {
                    dialogRef?.dismiss()
                    if (epProg != null && epProg.isResumable()) {
                        showEpisodeResumeOrRestartChoice(group, ep, epProg)
                    } else {
                        playSeriesEpisodeItem(group, ep, resumePositionMs = 0L)
                    }
                }
            }

            val textCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }

            val sPad = ep.seasonNumber.toString().padStart(2, '0')
            val ePad = ep.episodeNumber.toString().padStart(2, '0')
            val formattedHeadline = if (ep.episodeTitle.contains("S$sPad", ignoreCase = true)) {
                ep.episodeTitle
            } else {
                "${group.title} - S${sPad}E${ePad} • ${ep.episodeTitle}"
            }

            val tvEpTitle = TextView(this).apply {
                text = formattedHeadline
                textSize = 13.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.WHITE)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            val durPart = if (ep.durationLabel.isNotBlank()) "   DURATION: ${ep.durationLabel}" else ""
            val progPart = if (epProg != null) "   •   RESUME ${epProg.progressPercent()}%" else ""
            val tvEpSub = TextView(this).apply {
                text = "EPISODE NO: ${ep.episodeNumber}     SEASON: ${ep.seasonNumber}$durPart$progPart"
                textSize = 11.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#FBBF24"))
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(2) }
            }
            textCol.addView(tvEpTitle)
            textCol.addView(tvEpSub)
            epRow.addView(textCol)

            val tvPlayBadge = TextView(this).apply {
                text = if (epProg != null) "▶ ${epProg.progressPercent()}%" else "▶ PLAY"
                textSize = 10.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#6EE7B7"))
                setBackgroundResource(R.drawable.bg_live_dot_pill)
                setPadding(dp(10), dp(4), dp(10), dp(4))
            }
            epRow.addView(tvPlayBadge)

            if (firstEpisodeFocusView == null || (targetEpisodeIdToFocus != null && ep.channel.id == targetEpisodeIdToFocus)) {
                firstEpisodeFocusView = epRow
            }
            epContainer.addView(epRow)
        }

        scroll.addView(epContainer)
        rootCard.addView(scroll)

        scroll.post {
            if (scroll.height > maxScrollHeight) {
                scroll.layoutParams = (scroll.layoutParams as LinearLayout.LayoutParams).apply {
                    height = maxScrollHeight
                }
            }
        }

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) }
        }
        footer.addView(
            create4dActionCapsuleButton("Back to Series Library", R.drawable.bg_btn_3d_slate) {
                dialogRef?.dismiss()
            }
        )
        rootCard.addView(footer)

        dialogRef = present4dGlassDialog(rootCard, widthDp = 700)
        firstEpisodeFocusView?.post { firstEpisodeFocusView?.requestFocus() }
    }

    private fun showEpisodeResumeOrRestartChoice(
        group: SeriesGroupSummary,
        ep: SeriesEpisodeItem,
        progEntry: PlaybackProgressEntry
    ) {
        val mins = (progEntry.positionMs / 60_000L).coerceAtLeast(1L)
        val options = listOf(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_play,
                title = "▶ Resume Episode ($mins min • ${progEntry.progressPercent()}%)",
                subtitle = "Continue watching ${ep.episodeTitle} from saved position",
                badgeText = "RESUME ${progEntry.progressPercent()}%",
                isHighlighted = true
            ) {
                playSeriesEpisodeItem(group, ep, resumePositionMs = progEntry.positionMs)
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_play,
                title = "⏮ Start Episode from Beginning",
                subtitle = "Play Season ${ep.seasonNumber}, Episode ${ep.episodeNumber} from 00:00",
                badgeText = "RESTART"
            ) {
                profileStore.clearPlaybackProgress(ep.channel.id, activeAccountScope)
                playSeriesEpisodeItem(group, ep, resumePositionMs = 0L)
            }
        )
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_series,
            title = ep.episodeTitle,
            subtitle = "${group.title} • Season ${ep.seasonNumber}, Episode ${ep.episodeNumber}",
            badgeText = "CONTINUE",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun playSeriesEpisodeItem(group: SeriesGroupSummary, ep: SeriesEpisodeItem, resumePositionMs: Long) {
        recordCurrentVodOrSeriesProgress()
        vodPosterGridPanel.visibility = View.GONE
        leftChannelDrawer.visibility = View.GONE
        activePlaybackMode = ActivePlaybackMode.SERIES_EPISODE
        activeSeriesGroup = group
        activeSeriesSeasonNum = ep.seasonNumber
        activeSeriesEpisodeItem = ep
        currentPlayingSeriesKey = group.seriesKey
        currentPlayingSeasonNum = ep.seasonNumber
        currentPlayingEpisodeNum = ep.episodeNumber
        pendingResumeSeekPositionMs = resumePositionMs
        autoNextPromptShownForEpisodeId = ""
        playbackRetryCount = 0
        stallRecoveryCount = 0
        usingBackupStream = false

        val sPad = ep.seasonNumber.toString().padStart(2, '0')
        val ePad = ep.episodeNumber.toString().padStart(2, '0')
        tvChannelNumber.text = "S${sPad}E${ePad}"
        tvChannelName.text = "${group.title} • ${ep.episodeTitle}"
        tvChannelCategory.text = "${group.category} • Season ${ep.seasonNumber}"
        tvEpgNow.text = "Episode ${ep.episodeNumber} • Press BACK for Episode List"
        osdLiveProgressBar.progress = if (resumePositionMs > 0L) 50 else 100

        playSpecificStreamUrl(ep.channel.streamUrl, forceReload = true)
        showZappingOsd()
    }

    // =========================================================================
    // v18.1 SMART AUTO NEXT EPISODE WITH VISIBLE COUNTDOWN & CANCEL OPTION
    // (Requirement 17D: Identifies actual next episode in the same Series, shows
    // countdown near end or at completion, allows Cancel or Play Immediately)
    // =========================================================================

    private fun checkSmartAutoNextEpisodeNearEnd() {
        if (activePlaybackMode != ActivePlaybackMode.SERIES_EPISODE) return
        if (!::profileStore.isInitialized || !profileStore.isAutoNextEpisodeEnabled()) return
        val player = exoPlayer ?: return
        if (!player.isPlaying) return
        val group = activeSeriesGroup ?: return
        val curEp = activeSeriesEpisodeItem ?: return
        if (autoNextPromptShownForEpisodeId == curEp.channel.id) return

        val dur = player.duration
        val pos = player.currentPosition
        if (dur > 60_000L && pos > 0L && (dur - pos) in 1_000L..22_000L) {
            val nextEp = MediaCatalogEngine.findNextEpisodeInSeries(
                group = group,
                currentSeason = curEp.seasonNumber,
                currentEpisodeNumber = curEp.episodeNumber,
                currentEpisodeId = curEp.channel.id
            )
            if (nextEp != null) {
                autoNextPromptShownForEpisodeId = curEp.channel.id
                showAutoNextEpisodeCountdownModal(group, nextEp)
            }
        }
    }

    private fun showAutoNextEpisodeCountdownModal(group: SeriesGroupSummary, nextEp: SeriesEpisodeItem) {
        autoNextCountdownJob?.cancel()
        autoNextCountdownDialog?.dismiss()

        val sPad = nextEp.seasonNumber.toString().padStart(2, '0')
        val ePad = nextEp.episodeNumber.toString().padStart(2, '0')

        val rootCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_dialog_4d_glass)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }

        val tvCountdownBadge = TextView(this).apply {
            text = "NEXT EPISODE IN 8s"
            textSize = 11f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#38BDF8"))
            setBackgroundResource(R.drawable.bg_badge_neon)
            setPadding(dp(10), dp(5), dp(10), dp(5))
        }

        val headerRow = build4dModalHeader(
            iconRes = R.drawable.ic_3d_series,
            title = "Up Next: S${sPad}E${ePad} • ${nextEp.episodeTitle}",
            subtitle = "${group.title} • Season ${nextEp.seasonNumber}, Episode ${nextEp.episodeNumber}",
            badgeText = ""
        )
        headerRow.addView(tvCountdownBadge)
        rootCard.addView(headerRow)

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(14) }
        }

        val btnCancel = create4dActionCapsuleButton("Cancel Auto-Play", R.drawable.bg_btn_3d_slate) {
            autoNextCountdownJob?.cancel()
            autoNextCountdownDialog?.dismiss()
            Toast.makeText(this, "Auto Next Episode cancelled for this episode", Toast.LENGTH_SHORT).show()
        }

        val btnPlayNow = create4dActionCapsuleButton(
            "⏭ Play Next Episode Now",
            R.drawable.bg_btn_3d_cyan,
            R.drawable.ic_3d_play
        ) {
            autoNextCountdownJob?.cancel()
            autoNextCountdownDialog?.dismiss()
            playSeriesEpisodeItem(group, nextEp, resumePositionMs = 0L)
        }

        btnRow.addView(btnCancel)
        btnRow.addView(btnPlayNow)
        rootCard.addView(btnRow)

        val dlg = present4dGlassDialog(rootCard, widthDp = 540)
        autoNextCountdownDialog = dlg
        btnPlayNow.post { btnPlayNow.requestFocus() }

        autoNextCountdownJob = lifecycleScope.launch {
            for (remaining in 8 downTo 1) {
                if (!dlg.isShowing) return@launch
                tvCountdownBadge.text = "NEXT EPISODE IN ${remaining}s"
                delay(1000L)
            }
            if (dlg.isShowing) {
                dlg.dismiss()
                playSeriesEpisodeItem(group, nextEp, resumePositionMs = 0L)
            }
        }
    }

    private fun recordCurrentVodOrSeriesProgress() {
        if (!::profileStore.isInitialized) return
        val player = exoPlayer ?: return
        val pos = player.currentPosition
        val dur = player.duration.takeIf { it > 0L && it != C.TIME_UNSET } ?: 0L
        if (pos < 10_000L) return

        when (activePlaybackMode) {
            ActivePlaybackMode.VOD_MOVIE -> {
                val movie = activeVodMovieItem ?: return
                if (movie.sourceType == ContentSourceType.XTREAM_VOD_MOVIE) {
                    profileStore.savePlaybackProgress(
                        contentId = movie.id,
                        positionMs = pos,
                        durationMs = dur,
                        seriesKey = "",
                        seasonNumber = 0,
                        episodeNumber = 0,
                        contentType = ContentSourceType.XTREAM_VOD_MOVIE,
                        accountScope = activeAccountScope
                    )
                }
            }
            ActivePlaybackMode.SERIES_EPISODE -> {
                val ep = activeSeriesEpisodeItem ?: return
                val grp = activeSeriesGroup ?: return
                profileStore.savePlaybackProgress(
                    contentId = ep.channel.id,
                    positionMs = pos,
                    durationMs = dur,
                    seriesKey = grp.seriesKey,
                    seasonNumber = ep.seasonNumber,
                    episodeNumber = ep.episodeNumber,
                    contentType = ContentSourceType.XTREAM_SERIES_EPISODE,
                    accountScope = activeAccountScope
                )
            }
            ActivePlaybackMode.LIVE_TV, ActivePlaybackMode.VOD_TRAILER -> {
                // Live TV channels and trailers NEVER enter VOD/Series Continue Watching!
            }
        }
    }

    // =========================================================================
    // v18.1 UNIVERSAL SMART SEARCH WITH STRICT CONTENT SEPARATION
    // (Requirement 17B: Searches Live TV, Movies, and Series independently,
    // displays clear content-type labels, and never shows Movies/Series for M3U accounts)
    // =========================================================================

    private fun showUnifiedSearchDialog(initialQuery: String = "") {
        val history = if (::profileStore.isInitialized) profileStore.getSearchHistory() else emptyList()
        val isXtream = activeSourceType == ProfileType.XTREAM
        val scopeSummary = if (isXtream) {
            "${allChannels.size} Live TV • ${vodMoviesCatalog.size} Movies • ${seriesCatalogGroups.size} Series"
        } else {
            "${allChannels.size} Live TV Channels (M3U Mode)"
        }
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_search,
            title = "Universal Smart Search (Strict Catalog Separation)",
            subtitle = if (history.isNotEmpty()) {
                "Recent searches: ${history.take(5).joinToString(" • ")}  |  $scopeSummary"
            } else {
                "Search across $scopeSummary"
            },
            badgeText = if (isXtream) "LIVE • VOD • SERIES" else "LIVE TV ONLY",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "SEARCH QUERY",
                    hint = if (isXtream) "Search Live TV channels, VOD Movies, or Series..." else "Search Live TV channels or categories...",
                    iconRes = R.drawable.ic_3d_search,
                    initialValue = initialQuery,
                    inputType = InputType.TYPE_CLASS_TEXT
                )
            ),
            neutralLabel = if (history.isNotEmpty()) "Clear History" else null,
            neutralBgRes = R.drawable.bg_btn_3d_crimson,
            neutralIconRes = R.drawable.ic_3d_trash,
            onNeutral = if (history.isNotEmpty()) {
                {
                    profileStore.clearSearchHistory()
                    Toast.makeText(this, "Search history cleared", Toast.LENGTH_SHORT).show()
                }
            } else null,
            positiveLabel = "Search Catalogs",
            positiveBgRes = R.drawable.bg_btn_3d_cyan,
            positiveIconRes = R.drawable.ic_3d_search
        ) { values ->
            val q = ProfileStore.sanitizeExternalInput(values.firstOrNull().orEmpty())
            if (q.isNotBlank()) {
                profileStore.addSearchHistoryQuery(q)
                showUnifiedSearchResultsModal(q)
            }
        }
    }

    private fun showUnifiedSearchResultsModal(query: String) {
        lifecycleScope.launch {
            val qTrim = query.trim()
            val isXtream = activeSourceType == ProfileType.XTREAM

            val matchedOptions = withContext(Dispatchers.Default) {
                val results = ArrayList<GlassModalOption>(90)

                // 1. Search Live TV Catalog (`allChannels` — strictly Live TV)
                var liveCount = 0
                for (i in allChannels.indices) {
                    val ch = allChannels[i]
                    if (!ch.isLiveTvChannel()) continue
                    val matches = ch.name.contains(qTrim, ignoreCase = true) ||
                        ch.category.contains(qTrim, ignoreCase = true) ||
                        ch.number.toString() == qTrim
                    if (!matches) continue
                    val epgNow = lookupEpgForChannel(ch)?.first
                    val sub = buildString {
                        append("Live TV • ").append(ch.category)
                        if (!epgNow.isNullOrBlank()) append(" • Now: ").append(epgNow)
                    }
                    val targetIdx = i
                    results.add(
                        GlassModalOption(
                            iconRes = R.drawable.ic_3d_live_tv,
                            title = "[LIVE TV] ${ch.displayNumberFormatted()} • ${ch.name}",
                            subtitle = sub,
                            badgeText = "LIVE TV",
                            isHighlighted = activePlaybackMode == ActivePlaybackMode.LIVE_TV && targetIdx == currentChannelIndex
                        ) {
                            vodPosterGridPanel.visibility = View.GONE
                            activePlaybackMode = ActivePlaybackMode.LIVE_TV
                            switchChannel(targetIdx, immediatePlayback = true)
                        }
                    )
                    liveCount++
                    if (liveCount >= 35) break
                }

                // 2. Search VOD Movies Catalog (ONLY when connected to an Xtream account!)
                if (isXtream) {
                    var movieCount = 0
                    for (idx in vodMoviesCatalog.indices) {
                        val movie = vodMoviesCatalog[idx]
                        if (movie.sourceType != ContentSourceType.XTREAM_VOD_MOVIE) continue
                        val matches = movie.name.contains(qTrim, ignoreCase = true) ||
                            movie.category.contains(qTrim, ignoreCase = true)
                        if (!matches) continue
                        val targetMovieIdx = idx
                        val year = movie.extractReleaseYear()
                        results.add(
                            GlassModalOption(
                                iconRes = R.drawable.ic_3d_movies,
                                title = "[MOVIE] ${movie.cleanMovieDisplayTitle()}",
                                subtitle = "VOD Movie • ${movie.category}${if (year.isNotBlank()) " • $year" else ""}",
                                badgeText = "VOD MOVIE"
                            ) {
                                showMovieDetailModal(targetMovieIdx)
                            }
                        )
                        movieCount++
                        if (movieCount >= 35) break
                    }

                    // 3. Search Series Catalog (ONLY when connected to an Xtream account!)
                    var seriesCount = 0
                    for (grp in seriesCatalogGroups) {
                        val matches = grp.title.contains(qTrim, ignoreCase = true) ||
                            grp.category.contains(qTrim, ignoreCase = true)
                        if (!matches) continue
                        results.add(
                            GlassModalOption(
                                iconRes = R.drawable.ic_3d_series,
                                title = "[SERIES] ${grp.title}",
                                subtitle = "VOD Series • ${grp.category}${if (grp.releaseYear.isNotBlank()) " • ${grp.releaseYear}" else ""}",
                                badgeText = "SERIES"
                            ) {
                                showSeriesDetailModal(grp)
                            }
                        )
                        seriesCount++
                        if (seriesCount >= 25) break
                    }
                }
                results
            }

            if (matchedOptions.isEmpty()) {
                Toast.makeText(this@PlayerActivity, "No matches found for '$qTrim'", Toast.LENGTH_LONG).show()
            } else {
                show4dGlassListModal(
                    headerIconRes = R.drawable.ic_3d_search,
                    title = "Search Results for \"$qTrim\"",
                    subtitle = if (isXtream) {
                        "Separated results across Live TV, VOD Movies & Series (${matchedOptions.size} matches)"
                    } else {
                        "Live TV results for M3U playlist (${matchedOptions.size} matches)"
                    },
                    badgeText = "${matchedOptions.size} FOUND",
                    options = matchedOptions,
                    closeLabel = "Close"
                )
            }
        }
    }

    private fun openDrawerAndRequestFocus() {
        leftChannelDrawer.alpha = 0f
        leftChannelDrawer.visibility = View.VISIBLE
        leftChannelDrawer.animate()
            .alpha(1f)
            .setDuration(if (activePerformanceMode.reducedAnimations) 60L else 130L)
            .withLayer()
            .start()
        topControlBar.visibility = View.VISIBLE
        renderDrawerList(scrollToActive = true, requestFocusOnActive = true)
    }

    private fun closeDrawerAndRestoreFocus() {
        leftChannelDrawer.visibility = View.GONE
        playerView.requestFocus()
    }

    private fun cacheKeyFor(raw: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray(Charsets.UTF_8))
        return bytes.take(12).joinToString("") { "%02x".format(it) }
    }

    /**
     * Rebuilds Live TV indices strictly from Live TV channels.
     * Never populates Movies or Series from `allChannels`!
     */
    private fun rebuildChannelIndicesSync(channels: List<Channel>) {
        val seq = IntArray(channels.size) { it }
        val byId = HashMap<String, Int>(channels.size)
        val nonSeqNum = SparseIntArray()
        val byCatTemp = HashMap<String, ArrayList<Int>>(32)
        val epgIds = HashSet<String>(channels.size * 2)

        for (i in channels.indices) {
            val ch = channels[i]
            if (!byId.containsKey(ch.id)) byId[ch.id] = i
            if (ch.number != i + 1 && nonSeqNum.indexOfKey(ch.number) < 0) {
                nonSeqNum.put(ch.number, i)
            }
            byCatTemp.getOrPut(ch.category.lowercase(Locale.ROOT)) { ArrayList() }.add(i)
            epgIds.add(ch.id)
            if (ch.epgId.isNotEmpty()) epgIds.add(ch.epgId)
        }
        val byCatPrimitive = HashMap<String, IntArray>(byCatTemp.size)
        for ((k, list) in byCatTemp) {
            byCatPrimitive[k] = list.toIntArray()
        }
        allSequentialIndices = seq
        channelIndexById = byId
        nonSequentialNumberMap = nonSeqNum
        channelsByCategory = byCatPrimitive
        knownEpgAndChannelIds = epgIds
    }

    private suspend fun applyLoadedChannels(
        newChannels: List<Channel>,
        sectionTitle: String? = null,
        resumeLastWatched: Boolean = true,
        isPreliminaryBatch: Boolean = false
    ) {
        // Ensure only Live TV channels enter `allChannels`
        val liveOnlyChannels = newChannels.filter { it.sourceType.isLiveTv() }
        if (liveOnlyChannels.isEmpty() && newChannels.isNotEmpty()) return

        val prefs = getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
        val shouldResume = resumeLastWatched && autoResumeEnabled
        val savedLastId = if (shouldResume) prefs.getString("last_channel_id", null) else null
        val savedLastIndex = if (shouldResume) prefs.getInt("last_channel_index", 0) else 0

        if (!isPreliminaryBatch) {
            updateBootStage(80, "Indexing ${liveOnlyChannels.size} Live TV Channels...", "Zero-copy primitive arrays")
        }

        val prepared = withContext(Dispatchers.Default) {
            val seq = IntArray(liveOnlyChannels.size) { it }
            val byId = HashMap<String, Int>(liveOnlyChannels.size)
            val nonSeqNum = SparseIntArray()
            val byCatTemp = HashMap<String, ArrayList<Int>>(128)
            val categorySet = LinkedHashSet<String>()
            val epgIds = HashSet<String>(liveOnlyChannels.size.coerceAtMost(15000))

            for (i in liveOnlyChannels.indices) {
                if (i % 2000 == 0) ensureActive()
                val ch = liveOnlyChannels[i]
                if (!byId.containsKey(ch.id)) byId[ch.id] = i
                if (ch.number != i + 1 && nonSeqNum.indexOfKey(ch.number) < 0) {
                    nonSeqNum.put(ch.number, i)
                }
                if (ch.category.isNotBlank()) {
                    categorySet.add(ch.category)
                    byCatTemp.getOrPut(ch.category.lowercase(Locale.ROOT)) { ArrayList() }.add(i)
                }
                if (epgIds.size < 25000) {
                    epgIds.add(ch.id)
                    if (ch.epgId.isNotEmpty()) epgIds.add(ch.epgId)
                }
            }
            val byCatPrimitive = HashMap<String, IntArray>(byCatTemp.size)
            for ((k, list) in byCatTemp) {
                byCatPrimitive[k] = list.toIntArray()
            }
            val categories = ArrayList<String>(categorySet.size + 1).apply {
                add("All categories")
                addAll(categorySet.sorted())
            }
            val targetIdx = if (shouldResume) {
                (if (!savedLastId.isNullOrBlank()) byId[savedLastId] else null)
                    ?: savedLastIndex.takeIf { it in liveOnlyChannels.indices }
                    ?: 0
            } else {
                0
            }
            PreparedChannelData(seq, byId, nonSeqNum, byCatPrimitive, categories, epgIds, targetIdx)
        }

        allChannels = liveOnlyChannels
        allSequentialIndices = prepared.seq
        channelIndexById = prepared.byId
        nonSequentialNumberMap = prepared.nonSeqNum
        channelsByCategory = prepared.byCat
        knownEpgAndChannelIds = prepared.epgIds

        suppressCategoryCallback = true
        selectedCategory = "All categories"
        categoryFilter.adapter = createGlassCategoryAdapter(prepared.categories)
        categoryFilter.setSelection(0, false)
        suppressCategoryCallback = false

        if (sectionTitle != null) {
            tvActiveSectionBadge.text = sectionTitle
        }

        if (!isPreliminaryBatch || currentPlayingStreamUrl.isEmpty()) {
            previousChannelIndex = prepared.startIndex
            updateBootStage(92, "Starting Live TV...", "Channel #${prepared.startIndex + 1}")
            activePlaybackMode = ActivePlaybackMode.LIVE_TV
            switchChannel(prepared.startIndex, immediatePlayback = true)
        }

        if (leftChannelDrawer.visibility == View.VISIBLE) {
            renderDrawerList(scrollToActive = true)
        }
    }

    private data class PreparedChannelData(
        val seq: IntArray,
        val byId: Map<String, Int>,
        val nonSeqNum: SparseIntArray,
        val byCat: Map<String, IntArray>,
        val categories: List<String>,
        val epgIds: Set<String>,
        val startIndex: Int
    )

    private fun clearVodAndSeriesCatalogsForAccountSwitch() {
        vodCatalogLoadJob?.cancel()
        seriesCatalogLoadJob?.cancel()
        vodMoviesCatalog = emptyList()
        vodMovieIndexById = emptyMap()
        seriesCatalogRaw = emptyList()
        seriesCatalogGroups = emptyList()
        loadedSeriesEpisodesCache.clear()
        activeVodMovieItem = null
        activeVodMovieIndex = -1
        activeVodMovieDetailInfo = null
        activeSeriesGroup = null
        activeSeriesEpisodeItem = null
    }

    private fun initializeMedia3ProEngine(recreateIfPresent: Boolean = false) {
        if (exoPlayer != null && !recreateIfPresent) return
        val previousUrl = currentPlayingStreamUrl
        if (recreateIfPresent) {
            playerView.player = null
            exoPlayer?.release()
            exoPlayer = null
            currentPlayingStreamUrl = ""
        }

        val bp = activeBufferProfile
        val allocator = DefaultAllocator(true, 64 * 1024)
        sharedAllocator = allocator
        val loadControl = DefaultLoadControl.Builder()
            .setAllocator(allocator)
            .setBufferDurationsMs(bp.minBufferMs, bp.maxBufferMs, bp.playBufferMs, bp.rebufferMs)
            .setTargetBufferBytes(bp.targetBytes)
            .setBackBuffer(0, false)
            .setPrioritizeTimeOverSizeThresholds(bp.prioritizeTimeOverSize)
            .build()

        // Avoid loading optional software decoder extensions on 512MB TVs; enable async MediaCodec queueing & fallback.
        val renderersFactory = DefaultRenderersFactory(this)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF)
            .setEnableDecoderFallback(true)
            .forceEnableMediaCodecAsynchronousQueueing()

        // Direct-RAM Zero-Disk OkHttpDataSource wrapped with PreloadAwareDataSourceFactory
        val okHttpDataSourceFactory = OkHttpDataSource.Factory(NetworkClient.streamClient)
            .setUserAgent(NetworkClient.DEFAULT_USER_AGENT)
        val preloadAwareFactory = StreamPreFetcher.createPreloadAwareDataSourceFactory(okHttpDataSourceFactory)

        hlsChunklessFactory = HlsMediaSource.Factory(preloadAwareFactory)
            .setAllowChunklessPreparation(true)

        val mediaSourceFactory = DefaultMediaSourceFactory(preloadAwareFactory)
        defaultMediaSourceFactory = mediaSourceFactory

        exoPlayer = ExoPlayer.Builder(this, renderersFactory)
            .setLoadControl(loadControl)
            .setSeekParameters(SeekParameters.CLOSEST_SYNC)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setMediaSourceFactory(mediaSourceFactory)
            .build()
            .also { player ->
                player.videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT
                playerView.player = player
                playerView.resizeMode = resizeModes[currentResizeIndex]

                val paramsBuilder = player.trackSelectionParameters
                    .buildUpon()
                    .setPreferredAudioLanguages("hi", "hin", "en", "eng")
                if (isLowRamTvDevice && selectedQualityLabel == "Auto") {
                    paramsBuilder
                        .setMaxVideoSize(1920, 1080)
                        .setMaxVideoBitrate(8_000_000)
                }
                player.trackSelectionParameters = paramsBuilder.build()

                player.addListener(object : Player.Listener {
                    override fun onRenderedFirstFrame() {
                        val now = SystemClock.elapsedRealtime()
                        if (firstVideoFrameMs == 0L) {
                            firstVideoFrameMs = now - processStartElapsedMs
                        }
                        if (lastSwitchStartElapsedMs > 0L) {
                            lastChannelSwitchMs = now - lastSwitchStartElapsedMs
                        }
                        hasRenderedVideoFrame = true
                        if (isBootOverlayVisible) {
                            dismissDthBootOverlay("READY TO WATCH")
                        }
                        if (pendingResumeSeekPositionMs > 5_000L) {
                            val targetSeek = pendingResumeSeekPositionMs
                            pendingResumeSeekPositionMs = 0L
                            player.seekTo(targetSeek)
                        }
                        updateLiveTelemetryBadge(player)
                        if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                            updateOsdForCurrentChannel()
                        }
                    }

                    override fun onVideoSizeChanged(videoSize: VideoSize) {
                        val h = videoSize.height
                        val w = videoSize.width
                        if (h > 0 && w > 0) {
                            liveResolutionLabel = when {
                                h >= 2160 || w >= 3840 -> "4K UHD"
                                h >= 1080 -> "1080p FHD"
                                h >= 720 -> "720p HD"
                                h >= 540 -> "576p HQ"
                                else -> "${h}p SD"
                            }
                            updateLiveTelemetryBadge(player)
                            if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                                updateOsdForCurrentChannel()
                            }
                        }
                    }

                    override fun onPlaybackStateChanged(playbackState: Int) {
                        when (playbackState) {
                            Player.STATE_BUFFERING -> {
                                bufferingStartElapsedMs = SystemClock.elapsedRealtime()
                                liveStatusLabel = if (usingBackupStream) "⏳ Backup..." else "⏳ Buffering..."
                                osdLiveProgressBar.progress = 55
                                if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                                    updateOsdForCurrentChannel()
                                }
                                uiHandler.removeCallbacks(stallWatchdogRunnable)
                                uiHandler.postDelayed(stallWatchdogRunnable, 2500L)
                            }
                            Player.STATE_READY -> {
                                if (bufferingStartElapsedMs > 0L) {
                                    lastBufferingDurationMs = (SystemClock.elapsedRealtime() - bufferingStartElapsedMs).coerceAtLeast(1L)
                                    bufferingStartElapsedMs = 0L
                                }
                                playbackRetryCount = 0
                                stallRecoveryCount = 0
                                uiHandler.removeCallbacks(stallWatchdogRunnable)
                                liveStatusLabel = if (usingBackupStream) "🟢 Live (Backup)" else "🟢 Playing"
                                osdLiveProgressBar.progress = 100
                                updateLiveTelemetryBadge(player)
                                if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                                    updateOsdForCurrentChannel()
                                    if (allChannels.size > 1) {
                                        val nextIdx = (currentChannelIndex + 1) % allChannels.size
                                        val prevIdx = (currentChannelIndex - 1 + allChannels.size) % allChannels.size
                                        StreamPreFetcher.scheduleAdjacentPrefetch(
                                            this@PlayerActivity,
                                            allChannels.getOrNull(nextIdx)?.streamUrl,
                                            allChannels.getOrNull(prevIdx)?.streamUrl,
                                            preferForward = lastZapForward,
                                            hlsFactory = hlsChunklessFactory,
                                            defaultMediaSourceFactory = defaultMediaSourceFactory
                                        )
                                    }
                                }
                            }
                            Player.STATE_ENDED -> {
                                uiHandler.removeCallbacks(stallWatchdogRunnable)
                                when (activePlaybackMode) {
                                    ActivePlaybackMode.VOD_MOVIE -> {
                                        activeVodMovieItem?.let { m ->
                                            if (::profileStore.isInitialized) {
                                                profileStore.clearPlaybackProgress(m.id, activeAccountScope)
                                            }
                                        }
                                        liveStatusLabel = "✓ Movie Completed"
                                        osdLiveProgressBar.progress = 100
                                        val detail = activeVodMovieDetailInfo
                                        if (detail != null && activeVodMovieIndex in vodMoviesCatalog.indices) {
                                            openVodPosterHub(EntertainmentSection.MOVIES, restoreFocusIndex = lastFocusedPosterIndex)
                                            showMovieDetailModal(activeVodMovieIndex, detail)
                                        }
                                    }
                                    ActivePlaybackMode.SERIES_EPISODE -> {
                                        val curEp = activeSeriesEpisodeItem
                                        val grp = activeSeriesGroup
                                        if (curEp != null && ::profileStore.isInitialized) {
                                            profileStore.clearPlaybackProgress(curEp.channel.id, activeAccountScope)
                                        }
                                        liveStatusLabel = "✓ Episode Completed"
                                        osdLiveProgressBar.progress = 100
                                        if (grp != null && curEp != null) {
                                            val nextEp = MediaCatalogEngine.findNextEpisodeInSeries(
                                                group = grp,
                                                currentSeason = curEp.seasonNumber,
                                                currentEpisodeNumber = curEp.episodeNumber,
                                                currentEpisodeId = curEp.channel.id
                                            )
                                            if (nextEp != null && ::profileStore.isInitialized && profileStore.isAutoNextEpisodeEnabled()) {
                                                if (autoNextPromptShownForEpisodeId != curEp.channel.id) {
                                                    autoNextPromptShownForEpisodeId = curEp.channel.id
                                                    showAutoNextEpisodeCountdownModal(grp, nextEp)
                                                }
                                            } else {
                                                openVodPosterHub(EntertainmentSection.SERIES, restoreFocusIndex = lastFocusedPosterIndex)
                                                presentSeriesDetailOverlayDialog(grp, activeSeriesSeasonNum)
                                            }
                                        }
                                    }
                                    ActivePlaybackMode.VOD_TRAILER -> {
                                        val detail = activeVodMovieDetailInfo
                                        if (detail != null && activeVodMovieIndex in vodMoviesCatalog.indices) {
                                            openVodPosterHub(EntertainmentSection.MOVIES, restoreFocusIndex = lastFocusedPosterIndex)
                                            showMovieDetailModal(activeVodMovieIndex, detail)
                                        }
                                    }
                                    ActivePlaybackMode.LIVE_TV -> {
                                        liveStatusLabel = "🔄 Reconnecting..."
                                        osdLiveProgressBar.progress = 35
                                        updateOsdForCurrentChannel()
                                        uiHandler.removeCallbacks(retryPlaybackRunnable)
                                        uiHandler.postDelayed(retryPlaybackRunnable, 750L)
                                    }
                                }
                            }
                            Player.STATE_IDLE -> {
                                uiHandler.removeCallbacks(stallWatchdogRunnable)
                            }
                        }
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        uiHandler.removeCallbacks(stallWatchdogRunnable)
                        Log.w("StreamX", "Playback error (${error.errorCodeName}): ${NetworkClient.redactSensitiveUrl(error.message)}")

                        // Instant recovery for live window drift without consuming retry budget
                        if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                            liveStatusLabel = "⚡ Live Edge Sync..."
                            updateOsdForCurrentChannel()
                            player.seekToDefaultPosition()
                            player.prepare()
                            player.playWhenReady = true
                            return
                        }

                        if (error.errorCode == PlaybackException.ERROR_CODE_DECODING_FAILED ||
                            error.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED
                        ) {
                            player.trackSelectionParameters = player.trackSelectionParameters
                                .buildUpon()
                                .setMaxVideoSize(1280, 720)
                                .setMaxVideoBitrate(4_000_000)
                                .build()
                        }

                        if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                            val activeChannel = allChannels.getOrNull(currentChannelIndex)
                            if (activeChannel != null && !usingBackupStream && activeChannel.backupUrl.isNotBlank()) {
                                usingBackupStream = true
                                playbackRetryCount = 0
                                liveStatusLabel = "⚡ Auto-Failover Backup..."
                                updateOsdForCurrentChannel()
                                playSpecificStreamUrl(activeChannel.backupUrl)
                                return
                            }
                        }

                        val msgLower = error.message?.lowercase(Locale.ROOT).orEmpty()
                        val isPermanentAuthOrNotFound = msgLower.contains("401") ||
                            msgLower.contains("403") ||
                            msgLower.contains("404") ||
                            error.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS && playbackRetryCount >= 1

                        if (isPermanentAuthOrNotFound || playbackRetryCount >= 3) {
                            liveStatusLabel = "⚠️ Stream Offline"
                            osdLiveProgressBar.progress = 15
                            if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                                updateOsdForCurrentChannel()
                            }
                            if (isBootOverlayVisible) {
                                dismissDthBootOverlay("READY TO WATCH")
                            }
                            Toast.makeText(
                                this@PlayerActivity,
                                "Stream offline or unreachable. Try another stream or tap Sync.",
                                Toast.LENGTH_LONG
                            ).show()
                            return
                        }
                        playbackRetryCount++
                        val retryNum = playbackRetryCount
                        val backoffMs = (900L * (1 shl (retryNum - 1))).coerceAtMost(3200L)
                        liveStatusLabel = "🔄 Retry $retryNum/3..."
                        if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                            updateOsdForCurrentChannel()
                        }
                        uiHandler.removeCallbacks(retryPlaybackRunnable)
                        uiHandler.postDelayed(retryPlaybackRunnable, backoffMs)
                    }
                })
            }

        if (previousUrl.isNotEmpty()) {
            playSpecificStreamUrl(previousUrl, forceReload = true)
        }
    }

    private fun updateLiveTelemetryBadge(player: ExoPlayer) {
        val vf = player.videoFormat
        val af = player.audioFormat
        val parts = ArrayList<String>(2)
        if (vf != null) {
            if (vf.frameRate > 0f) {
                parts.add("${vf.frameRate.toInt()}fps")
            }
            if (vf.bitrate > 0) {
                val mbps = vf.bitrate / 1_000_000.0
                parts.add(String.format(Locale.US, "%.1fMbps", mbps))
            }
        }
        liveTelemetryDetail = parts.joinToString(" • ")

        val preloadPrefix = if (lastSwitchUsedPreload) "⚡ PRELOAD" else "⚡"
        val zapTag = if (lastChannelSwitchMs in 1..4999) "$preloadPrefix ${lastChannelSwitchMs}ms" else "$preloadPrefix DIRECT-RAM"
        val audioTag = af?.language?.uppercase(Locale.ROOT)?.takeIf { it.isNotBlank() && it != "UND" } ?: "STEREO"
        tvOsdStreamBadge.text = "$zapTag • $audioTag"
    }

    private fun recallPreviousChannel() {
        if (allChannels.isEmpty()) return
        activePlaybackMode = ActivePlaybackMode.LIVE_TV
        if (previousChannelIndex != currentChannelIndex && previousChannelIndex in allChannels.indices) {
            val target = previousChannelIndex
            Toast.makeText(this, "⟲ Recall: ${allChannels[target].name}", Toast.LENGTH_SHORT).show()
            switchChannel(target, immediatePlayback = true)
        } else if (recentIds.size >= 2) {
            val prevId = recentIds[1]
            val idx = channelIndexById[prevId]
            if (idx != null && idx != currentChannelIndex) {
                Toast.makeText(this, "⟲ Recall: ${allChannels[idx].name}", Toast.LENGTH_SHORT).show()
                switchChannel(idx, immediatePlayback = true)
            }
        } else {
            Toast.makeText(this, "No previous channel yet", Toast.LENGTH_SHORT).show()
        }
    }

    // =========================================================================
    // 4D CRYSTAL GLASS STUDIO MODAL DIALOG ENGINE
    // =========================================================================

    private fun build4dModalHeader(
        iconRes: Int,
        title: String,
        subtitle: String,
        badgeText: String
    ): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundResource(R.drawable.bg_dialog_header_4d)
            setPadding(dp(14), dp(12), dp(14), dp(12))

            val iconFrame = ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setBackgroundResource(R.drawable.bg_channel_logo_frame)
                setPadding(dp(8), dp(8), dp(8), dp(8))
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
            }
            addView(iconFrame)

            val textCol = LinearLayout(this@PlayerActivity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dp(12)
                    marginEnd = dp(8)
                }
            }
            val tvTitle = TextView(this@PlayerActivity).apply {
                text = title
                textSize = 15.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#F8FAFC"))
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            val tvSub = TextView(this@PlayerActivity).apply {
                text = subtitle
                textSize = 11.5f
                setTextColor(Color.parseColor("#BAE6FD"))
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            }
            textCol.addView(tvTitle)
            textCol.addView(tvSub)
            addView(textCol)

            if (badgeText.isNotBlank()) {
                val tvBadge = TextView(this@PlayerActivity).apply {
                    text = badgeText
                    textSize = 10.5f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(Color.parseColor("#38BDF8"))
                    setBackgroundResource(R.drawable.bg_badge_neon)
                    setPadding(dp(10), dp(5), dp(10), dp(5))
                }
                addView(tvBadge)
            }
        }
    }

    private fun create4dActionCapsuleButton(
        label: String,
        bgRes: Int,
        iconRes: Int = 0,
        onClick: () -> Unit
    ): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setBackgroundResource(bgRes)
            backgroundTintList = null
            isFocusable = true
            setPadding(dp(16), dp(8), dp(16), dp(8))
            if (iconRes != 0) {
                setCompoundDrawablesWithIntrinsicBounds(iconRes, 0, 0, 0)
                compoundDrawablePadding = dp(7)
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                dp(40)
            ).apply {
                marginStart = dp(8)
            }
            attach4dFocusMicroInteraction(this)
            setOnClickListener { onClick() }
        }
    }

    private fun present4dGlassDialog(rootCard: View, widthDp: Int = 540): AlertDialog {
        val dlg = AlertDialog.Builder(this, R.style.Theme_StreamX_GlassDialog)
            .setView(rootCard)
            .create()
        dlg.show()
        dlg.window?.let { win ->
            win.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            val maxW = (resources.displayMetrics.widthPixels * 0.92f).toInt()
            val targetW = dp(widthDp).coerceAtMost(maxW)
            win.setLayout(targetW, WindowManager.LayoutParams.WRAP_CONTENT)
        }
        return dlg
    }

    private fun show4dGlassListModal(
        headerIconRes: Int,
        title: String,
        subtitle: String,
        badgeText: String,
        options: List<GlassModalOption>,
        closeLabel: String = "Close"
    ) {
        var dialogRef: AlertDialog? = null
        val rootCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_dialog_4d_glass)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }

        rootCard.addView(build4dModalHeader(headerIconRes, title, subtitle, badgeText))

        val maxScrollHeight = (resources.displayMetrics.heightPixels * 0.56f).toInt().coerceAtLeast(dp(180))
        val scroll = ScrollView(this).apply {
            isFillViewport = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(12)
                bottomMargin = dp(10)
            }
        }
        val listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        var firstFocusableRow: View? = null
        options.forEachIndexed { idx, opt ->
            val rowCard = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isFocusable = true
                isClickable = true
                isSelected = opt.isHighlighted
                setBackgroundResource(
                    if (opt.isHighlighted) themes[currentThemeIndex].activeRowDrawableRes
                    else R.drawable.bg_dialog_item_4d
                )
                setPadding(dp(12), dp(10), dp(12), dp(10))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    if (idx < options.lastIndex) bottomMargin = dp(7)
                }
                attach4dFocusMicroInteraction(this, focusedScale = 1.02f)
                setOnClickListener {
                    dialogRef?.dismiss()
                    opt.onClick()
                }
            }

            val iconView = ImageView(this).apply {
                setImageResource(opt.iconRes)
                setBackgroundResource(R.drawable.bg_channel_logo_frame)
                setPadding(dp(6), dp(6), dp(6), dp(6))
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = LinearLayout.LayoutParams(dp(36), dp(36))
            }
            rowCard.addView(iconView)

            val textCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dp(11)
                    marginEnd = dp(8)
                }
            }
            val tvRowTitle = TextView(this).apply {
                text = opt.title
                textSize = 13.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.WHITE)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            val tvRowSub = TextView(this).apply {
                text = opt.subtitle
                textSize = 11f
                setTextColor(if (opt.isHighlighted) Color.parseColor("#FEF08A") else Color.parseColor("#CBD5E1"))
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            }
            textCol.addView(tvRowTitle)
            textCol.addView(tvRowSub)
            rowCard.addView(textCol)

            if (opt.badgeText.isNotBlank()) {
                val badge = TextView(this).apply {
                    text = opt.badgeText
                    textSize = 10.5f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(if (opt.isHighlighted) Color.parseColor("#6EE7B7") else Color.parseColor("#38BDF8"))
                    setBackgroundResource(
                        if (opt.isHighlighted) R.drawable.bg_live_dot_pill else R.drawable.bg_badge_neon
                    )
                    setPadding(dp(9), dp(4), dp(9), dp(4))
                }
                rowCard.addView(badge)
            }

            if (firstFocusableRow == null || opt.isHighlighted) {
                firstFocusableRow = rowCard
            }
            listContainer.addView(rowCard)
        }

        scroll.addView(listContainer)
        rootCard.addView(scroll)

        scroll.post {
            if (scroll.height > maxScrollHeight) {
                scroll.layoutParams = (scroll.layoutParams as LinearLayout.LayoutParams).apply {
                    height = maxScrollHeight
                }
            }
        }

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        footer.addView(
            create4dActionCapsuleButton(closeLabel, R.drawable.bg_btn_3d_slate) {
                dialogRef?.dismiss()
            }
        )
        rootCard.addView(footer)

        dialogRef = present4dGlassDialog(rootCard, widthDp = 560)
        firstFocusableRow?.post { firstFocusableRow?.requestFocus() }
    }

    private fun show4dGlassFormModal(
        headerIconRes: Int,
        title: String,
        subtitle: String,
        badgeText: String,
        fields: List<GlassFormFieldSpec>,
        neutralLabel: String? = null,
        neutralBgRes: Int = R.drawable.bg_btn_3d_emerald,
        neutralIconRes: Int = 0,
        onNeutral: (() -> Unit)? = null,
        positiveLabel: String,
        positiveBgRes: Int = R.drawable.bg_btn_3d_cyan,
        positiveIconRes: Int = 0,
        onSubmit: (List<String>) -> Unit
    ) {
        var dialogRef: AlertDialog? = null
        val rootCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_dialog_4d_glass)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }

        rootCard.addView(build4dModalHeader(headerIconRes, title, subtitle, badgeText))

        val formBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(12)
                bottomMargin = dp(14)
            }
        }

        val editTexts = ArrayList<EditText>(fields.size)
        fields.forEachIndexed { idx, spec ->
            val lbl = TextView(this).apply {
                text = spec.label
                textSize = 10.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#7DD3FC"))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    if (idx > 0) topMargin = dp(8)
                    bottomMargin = dp(4)
                }
            }
            formBox.addView(lbl)

            val et = EditText(this).apply {
                hint = spec.hint
                setText(spec.initialValue)
                setSingleLine(true)
                inputType = spec.inputType
                textSize = 13f
                setTextColor(Color.WHITE)
                setHintTextColor(Color.parseColor("#94A3B8"))
                setBackgroundResource(R.drawable.bg_glass_input_4d)
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setCompoundDrawablesWithIntrinsicBounds(spec.iconRes, 0, 0, 0)
                compoundDrawablePadding = dp(10)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(44)
                )
            }
            editTexts.add(et)
            formBox.addView(et)
        }
        rootCard.addView(formBox)

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        if (!neutralLabel.isNullOrBlank() && onNeutral != null) {
            val neutralBtn = create4dActionCapsuleButton(neutralLabel, neutralBgRes, neutralIconRes) {
                dialogRef?.dismiss()
                onNeutral()
            }.apply {
                (layoutParams as LinearLayout.LayoutParams).marginStart = 0
            }
            footer.addView(neutralBtn)
        }

        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        footer.addView(spacer)

        footer.addView(
            create4dActionCapsuleButton("Cancel", R.drawable.bg_btn_3d_slate) {
                dialogRef?.dismiss()
            }
        )
        footer.addView(
            create4dActionCapsuleButton(positiveLabel, positiveBgRes, positiveIconRes) {
                val values = editTexts.map { it.text?.toString()?.trim().orEmpty() }
                dialogRef?.dismiss()
                onSubmit(values)
            }
        )
        rootCard.addView(footer)

        dialogRef = present4dGlassDialog(rootCard, widthDp = 540)
        editTexts.firstOrNull()?.post { editTexts.firstOrNull()?.requestFocus() }
    }

    private fun showAudioAndQualityDialog() {
        val player = exoPlayer ?: return
        val options = ArrayList<GlassModalOption>(14)

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_speed_bolt,
                title = "Sync to Live Broadcast Edge",
                subtitle = "Jump directly to real-time live edge with zero delay",
                badgeText = "ZERO DELAY",
                isHighlighted = false
            ) {
                player.seekToDefaultPosition()
                player.prepare()
                player.playWhenReady = true
                Toast.makeText(this, "⚡ Synced to real-time live edge!", Toast.LENGTH_SHORT).show()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_rocket,
                title = "Performance Mode: ${activePerformanceMode.title}",
                subtitle = activePerformanceMode.subtitle,
                badgeText = "MODE",
                isHighlighted = false
            ) {
                showPerformanceModeDialog()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_ram_gauge,
                title = "Buffer Profile: ${activeBufferProfile.label}",
                subtitle = activeBufferProfile.subtitle,
                badgeText = "CHANGE",
                isHighlighted = false
            ) {
                showBufferProfileDialog()
            }
        )

        val qualities = listOf(
            Triple("Video Quality: Auto", "Smart 1080p / 8 Mbps Low-RAM Hardware Guard", null as Pair<Int, Int>?),
            Triple("Video Quality: 1080p Full HD", "1920x1080 • Maximum Crystal Sharpness", 1920 to 1080),
            Triple("Video Quality: 720p HD", "1280x720 • Recommended for 512MB RAM Smart TVs", 1280 to 720),
            Triple("Video Quality: 480p SD", "854x480 • Fast Zap & Mobile Data Saver", 854 to 480),
            Triple("Video Quality: 360p Eco", "640x360 • Ultra Low Bandwidth Mode", 640 to 360)
        )
        for ((titleText, subText, size) in qualities) {
            val tagKey = if (size == null) "Auto" else "${size.second}p"
            val isCurrent = selectedQualityLabel == tagKey
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_video_4k,
                    title = titleText,
                    subtitle = subText,
                    badgeText = if (isCurrent) "ACTIVE ✓" else tagKey.uppercase(Locale.ROOT),
                    isHighlighted = isCurrent
                ) {
                    val builder = player.trackSelectionParameters.buildUpon()
                    if (size == null) {
                        if (isLowRamTvDevice) {
                            builder.setMaxVideoSize(1920, 1080).setMaxVideoBitrate(8_000_000)
                        } else {
                            builder.clearVideoSizeConstraints()
                        }
                        selectedQualityLabel = "Auto"
                    } else {
                        builder.setMaxVideoSize(size.first, size.second)
                        selectedQualityLabel = "${size.second}p"
                    }
                    player.trackSelectionParameters = builder.build()
                    Toast.makeText(this, "Video Quality set to $selectedQualityLabel", Toast.LENGTH_SHORT).show()
                }
            )
        }

        val tracks: Tracks = player.currentTracks
        var audioIndex = 1
        val currentChId = allChannels.getOrNull(currentChannelIndex)?.id
        for (group in tracks.groups) {
            if (group.type == C.TRACK_TYPE_AUDIO && group.isSupported) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val rawLang = format.language
                    val lang = rawLang?.let { Locale(it).displayLanguage }?.ifBlank { null } ?: "Track $audioIndex"
                    val label = format.label?.takeIf { it.isNotBlank() } ?: "Broadcast Audio"
                    val chCount = if (format.channelCount > 0) "${format.channelCount}ch" else "Stereo"
                    val isSelected = group.isTrackSelected(i)
                    val trackGroup = group.mediaTrackGroup
                    val trackIdx = i
                    options.add(
                        GlassModalOption(
                            iconRes = R.drawable.ic_3d_audio_hd,
                            title = "Audio Track $audioIndex: $lang",
                            subtitle = "$label • $chCount • Auto-saved for this channel",
                            badgeText = if (isSelected) "PLAYING ✓" else chCount.uppercase(Locale.ROOT),
                            isHighlighted = isSelected
                        ) {
                            player.trackSelectionParameters = player.trackSelectionParameters
                                .buildUpon()
                                .setOverrideForType(TrackSelectionOverride(trackGroup, trackIdx))
                                .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                                .build()
                            if (!currentChId.isNullOrBlank() && !rawLang.isNullOrBlank()) {
                                profileStore.setPreferredAudioLanguage(currentChId, rawLang)
                            }
                            Toast.makeText(this, "Switched to $lang $label (Saved for channel)", Toast.LENGTH_SHORT).show()
                        }
                    )
                    audioIndex++
                }
            }
        }

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_subtitles,
                title = "Subtitles / Closed Captions",
                subtitle = "Toggle DVB / CEA-608 / WebVTT live broadcast subtitles",
                badgeText = if (subtitlesEnabled) "ON ✓" else "OFF",
                isHighlighted = subtitlesEnabled
            ) {
                subtitlesEnabled = !subtitlesEnabled
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !subtitlesEnabled)
                    .build()
                Toast.makeText(
                    this,
                    if (subtitlesEnabled) "Subtitles Enabled" else "Subtitles Disabled",
                    Toast.LENGTH_SHORT
                ).show()
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_audio_hd,
            title = "Audio, Video Quality & Buffer Profiles",
            subtitle = "Real-Time Media3 Track Engine • ${liveResolutionLabel}${if (liveTelemetryDetail.isNotEmpty()) " • $liveTelemetryDetail" else ""}",
            badgeText = selectedQualityLabel.uppercase(Locale.ROOT),
            options = options,
            closeLabel = "Close"
        )
    }

    private fun showPerformanceModeDialog() {
        val options = PerformanceMode.values().map { mode ->
            val isCur = mode == activePerformanceMode
            GlassModalOption(
                iconRes = when (mode) {
                    PerformanceMode.FAST_ZAPPING -> R.drawable.ic_3d_speed_bolt
                    PerformanceMode.LOW_MEMORY -> R.drawable.ic_3d_ram_gauge
                    PerformanceMode.NETWORK_SAVER -> R.drawable.ic_3d_network
                    PerformanceMode.SMART_BALANCED -> R.drawable.ic_3d_rocket
                },
                title = mode.title,
                subtitle = mode.subtitle,
                badgeText = if (isCur) "ACTIVE ✓" else "${mode.focusDebounceMs}ms",
                isHighlighted = isCur
            ) {
                activePerformanceMode = mode
                StreamPreFetcher.setPerformanceMode(mode)
                if (::profileStore.isInitialized) {
                    profileStore.setPerformanceMode(mode)
                }
                if (mode == PerformanceMode.LOW_MEMORY) {
                    runCatching { Glide.get(this).clearMemory() }
                    ChannelCacheStore.trimMemoryCache()
                }
                val targetBuf = BufferProfile.fromId(mode.recommendedBufferProfileId, isLowRamTvDevice)
                if (targetBuf != activeBufferProfile) {
                    activeBufferProfile = targetBuf
                    getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
                        .edit()
                        .putString("buffer_profile_id", targetBuf.id)
                        .apply()
                    initializeMedia3ProEngine(recreateIfPresent = true)
                }
                Toast.makeText(this, "⚡ Performance Mode: ${mode.title}", Toast.LENGTH_SHORT).show()
            }
        }

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_rocket,
            title = "Performance Modes & Smart Low-Memory Guard (v18.1)",
            subtitle = "Adaptive preload, conservative poster decoding & memory profiles for Android TV",
            badgeText = activePerformanceMode.id,
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showBufferProfileDialog() {
        val options = BufferProfile.values().map { p ->
            val isCur = p == activeBufferProfile
            GlassModalOption(
                iconRes = if (p == BufferProfile.LOW_LATENCY || p == BufferProfile.ULTRA_FAST_ZAP) {
                    R.drawable.ic_3d_speed_bolt
                } else {
                    R.drawable.ic_3d_ram_gauge
                },
                title = p.label,
                subtitle = p.subtitle,
                badgeText = if (isCur) "ACTIVE ✓" else "${p.playBufferMs}ms",
                isHighlighted = isCur
            ) {
                if (p != activeBufferProfile) {
                    activeBufferProfile = p
                    getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
                        .edit()
                        .putString("buffer_profile_id", p.id)
                        .apply()
                    initializeMedia3ProEngine(recreateIfPresent = true)
                    Toast.makeText(this, "Buffer Profile: ${p.label}", Toast.LENGTH_SHORT).show()
                }
            }
        }

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_ram_gauge,
            title = "Adaptive Buffer Profiles (512MB Tuned)",
            subtitle = "Choose start speed vs. network cushion for your Smart TV",
            badgeText = "512MB GUARD",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showThemeAndPipDialog() {
        val options = ArrayList<GlassModalOption>(16)
        themes.forEachIndexed { idx, t ->
            val isCur = idx == currentThemeIndex
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_theme,
                    title = "4D Theme: ${t.name}",
                    subtitle = t.subtitle,
                    badgeText = if (isCur) "ACTIVE ✓" else "APPLY",
                    isHighlighted = isCur
                ) {
                    applyTheme(idx)
                    getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
                        .edit()
                        .putInt("theme_index", idx)
                        .apply()
                    Toast.makeText(this, "4D Theme applied: ${t.name}", Toast.LENGTH_SHORT).show()
                }
            )
        }

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_speed_bolt,
                title = "Performance Mode: ${activePerformanceMode.title}",
                subtitle = activePerformanceMode.subtitle,
                badgeText = "CHANGE"
            ) {
                showPerformanceModeDialog()
            }
        )

        val autoNextOn = if (::profileStore.isInitialized) profileStore.isAutoNextEpisodeEnabled() else true
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_series,
                title = "Smart Auto Next Episode (Series)",
                subtitle = "Show countdown prompt and automatically play the next episode in the same series",
                badgeText = if (autoNextOn) "ON ✓" else "OFF",
                isHighlighted = autoNextOn
            ) {
                val nextVal = !autoNextOn
                profileStore.setAutoNextEpisodeEnabled(nextVal)
                Toast.makeText(
                    this,
                    "📺 Smart Auto Next Episode: ${if (nextVal) "ENABLED" else "DISABLED"}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_rocket,
                title = "Auto-Start on TV Boot",
                subtitle = "Launch StreamX automatically when Android TV powers on",
                badgeText = if (autoBootEnabled) "ON ✓" else "OFF",
                isHighlighted = autoBootEnabled
            ) {
                toggleAutoBootSetting()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_live_tv,
                title = "Auto-Resume Last Watched Channel",
                subtitle = "Instantly tune to your last channel on app startup",
                badgeText = if (autoResumeEnabled) "ON ✓" else "OFF",
                isHighlighted = autoResumeEnabled
            ) {
                toggleAutoResumeSetting()
            }
        )

        val hasPin = profileStore.hasParentalPin()
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_lock,
                title = "4-Digit Parental PIN Lock",
                subtitle = "Protect specific channel categories with a 4-digit PIN",
                badgeText = if (hasPin) "LOCKED ✓" else "OFF",
                isHighlighted = hasPin
            ) {
                showParentalPinSettingsDialog()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_ram_gauge,
                title = "512MB RAM & Zap Benchmark Telemetry",
                subtitle = "Inspect real-time JVM/Native heap, switch benchmarks, prefetch hit rate & cache size",
                badgeText = "BENCHMARKS"
            ) {
                showPerformanceMonitorDialog()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_pip,
                title = "Enter Picture-in-Picture (PiP Mini Player)",
                subtitle = "Continue watching live TV in a floating corner window",
                badgeText = "MINI TV"
            ) {
                enterPipModeSafe()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "Clear Offline SXB2 Channel & EPG Cache",
                subtitle = "Purge cached playlists and free flash/RAM memory",
                badgeText = "CLEAN"
            ) {
                lifecycleScope.launch {
                    channelCache.clearAllCaches()
                    epgCache.clear()
                    StreamPreFetcher.trimIdleCacheOnLowMemory()
                    Toast.makeText(
                        this@PlayerActivity,
                        "Caches cleared! Tap Sync to reload.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_theme,
            title = "4D Studio Themes, Performance Modes & Diagnostics",
            subtitle = "StreamX v18.1 Next-Gen Ultra Extreme • Crystal Glass Themes, Modes & 512MB Telemetry",
            badgeText = "v18.1 EXTREME",
            options = options,
            closeLabel = "Close"
        )
    }

    private fun showParentalPinSettingsDialog() {
        val currentPin = profileStore.getParentalPin()
        val currentCat = allChannels.getOrNull(currentChannelIndex)?.category ?: "General"
        val isCatLocked = profileStore.getLockedCategories().any { it.equals(currentCat, ignoreCase = true) }

        val options = listOf(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_lock,
                title = if (currentPin.length == 4) "Change 4-Digit Parental PIN" else "Set 4-Digit Parental PIN",
                subtitle = "Create or update your 4-digit category security code",
                badgeText = if (currentPin.length == 4) "ACTIVE ✓" else "SET PIN",
                isHighlighted = currentPin.length == 4
            ) {
                show4dGlassFormModal(
                    headerIconRes = R.drawable.ic_3d_lock,
                    title = "Set 4-Digit Parental PIN",
                    subtitle = "Enter exactly 4 numeric digits to lock restricted categories",
                    badgeText = "SECURITY",
                    fields = listOf(
                        GlassFormFieldSpec(
                            label = "4-DIGIT PARENTAL PIN CODE",
                            hint = "Enter 4-digit PIN (e.g. 1234)",
                            iconRes = R.drawable.ic_3d_lock,
                            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
                        )
                    ),
                    positiveLabel = "Save PIN",
                    positiveBgRes = R.drawable.bg_btn_3d_gold,
                    positiveIconRes = R.drawable.ic_3d_lock
                ) { values ->
                    val pin = values.firstOrNull().orEmpty()
                    if (pin.length == 4 && pin.all { it.isDigit() }) {
                        profileStore.setParentalPin(pin)
                        unlockedSessionCategories.clear()
                        Toast.makeText(this, "🔒 4-Digit Parental PIN Enabled!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Please enter exactly 4 digits", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_category,
                title = "Lock / Unlock Category: $currentCat",
                subtitle = "Toggle PIN protection for the currently playing channel's group",
                badgeText = if (isCatLocked) "LOCKED 🔒" else "UNLOCKED",
                isHighlighted = isCatLocked
            ) {
                val locked = profileStore.toggleCategoryLock(currentCat)
                Toast.makeText(
                    this,
                    if (locked) "🔒 Category '$currentCat' Locked" else "🔓 Category '$currentCat' Unlocked",
                    Toast.LENGTH_SHORT
                ).show()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "Disable Parental PIN Lock",
                subtitle = "Remove PIN requirement across all channel categories",
                badgeText = "DISABLE"
            ) {
                profileStore.setParentalPin("")
                unlockedSessionCategories.clear()
                Toast.makeText(this, "🔓 Parental PIN Lock Disabled", Toast.LENGTH_SHORT).show()
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_lock,
            title = "4-Digit Parental PIN Lock",
            subtitle = "Category access control for family-safe television viewing",
            badgeText = if (currentPin.length == 4) "PIN ON" else "PIN OFF",
            options = options,
            closeLabel = "Close"
        )
    }

    private fun promptParentalPinToUnlock(category: String, onUnlocked: () -> Unit) {
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_lock,
            title = "Locked Category: $category",
            subtitle = "Enter your 4-digit Parental PIN to watch channels in '$category'",
            badgeText = "LOCKED 🔒",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "ENTER 4-DIGIT PARENTAL PIN",
                    hint = "••••",
                    iconRes = R.drawable.ic_3d_lock,
                    inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
                )
            ),
            positiveLabel = "Unlock Category",
            positiveBgRes = R.drawable.bg_btn_3d_gold,
            positiveIconRes = R.drawable.ic_3d_lock
        ) { values ->
            if (profileStore.verifyParentalPin(values.firstOrNull().orEmpty())) {
                unlockedSessionCategories.add(category.lowercase(Locale.ROOT))
                onUnlocked()
            } else {
                Toast.makeText(this, "❌ Incorrect Parental PIN", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun toggleAutoBootSetting() {
        autoBootEnabled = !autoBootEnabled
        getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("auto_boot_enabled", autoBootEnabled)
            .apply()
        runCatching {
            val comp = ComponentName(this, BootReceiver::class.java)
            val newState = if (autoBootEnabled) {
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            } else {
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            }
            packageManager.setComponentEnabledSetting(comp, newState, PackageManager.DONT_KILL_APP)
        }
        Toast.makeText(
            this,
            "🚀 Auto-Start on TV Boot: ${if (autoBootEnabled) "ENABLED" else "DISABLED"}",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun toggleAutoResumeSetting() {
        autoResumeEnabled = !autoResumeEnabled
        getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("auto_resume_enabled", autoResumeEnabled)
            .apply()
        Toast.makeText(
            this,
            "▶️ Auto-Resume Last Channel: ${if (autoResumeEnabled) "ENABLED" else "DISABLED"}",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun showPerformanceMonitorDialog() {
        val rt = Runtime.getRuntime()
        val usedHeapMb = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024)
        val maxHeapMb = (rt.maxMemory() / (1024 * 1024)).coerceAtLeast(1)
        val heapPct = ((usedHeapMb * 100L) / maxHeapMb).toInt().coerceIn(5, 100)
        val nativeHeapMb = Debug.getNativeHeapAllocatedSize() / (1024 * 1024)
        val chCacheKb = channelCache.totalCacheSizeBytes() / 1024
        val epgCacheKb = epgCache.cacheSizeBytes() / 1024

        var dialogRef: AlertDialog? = null
        val rootCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_dialog_4d_glass)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }

        rootCard.addView(
            build4dModalHeader(
                iconRes = R.drawable.ic_3d_ram_gauge,
                title = "StreamX v18.1 Next-Gen 512MB & Zap Benchmarks",
                subtitle = "Real-Time Memory Footprint, Zapping Stage Timings & Separated Catalogs",
                badgeText = "${usedHeapMb}/${maxHeapMb} MB"
            )
        )

        val gaugeBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_dialog_item_4d)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(10)
            }
        }
        val tvGaugeLabel = TextView(this).apply {
            text = "JVM Heap Memory Pressure: $usedHeapMb MB used of $maxHeapMb MB ($heapPct%) • Native: $nativeHeapMb MB"
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#E0F2FE"))
        }
        val heapBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = heapPct
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(8)
            ).apply {
                topMargin = dp(6)
            }
        }
        gaugeBox.addView(tvGaugeLabel)
        gaugeBox.addView(heapBar)
        rootCard.addView(gaugeBox)

        val benchmarkMetrics = ZapBenchmarkMetrics(
            keyPressToSelectionMs = lastKeyPressToSelectionMs,
            selectionToPrepareMs = lastSelectionToPrepareMs,
            selectionToFirstFrameMs = lastChannelSwitchMs,
            channelSwitchCompletionMs = lastChannelSwitchMs + lastKeyPressToSelectionMs,
            lastBufferingDurationMs = lastBufferingDurationMs,
            prefetchHitRatePercent = StreamPreFetcher.prefetchHitRatePercent(),
            failedPrefetchRatePercent = StreamPreFetcher.failedPrefetchRatePercent()
        )

        val metrics = listOf(
            "Device & Performance Mode" to "${totalDeviceRamMb} MB • ${activePerformanceMode.title}",
            "Active Buffer Profile" to activeBufferProfile.label,
            "Key-Press → Selection / Prep" to "${benchmarkMetrics.keyPressToSelectionMs} ms key → ${benchmarkMetrics.selectionToPrepareMs} ms prep",
            "Selection → First Video Frame" to if (benchmarkMetrics.selectionToFirstFrameMs > 0) "${benchmarkMetrics.selectionToFirstFrameMs} ms (Total: ${benchmarkMetrics.channelSwitchCompletionMs} ms)" else "Instant Ready",
            "Last Buffering Duration" to "${benchmarkMetrics.lastBufferingDurationMs} ms",
            "Prefetch Hit / Fail Rate" to "${benchmarkMetrics.prefetchHitRatePercent}% Hit • ${benchmarkMetrics.failedPrefetchRatePercent}% Fail (${StreamPreFetcher.preloadStatusSummary()})",
            "Separated Catalogs & Cache" to "${allChannels.size} Live TV • ${vodMoviesCatalog.size} VOD Movies • ${seriesCatalogGroups.size} Series • ${chCacheKb}KB SXB2 • ${epgCacheKb}KB EPG"
        )

        val metricsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(8)
                bottomMargin = dp(12)
            }
        }
        for ((k, v) in metrics) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundResource(R.drawable.bg_dialog_item_4d)
                setPadding(dp(12), dp(7), dp(12), dp(7))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dp(5)
                }
            }
            val tvK = TextView(this).apply {
                text = k
                textSize = 11f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#7DD3FC"))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.42f)
            }
            val tvV = TextView(this).apply {
                text = v
                textSize = 11f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.WHITE)
                gravity = Gravity.END
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.58f)
            }
            row.addView(tvK)
            row.addView(tvV)
            metricsContainer.addView(row)
        }
        rootCard.addView(metricsContainer)

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
        }
        val trimBtn = create4dActionCapsuleButton("Trim RAM Now", R.drawable.bg_btn_3d_emerald, R.drawable.ic_3d_speed_bolt) {
            StreamPreFetcher.trimIdleCacheOnLowMemory()
            ChannelCacheStore.trimMemoryCache()
            sharedAllocator?.trim()
            runCatching { Glide.get(this).clearMemory() }
            dialogRef?.dismiss()
            Toast.makeText(this, "⚡ RAM trimmed & idle buffers freed!", Toast.LENGTH_SHORT).show()
        }
        val closeBtn = create4dActionCapsuleButton("Close", R.drawable.bg_btn_3d_slate) {
            dialogRef?.dismiss()
        }
        footer.addView(trimBtn)
        footer.addView(closeBtn)
        rootCard.addView(footer)

        dialogRef = present4dGlassDialog(rootCard, widthDp = 580)
        trimBtn.post { trimBtn.requestFocus() }
    }

    private fun applyTheme(index: Int) {
        currentThemeIndex = index.coerceIn(themes.indices)
        val palette = themes[currentThemeIndex]
        val badgeTextColor = Color.parseColor(palette.badgeTextHex)
        val statusColor = Color.parseColor(palette.statusHex)

        tvChannelNumber.setTextColor(badgeTextColor)
        tvChannelCategory.setTextColor(statusColor)
        updateTabButton3dSelection(activeTab)
        channelAdapter.setActiveRowDrawable(palette.activeRowDrawableRes)
    }

    private fun enterPipModeSafe() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
            } catch (e: Exception) {
                Log.w("StreamX", "PiP not supported: ${e.message}")
                Toast.makeText(this, "PiP not supported on this device", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "PiP requires Android 8.0+", Toast.LENGTH_SHORT).show()
        }
    }

    private fun forceRefreshActivePlaylist() {
        val creds = activeXtreamCreds
        when {
            activeSourceType == ProfileType.XTREAM && creds != null -> {
                Toast.makeText(this, "🔄 Syncing fresh catalogs from Xtream Server...", Toast.LENGTH_SHORT).show()
                loadXtreamChannels(creds, forceNetworkRefresh = true)
            }
            activeSourceType == ProfileType.M3U && activeM3uInput.isNotBlank() -> {
                Toast.makeText(this, "🔄 Syncing fresh M3U Live TV playlist...", Toast.LENGTH_SHORT).show()
                loadM3uFromInput(activeM3uInput, activeM3uLabel, forceNetworkRefresh = true)
            }
            else -> {
                Toast.makeText(this, "Connect an Xtream or M3U account first to sync", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun toggleCurrentChannelFavorite() {
        if (allChannels.isEmpty()) return
        val ch = allChannels[currentChannelIndex]
        if (favoriteIds.contains(ch.id)) {
            favoriteIds.remove(ch.id)
            Toast.makeText(this, "Removed from ★ Favorites", Toast.LENGTH_SHORT).show()
        } else {
            favoriteIds.add(ch.id)
            Toast.makeText(this, "Added to ★ Favorites!", Toast.LENGTH_SHORT).show()
        }
        getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
            .edit()
            .putStringSet("fav_ids", HashSet(favoriteIds))
            .apply()
        updateFavButtonUi(ch.id)
        if (leftChannelDrawer.visibility == View.VISIBLE) {
            if (activeTab == "FAV") {
                renderDrawerList()
            } else {
                channelAdapter.notifyFavoriteChanged(currentChannelIndex)
            }
        }
    }

    private fun updateFavButtonUi(channelId: String) {
        val isFav = favoriteIds.contains(channelId)
        btnToggleFavorite.text = if (isFav) "★" else "☆"
    }

    private fun renderDrawerList(
        debounceMs: Long = 0L,
        scrollToActive: Boolean = false,
        requestFocusOnActive: Boolean = false
    ) {
        filterJob?.cancel()
        filterJob = lifecycleScope.launch {
            if (debounceMs > 0L) {
                delay(debounceMs)
            }
            val snapshotChannels = allChannels
            val snapshotSeq = allSequentialIndices
            val snapshotByCategory = channelsByCategory
            val snapshotFavs = HashSet(favoriteIds)
            val snapshotRecents = ArrayList(recentIds)
            val snapshotById = channelIndexById
            val tab = activeTab
            val query = searchQuery.trim()
            val category = selectedCategory
            val activeIdx = currentChannelIndex
            val oldIndices = channelAdapter.currentIndices()

            val (filteredAll, pagedSlice, diffResult) = withContext(Dispatchers.Default) {
                val matchAllCat = category == "All categories" || category.isBlank()
                val baseIndices: IntArray = when (tab) {
                    "FAV" -> {
                        val temp = ArrayList<Int>(snapshotFavs.size)
                        for (i in snapshotChannels.indices) {
                            if (snapshotFavs.contains(snapshotChannels[i].id)) temp.add(i)
                        }
                        temp.toIntArray()
                    }
                    "RECENT" -> {
                        val temp = ArrayList<Int>(snapshotRecents.size)
                        for (id in snapshotRecents) {
                            val idx = snapshotById[id]
                            if (idx != null && idx in snapshotChannels.indices) temp.add(idx)
                        }
                        temp.toIntArray()
                    }
                    else -> {
                        if (matchAllCat) {
                            snapshotSeq
                        } else {
                            snapshotByCategory[category.lowercase(Locale.ROOT)] ?: IntArray(0)
                        }
                    }
                }

                val resultIndices: IntArray = if (query.isEmpty() && (tab == "ALL" || matchAllCat)) {
                    baseIndices
                } else {
                    val temp = ArrayList<Int>(256)
                    for (idx in baseIndices) {
                        if (idx !in snapshotChannels.indices) continue
                        val ch = snapshotChannels[idx]
                        val catMatches = (tab == "ALL") || matchAllCat || ch.category.equals(category, ignoreCase = true)
                        val queryMatches = query.isEmpty() ||
                            ch.name.contains(query, ignoreCase = true) ||
                            ch.category.contains(query, ignoreCase = true) ||
                            ch.number.toString() == query
                        if (catMatches && queryMatches) {
                            temp.add(idx)
                        }
                    }
                    temp.toIntArray()
                }

                val activePosInResult = if (scrollToActive) {
                    resultIndices.indexOfFirst { it == activeIdx }
                } else {
                    0
                }
                val requiredWindow = ((activePosInResult + 200).coerceAtLeast(pageStepSize))
                    .coerceAtMost(resultIndices.size)
                val slice = if (resultIndices.size > requiredWindow) {
                    resultIndices.copyOfRange(0, requiredWindow)
                } else {
                    resultIndices
                }

                val diff = if (oldIndices.isNotEmpty() && slice.isNotEmpty() &&
                    oldIndices.size <= 1800 && slice.size <= 1800 && oldIndices !== slice
                ) {
                    DiffUtil.calculateDiff(object : DiffUtil.Callback() {
                        override fun getOldListSize(): Int = oldIndices.size
                        override fun getNewListSize(): Int = slice.size
                        override fun areItemsTheSame(oldPos: Int, newPos: Int): Boolean =
                            oldIndices[oldPos] == slice[newPos]
                        override fun areContentsTheSame(oldPos: Int, newPos: Int): Boolean =
                            oldIndices[oldPos] == slice[newPos]
                    }, false)
                } else {
                    null
                }
                Triple(resultIndices, slice, diff)
            }

            fullFilteredIndices = filteredAll
            currentPagedLimit = pagedSlice.size

            if (pagedSlice.isEmpty()) {
                tvEmptyDrawer.text = if (tab == "FAV") {
                    "★ कोई Favorite चैनल नहीं है। ☆ बटन दबाकर जोड़ें।"
                } else {
                    "कोई चैनल नहीं मिला।"
                }
                tvEmptyDrawer.visibility = View.VISIBLE
                channelListRecycler.visibility = View.GONE
                channelAdapter.submitIndices(IntArray(0), activeIdx, null)
            } else {
                tvEmptyDrawer.visibility = View.GONE
                channelListRecycler.visibility = View.VISIBLE
                channelAdapter.submitIndices(pagedSlice, activeIdx, diffResult, isAscending = (tab != "RECENT"))
                if (scrollToActive) {
                    val pos = pagedSlice.indexOfFirst { it == activeIdx }.coerceAtLeast(0)
                    val lm = channelListRecycler.layoutManager as? LinearLayoutManager
                    lm?.scrollToPositionWithOffset(pos, 120)
                    if (requestFocusOnActive) {
                        channelListRecycler.post {
                            val holder = channelListRecycler.findViewHolderForAdapterPosition(pos)
                            if (holder != null) {
                                holder.itemView.requestFocus()
                            } else {
                                channelListRecycler.requestFocus()
                            }
                        }
                    }
                }
            }
        }
    }

    private fun importLocalM3uUri(uri: Uri) {
        xtreamRepo.cancelActiveFetch()
        loadChannelsJob?.cancel()
        clearVodAndSeriesCatalogsForAccountSwitch()

        loadChannelsJob = lifecycleScope.launch {
            val t0 = SystemClock.elapsedRealtime()
            tvActiveSectionBadge.text = "⏳ Importing M3U Live TV playlist..."
            runCatching {
                withContext(Dispatchers.IO) {
                    val cachedFile = File(filesDir, "local_playlist_${System.currentTimeMillis()}.m3u")
                    contentResolver.openInputStream(uri)?.use { input ->
                        cachedFile.outputStream().use { output ->
                            input.copyTo(output, bufferSize = 65536)
                        }
                    } ?: error("Cannot read selected file")
                    val channels = cachedFile.bufferedReader(Charsets.UTF_8).use { reader ->
                        M3uParser.parse(reader, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive })
                    }
                    cachedFile to channels
                }
            }.onSuccess { (cachedFile, channels) ->
                lastPlaylistLoadDurationMs = SystemClock.elapsedRealtime() - t0
                if (channels.isNotEmpty()) {
                    val fileSource = "file://${cachedFile.absolutePath}"
                    val localProfile = PlaylistProfile(
                        name = "Local playlist (${channels.size} ch)",
                        type = ProfileType.M3U,
                        source = fileSource
                    )
                    profileStore.save(localProfile)
                    profileStore.setActive(localProfile.id)
                    activeSourceType = ProfileType.M3U
                    activeXtreamCreds = null
                    activeM3uInput = fileSource
                    activeM3uLabel = localProfile.name
                    activeAccountScope = localProfile.id
                    val cKey = cacheKeyFor("m3u_live_$fileSource")
                    launch(Dispatchers.IO) {
                        channelCache.saveChannels(cKey, channels, maxLimit = maxPlaylistLimit)
                    }
                    applyLoadedChannels(channels, "StreamX v18.1 • ${localProfile.name}", resumeLastWatched = false)
                    Toast.makeText(this@PlayerActivity, "Imported & cached ${channels.size} Live TV channels", Toast.LENGTH_LONG).show()
                } else {
                    tvActiveSectionBadge.text = "StreamX v18.1 • All Live TV"
                    Toast.makeText(this@PlayerActivity, "No valid M3U channels found", Toast.LENGTH_LONG).show()
                }
            }.onFailure { e ->
                Log.w("StreamX", "Local M3U import failed", e)
                tvActiveSectionBadge.text = "StreamX v18.1 • All Live TV"
                Toast.makeText(this@PlayerActivity, "File import failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showEpgGuideHubDialog() {
        val activeCh = allChannels.getOrNull(currentChannelIndex)
        val activeEpg = activeCh?.let { lookupEpgForChannel(it) }
        val activeDetail = activeCh?.let { lookupEpgDetailForChannel(it) }
        val options = ArrayList<GlassModalOption>(64)

        if (activeCh != null) {
            val nowText = activeDetail?.nowTitle ?: activeEpg?.first ?: Channel.DEFAULT_PROGRAM
            val nextText = activeDetail?.nextTitle ?: activeEpg?.second ?: Channel.DEFAULT_NEXT_PROGRAM
            val timeWin = activeDetail?.timeWindow?.takeIf { it.isNotBlank() }?.let { " ($it)" } ?: ""
            val progPct = activeDetail?.progressPercent ?: 100
            val descText = activeDetail?.description?.takeIf { it.isNotBlank() }
                ?.let { "$it  •  Next: $nextText" }
                ?: "Next Programme: $nextText"
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_live_tv,
                    title = "Now on ${activeCh.name}: $nowText$timeWin",
                    subtitle = descText,
                    badgeText = "LIVE $progPct%",
                    isHighlighted = true
                ) {
                    showZappingOsd()
                }
            )
        }

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_epg,
                title = "Load / Refresh XMLTV EPG Guide URL (.XML)",
                subtitle = "Configure or refresh your XMLTV Electronic Program Guide source",
                badgeText = if (epgMap.isNotEmpty()) "${epgMap.size} EPG" else "SET URL"
            ) {
                showEpgUrlDialog()
            }
        )

        if (allChannels.isNotEmpty()) {
            val startIdx = (currentChannelIndex - 5).coerceAtLeast(0)
            val endIdx = (startIdx + 40).coerceAtMost(allChannels.size)
            for (idx in startIdx until endIdx) {
                val ch = allChannels[idx]
                val epg = lookupEpgForChannel(ch)
                val detail = lookupEpgDetailForChannel(ch)
                val nowStr = detail?.nowTitle ?: epg?.first ?: Channel.DEFAULT_PROGRAM
                val nextStr = detail?.nextTitle ?: epg?.second ?: Channel.DEFAULT_NEXT_PROGRAM
                val winPrefix = detail?.timeWindow?.takeIf { it.isNotBlank() }?.let { "[$it] " } ?: ""
                val isCur = idx == currentChannelIndex
                options.add(
                    GlassModalOption(
                        iconRes = R.drawable.ic_3d_channels,
                        title = "${ch.displayNumberFormatted()} • ${ch.name}",
                        subtitle = "${winPrefix}Now: $nowStr  •  Next: $nextStr",
                        badgeText = if (isCur) "WATCHING ✓" else ch.category.take(10).uppercase(Locale.ROOT),
                        isHighlighted = isCur
                    ) {
                        activePlaybackMode = ActivePlaybackMode.LIVE_TV
                        switchChannel(idx, immediatePlayback = true)
                    }
                )
            }
        }

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_epg,
            title = "4D Electronic Program Guide (TV Guide)",
            subtitle = "Browse live Now/Next schedules with time windows or configure XMLTV EPG source",
            badgeText = if (epgMap.isNotEmpty()) "XMLTV ACTIVE" else "TV GUIDE",
            options = options,
            closeLabel = "Close"
        )
    }

    private fun showEpgUrlDialog() {
        val prefs = getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_epg,
            title = "Load XMLTV EPG Program Guide",
            subtitle = "Parsed Now/Next TV schedules are cached locally and refreshed automatically",
            badgeText = "XMLTV EPG",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "XMLTV EPG GUIDE URL (.XML)",
                    hint = "https://example.com/epg.xml",
                    iconRes = R.drawable.ic_3d_epg,
                    initialValue = prefs.getString("last_epg_url", "").orEmpty(),
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                )
            ),
            positiveLabel = "Load & Cache Guide",
            positiveBgRes = R.drawable.bg_btn_3d_teal,
            positiveIconRes = R.drawable.ic_3d_sync
        ) { values ->
            val url = ProfileStore.sanitizeExternalInput(values.firstOrNull().orEmpty())
            if (url.isNotBlank()) {
                prefs.edit().putString("last_epg_url", url).apply()
                loadXmltvEpg(url, silentBackground = false)
            }
        }
    }

    private fun loadXmltvEpg(url: String, silentBackground: Boolean = false) {
        epgLoadJob?.cancel()
        epgLoadJob = lifecycleScope.launch {
            if (!silentBackground) {
                Toast.makeText(this@PlayerActivity, "Loading EPG in background...", Toast.LENGTH_SHORT).show()
            }
            val filterIds = knownEpgAndChannelIds.takeIf { it.isNotEmpty() }
            runCatching {
                withContext(Dispatchers.IO) {
                    val request = Request.Builder()
                        .url(url)
                        .header("User-Agent", NetworkClient.DEFAULT_USER_AGENT)
                        .build()
                    NetworkClient.apiClient.newCall(request).execute().use { response ->
                        if (!response.isSuccessful) error("EPG HTTP ${response.code}")
                        val body = response.body ?: error("Empty EPG response")
                        BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 32768).use { reader ->
                            XmltvParser.parseNowNext(
                                reader = reader,
                                relevantChannelIds = filterIds,
                                shouldCancel = { !isActive }
                            )
                        }
                    }
                }
            }.onSuccess { parsedEpg ->
                if (parsedEpg.isNotEmpty()) {
                    epgMap = parsedEpg
                    launch(Dispatchers.IO) {
                        epgCache.saveEpg(url, parsedEpg)
                    }
                    if (allChannels.isNotEmpty()) updateOsdForCurrentChannel()
                }
                if (!silentBackground) {
                    Toast.makeText(this@PlayerActivity, "EPG cached: ${epgMap.size} channel entries", Toast.LENGTH_LONG).show()
                }
            }.onFailure { e ->
                Log.w("StreamX", "EPG load error", e)
                if (!silentBackground) {
                    Toast.makeText(this@PlayerActivity, "EPG error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun showProfilesDialog() {
        val profiles = profileStore.all()
        val activeId = profileStore.activeId()
        val options = ArrayList<GlassModalOption>(profiles.size + 8)

        profiles.forEach { p ->
            val isAct = p.id == activeId
            options.add(
                GlassModalOption(
                    iconRes = if (p.type == ProfileType.XTREAM) R.drawable.ic_3d_xtream else R.drawable.ic_3d_playlist,
                    title = p.name,
                    subtitle = "${p.type} Account • ${redactUrlForDisplay(p.source)}",
                    badgeText = if (isAct) "ACTIVE ✓" else "SWITCH",
                    isHighlighted = isAct
                ) {
                    activateProfile(p)
                }
            )
        }

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_accounts,
                title = "Add New Playlist / IPTV Account",
                subtitle = "Save an M3U URL or Xtream Codes VIP account with AES-256 encryption",
                badgeText = "+ NEW"
            ) {
                showAddProfileDialog()
            }
        )

        val currentCreds = activeXtreamCreds
        if (activeSourceType == ProfileType.XTREAM && currentCreds != null) {
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_movies,
                    title = "Refresh Xtream VOD Movies Catalog",
                    subtitle = "Fetch VOD Movies (`get_vod_streams`) from ${currentCreds.profileName}",
                    badgeText = "${vodMoviesCatalog.size} MOVIES"
                ) {
                    loadXtreamVodMovies(currentCreds, forceNetworkRefresh = true)
                }
            )
            options.add(
                GlassModalOption(
                    iconRes = R.drawable.ic_3d_series,
                    title = "Refresh Xtream Series Catalog",
                    subtitle = "Fetch Series (`get_series`) from ${currentCreds.profileName}",
                    badgeText = "${seriesCatalogGroups.size} SERIES"
                ) {
                    loadXtreamSeriesCatalog(currentCreds, forceNetworkRefresh = true)
                }
            )
        }

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_sync,
                title = "Force Sync Active Account from Server",
                subtitle = "Refresh active playlist from network and update SXB2 cache",
                badgeText = "SYNC"
            ) {
                forceRefreshActivePlaylist()
            }
        )

        val hasPin = profileStore.hasParentalPin()
        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_lock,
                title = "Parental PIN Lock Settings",
                subtitle = "Configure 4-digit PIN and lock specific categories",
                badgeText = if (hasPin) "LOCKED ✓" else "OFF",
                isHighlighted = hasPin
            ) {
                showParentalPinSettingsDialog()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_rocket,
                title = "Auto-Start on TV Boot",
                subtitle = "Automatically launch StreamX when Android TV starts",
                badgeText = if (autoBootEnabled) "ON ✓" else "OFF",
                isHighlighted = autoBootEnabled
            ) {
                toggleAutoBootSetting()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_live_tv,
                title = "Auto-Resume Last Channel",
                subtitle = "Automatically play your last watched channel on launch",
                badgeText = if (autoResumeEnabled) "ON ✓" else "OFF",
                isHighlighted = autoResumeEnabled
            ) {
                toggleAutoResumeSetting()
            }
        )

        options.add(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "Delete a Saved Account",
                subtitle = "Remove an existing M3U or Xtream profile and its isolated caches",
                badgeText = "REMOVE"
            ) {
                showDeleteProfileDialog()
            }
        )

        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_accounts,
            title = "Saved Accounts, Playlists & Boot Settings",
            subtitle = "Multi-account manager with strict Live/VOD/Series catalog isolation",
            badgeText = "${profiles.size} SAVED",
            options = options,
            closeLabel = "Close"
        )
    }

    private fun showAddProfileDialog() {
        val options = listOf(
            GlassModalOption(
                iconRes = R.drawable.ic_3d_playlist,
                title = "M3U / M3U8 Playlist Account (Live TV Only)",
                subtitle = "Add a remote M3U/M3U8 playlist link or raw #EXTM3U stream list for Live TV",
                badgeText = "M3U8 LIVE"
            ) {
                showSaveM3uProfileDialog()
            },
            GlassModalOption(
                iconRes = R.drawable.ic_3d_xtream,
                title = "Xtream Codes VIP Account (Live TV + VOD Movies + Series)",
                subtitle = "Connect with Server URL, Username & Password for independent Live, Movies & Series catalogs",
                badgeText = "VIP API",
                isHighlighted = true
            ) {
                showSaveXtreamProfileDialog()
            }
        )
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_accounts,
            title = "Choose IPTV Account Type",
            subtitle = "Select how you want to connect your television channels and VOD catalogs",
            badgeText = "NEW PROFILE",
            options = options,
            closeLabel = "Back"
        )
    }

    private fun showSaveM3uProfileDialog() {
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_playlist,
            title = "Save M3U / M3U8 Playlist Profile (Live TV)",
            subtitle = "Store Live TV playlist in SXB2 fast binary cache for instant startup",
            badgeText = "M3U PROFILE",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "PROFILE NAME",
                    hint = "Account name (e.g. Family Live TV)",
                    iconRes = R.drawable.ic_3d_accounts,
                    inputType = InputType.TYPE_CLASS_TEXT
                ),
                GlassFormFieldSpec(
                    label = "M3U / M3U8 URL OR #EXTM3U TEXT",
                    hint = "https://server.com/playlist.m3u8",
                    iconRes = R.drawable.ic_3d_server,
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                )
            ),
            positiveLabel = "Save & Play",
            positiveBgRes = R.drawable.bg_btn_3d_emerald,
            positiveIconRes = R.drawable.ic_3d_playlist
        ) { values ->
            val name = ProfileStore.sanitizeExternalInput(values.getOrNull(0).orEmpty())
            val source = ProfileStore.sanitizeExternalInput(values.getOrNull(1).orEmpty())
            if (name.isBlank() || source.isBlank()) {
                Toast.makeText(this, "Name and playlist are required", Toast.LENGTH_LONG).show()
            } else {
                val p = PlaylistProfile(name = name, type = ProfileType.M3U, source = source)
                profileStore.save(p); profileStore.setActive(p.id); activateProfile(p)
            }
        }
    }

    private fun showSaveXtreamProfileDialog() {
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_xtream,
            title = "Save Xtream Codes VIP Account",
            subtitle = "Credentials are encrypted with AES-256 and load independent Live, Movies & Series catalogs",
            badgeText = "VIP XTREAM",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "ACCOUNT / PROFILE NAME",
                    hint = "Account name (e.g. Sports & Cinema VIP)",
                    iconRes = R.drawable.ic_3d_accounts,
                    inputType = InputType.TYPE_CLASS_TEXT
                ),
                GlassFormFieldSpec(
                    label = "XTREAM SERVER URL & PORT",
                    hint = "http://line.server.com:8080",
                    iconRes = R.drawable.ic_3d_server,
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                ),
                GlassFormFieldSpec(
                    label = "USERNAME",
                    hint = "Enter Xtream Username",
                    iconRes = R.drawable.ic_3d_user,
                    inputType = InputType.TYPE_CLASS_TEXT
                ),
                GlassFormFieldSpec(
                    label = "PASSWORD",
                    hint = "Enter Xtream Password",
                    iconRes = R.drawable.ic_3d_lock,
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                )
            ),
            positiveLabel = "Save & Play",
            positiveBgRes = R.drawable.bg_btn_3d_cyan,
            positiveIconRes = R.drawable.ic_3d_xtream
        ) { values ->
            val name = ProfileStore.sanitizeExternalInput(values.getOrNull(0).orEmpty())
            val server = ProfileStore.sanitizeExternalInput(values.getOrNull(1).orEmpty())
            val user = ProfileStore.sanitizeExternalInput(values.getOrNull(2).orEmpty())
            val pass = ProfileStore.sanitizeExternalInput(values.getOrNull(3).orEmpty())
            if (name.isBlank() || server.isBlank() || user.isBlank() || pass.isBlank()) {
                Toast.makeText(this, "All fields are required", Toast.LENGTH_LONG).show()
            } else {
                val p = PlaylistProfile(
                    name = name,
                    type = ProfileType.XTREAM,
                    source = server,
                    username = user,
                    password = pass
                )
                profileStore.save(p); profileStore.setActive(p.id); activateProfile(p)
            }
        }
    }

    private fun showDeleteProfileDialog() {
        val profiles = profileStore.all()
        if (profiles.isEmpty()) {
            Toast.makeText(this, "No saved accounts", Toast.LENGTH_SHORT).show()
            return
        }
        val options = profiles.map { p ->
            GlassModalOption(
                iconRes = R.drawable.ic_3d_trash,
                title = "Delete: ${p.name}",
                subtitle = "${p.type} • ${redactUrlForDisplay(p.source)}",
                badgeText = "DELETE"
            ) {
                profileStore.delete(p.id)
                if (profileStore.activeId() == p.id) {
                    val next = profileStore.all().firstOrNull()
                    if (next != null) {
                        profileStore.setActive(next.id)
                        activateProfile(next)
                    } else {
                        clearVodAndSeriesCatalogsForAccountSwitch()
                        Toast.makeText(this, "Account deleted. Add a playlist to start.", Toast.LENGTH_LONG).show()
                    }
                }
                showProfilesDialog()
            }
        }
        show4dGlassListModal(
            headerIconRes = R.drawable.ic_3d_trash,
            title = "Delete Saved Account",
            subtitle = "Select an account below to permanently remove it",
            badgeText = "${profiles.size} ACCOUNTS",
            options = options,
            closeLabel = "Cancel"
        )
    }

    private fun activateProfile(profile: PlaylistProfile) {
        recordCurrentVodOrSeriesProgress()
        xtreamRepo.cancelActiveFetch()
        loadChannelsJob?.cancel()
        clearVodAndSeriesCatalogsForAccountSwitch()

        profileStore.setActive(profile.id)
        activeAccountScope = profile.id
        tvActiveSectionBadge.text = "StreamX v18.1 • ${profile.name}"
        when (profile.type) {
            ProfileType.M3U -> {
                activeXtreamCreds = null
                loadM3uFromInput(profile.source, profile.name, forceNetworkRefresh = false, scopeOverride = profile.id)
            }
            ProfileType.XTREAM -> {
                val creds = XtreamCredentials(profile.name, profile.source, profile.username, profile.password)
                loadXtreamChannels(creds, forceNetworkRefresh = false, scopeOverride = profile.id)
            }
        }
    }

    private fun showXtreamLoginDialog() {
        val prefs = getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_xtream,
            title = "Xtream Codes VIP Login",
            subtitle = "Independent Live TV (`get_live_streams`), Movies (`get_vod_streams`) & Series (`get_series`)",
            badgeText = "VIP HD",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "SERVER URL & PORT",
                    hint = "Server URL (e.g. http://line.server.com:8080)",
                    iconRes = R.drawable.ic_3d_server,
                    initialValue = prefs.getString("xtream_server", "").orEmpty(),
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                ),
                GlassFormFieldSpec(
                    label = "USERNAME",
                    hint = "Username",
                    iconRes = R.drawable.ic_3d_user,
                    initialValue = prefs.getString("xtream_user", "").orEmpty(),
                    inputType = InputType.TYPE_CLASS_TEXT
                ),
                GlassFormFieldSpec(
                    label = "PASSWORD",
                    hint = "Password",
                    iconRes = R.drawable.ic_3d_lock,
                    initialValue = prefs.getString("xtream_pass", "").orEmpty(),
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                )
            ),
            positiveLabel = "Connect & Play",
            positiveBgRes = R.drawable.bg_btn_3d_cyan,
            positiveIconRes = R.drawable.ic_3d_xtream
        ) { values ->
            val srv = ProfileStore.sanitizeExternalInput(values.getOrNull(0).orEmpty())
            val usr = ProfileStore.sanitizeExternalInput(values.getOrNull(1).orEmpty())
            val pwd = ProfileStore.sanitizeExternalInput(values.getOrNull(2).orEmpty())
            if (srv.isNotEmpty() && usr.isNotEmpty()) {
                prefs.edit()
                    .putString("xtream_server", srv)
                    .putString("xtream_user", usr)
                    .putString("xtream_pass", pwd)
                    .apply()
                clearVodAndSeriesCatalogsForAccountSwitch()
                val creds = XtreamCredentials("Xtream VIP", srv, usr, pwd)
                loadXtreamChannels(creds, forceNetworkRefresh = true)
            }
        }
    }

    // =========================================================================
    // v18.1 STRICTLY SEPARATED XTREAM LIVE TV, VOD MOVIES & SERIES LOADERS
    // =========================================================================

    private fun xtreamScopeKey(creds: XtreamCredentials): String =
        cacheKeyFor("xtream_${creds.serverUrl.trim()}_${creds.username.trim()}")

    private fun loadXtreamChannels(
        creds: XtreamCredentials,
        forceNetworkRefresh: Boolean = false,
        scopeOverride: String? = null
    ) {
        activeSourceType = ProfileType.XTREAM
        activeXtreamCreds = creds
        val baseKey = xtreamScopeKey(creds)
        activeAccountScope = scopeOverride ?: baseKey
        val liveCacheKey = "live_$baseKey"

        xtreamRepo.cancelActiveFetch()
        loadChannelsJob?.cancel()
        loadChannelsJob = lifecycleScope.launch {
            val t0 = SystemClock.elapsedRealtime()

            // Restore cached VOD Movies & Series for this specific Xtream account in background
            preloadCachedXtreamVodAndSeries(creds)

            // 1. Fast SXB2 Live TV Cache Load + Progressive 80-Channel First Batch
            if (!forceNetworkRefresh) {
                updateBootStage(68, "Restoring Fast SXB2 Live TV Cache...", "Account: ${creds.profileName}")
                val cachedLive = channelCache.loadChannels(
                    key = liveCacheKey,
                    maxLimit = maxPlaylistLimit,
                    defaultSourceType = ContentSourceType.XTREAM_LIVE
                ) { firstBatch ->
                    withContext(Dispatchers.Main) {
                        if (currentPlayingStreamUrl.isEmpty()) {
                            applyLoadedChannels(
                                firstBatch,
                                "StreamX v18.1 • ⚡ ${creds.profileName} (${firstBatch.size}+ Live)",
                                resumeLastWatched = false,
                                isPreliminaryBatch = true
                            )
                        }
                    }
                }
                if (cachedLive.isNotEmpty()) {
                    lastPlaylistLoadDurationMs = SystemClock.elapsedRealtime() - t0
                    applyLoadedChannels(
                        cachedLive,
                        "StreamX v18.1 • ⚡ ${creds.profileName} (${cachedLive.size} Live)",
                        resumeLastWatched = true
                    )
                    if (isNetworkConnectedNow() && channelCache.isCacheStale(liveCacheKey)) {
                        scheduleSilentXtreamRefresh(creds, liveCacheKey)
                    }
                    return@launch
                }
            }

            // 2. Network Live TV Stream Load (`get_live_streams` ONLY)
            updateBootStage(70, "Loading Live TV from Xtream Server...", "Connecting to ${NetworkClient.redactSensitiveUrl(creds.serverUrl)}")
            tvActiveSectionBadge.text = "⏳ Loading Xtream Live TV..."
            val res = xtreamRepo.fetchLiveStreams(creds, maxStreams = maxPlaylistLimit) { firstBatch ->
                withContext(Dispatchers.Main) {
                    updateBootStage(76, "Loaded first ${firstBatch.size} live channels...", "Playing immediately while streaming list")
                    applyLoadedChannels(
                        firstBatch,
                        "StreamX v18.1 • ⏳ ${creds.profileName} (${firstBatch.size}+ Live)",
                        resumeLastWatched = false,
                        isPreliminaryBatch = true
                    )
                }
            }
            res.onSuccess { list ->
                lastPlaylistLoadDurationMs = SystemClock.elapsedRealtime() - t0
                if (list.isNotEmpty()) {
                    applyLoadedChannels(
                        list,
                        "StreamX v18.1 • ${creds.profileName} (${list.size} Live)",
                        resumeLastWatched = true
                    )
                    launch(Dispatchers.IO) {
                        channelCache.saveChannels(liveCacheKey, list, maxLimit = maxPlaylistLimit)
                    }
                    Toast.makeText(
                        this@PlayerActivity,
                        "Xtream Live TV Cached (${list.size} channels)!",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    dismissDthBootOverlay("NO CHANNELS FOUND")
                    tvActiveSectionBadge.text = "StreamX v18.1 • No Live Channels"
                    Toast.makeText(this@PlayerActivity, "No live channels found on server", Toast.LENGTH_LONG).show()
                }
            }.onFailure { err ->
                Log.w("StreamX", "Xtream live load error", err)
                val fallbackCached = channelCache.loadChannels(
                    key = liveCacheKey,
                    maxLimit = maxPlaylistLimit,
                    defaultSourceType = ContentSourceType.XTREAM_LIVE
                )
                if (fallbackCached.isNotEmpty()) {
                    applyLoadedChannels(
                        fallbackCached,
                        "StreamX v18.1 • ⚡ ${creds.profileName} (${fallbackCached.size} Live)",
                        resumeLastWatched = true
                    )
                } else {
                    dismissDthBootOverlay("CONNECTION ERROR")
                    tvActiveSectionBadge.text = "StreamX v18.1 • Connection Error"
                    Toast.makeText(this@PlayerActivity, "Xtream Error: ${err.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun preloadCachedXtreamVodAndSeries(creds: XtreamCredentials) {
        val baseKey = xtreamScopeKey(creds)
        val vodCacheKey = "vod_$baseKey"
        val seriesCacheKey = "series_$baseKey"

        lifecycleScope.launch(Dispatchers.IO) {
            val cachedVod = channelCache.loadChannels(
                key = vodCacheKey,
                maxLimit = 25_000,
                defaultSourceType = ContentSourceType.XTREAM_VOD_MOVIE
            ).filter { it.sourceType == ContentSourceType.XTREAM_VOD_MOVIE }

            if (cachedVod.isNotEmpty()) {
                val byId = HashMap<String, Int>(cachedVod.size)
                for (i in cachedVod.indices) byId[cachedVod[i].id] = i
                withContext(Dispatchers.Main) {
                    if (activeXtreamCreds == creds && vodMoviesCatalog.isEmpty()) {
                        vodMoviesCatalog = cachedVod
                        vodMovieIndexById = byId
                    }
                }
            }

            val cachedSeries = channelCache.loadChannels(
                key = seriesCacheKey,
                maxLimit = 15_000,
                defaultSourceType = ContentSourceType.XTREAM_SERIES
            ).filter { it.sourceType == ContentSourceType.XTREAM_SERIES }

            if (cachedSeries.isNotEmpty()) {
                val groups = MediaCatalogEngine.buildXtreamSeriesGroups(cachedSeries)
                withContext(Dispatchers.Main) {
                    if (activeXtreamCreds == creds && seriesCatalogGroups.isEmpty()) {
                        seriesCatalogRaw = cachedSeries
                        seriesCatalogGroups = groups
                    }
                }
            }
        }
    }

    /**
     * Loads Xtream VOD Movies (`get_vod_categories` + `get_vod_streams`) into `vodMoviesCatalog` ONLY.
     * NEVER modifies or overwrites `allChannels` (Live TV)!
     */
    private fun loadXtreamVodMovies(creds: XtreamCredentials, forceNetworkRefresh: Boolean = false) {
        val baseKey = xtreamScopeKey(creds)
        val vodCacheKey = "vod_$baseKey"

        vodCatalogLoadJob?.cancel()
        vodCatalogLoadJob = lifecycleScope.launch {
            if (!forceNetworkRefresh) {
                val cachedVod = channelCache.loadChannels(
                    key = vodCacheKey,
                    maxLimit = 25_000,
                    defaultSourceType = ContentSourceType.XTREAM_VOD_MOVIE
                ).filter { it.sourceType == ContentSourceType.XTREAM_VOD_MOVIE }

                if (cachedVod.isNotEmpty()) {
                    applyLoadedVodMoviesCatalog(cachedVod)
                    return@launch
                }
            }

            Toast.makeText(this@PlayerActivity, "🎬 Loading VOD Movies from Xtream...", Toast.LENGTH_SHORT).show()
            val res = xtreamRepo.fetchVodStreams(creds, maxStreams = 25_000, startingNumber = 1)
            res.onSuccess { movies ->
                val strictMovies = movies.filter { it.sourceType == ContentSourceType.XTREAM_VOD_MOVIE }
                applyLoadedVodMoviesCatalog(strictMovies)
                if (strictMovies.isNotEmpty()) {
                    launch(Dispatchers.IO) {
                        channelCache.saveChannels(vodCacheKey, strictMovies, maxLimit = 25_000)
                    }
                    Toast.makeText(this@PlayerActivity, "🎬 Loaded ${strictMovies.size} VOD Movies!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@PlayerActivity, "No VOD Movies returned by this Xtream server", Toast.LENGTH_SHORT).show()
                }
            }.onFailure { e ->
                Toast.makeText(this@PlayerActivity, "VOD Movies Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun applyLoadedVodMoviesCatalog(movies: List<Channel>) {
        val byId = HashMap<String, Int>(movies.size)
        for (i in movies.indices) {
            byId[movies[i].id] = i
        }
        vodMoviesCatalog = movies
        vodMovieIndexById = byId
        if (vodPosterGridPanel.visibility == View.VISIBLE && activeEntertainmentSection == EntertainmentSection.MOVIES) {
            val sidebarItems = buildVodSidebarCategories(EntertainmentSection.MOVIES)
            vodSidebarAdapter.submitCategories(sidebarItems, selectedVodCategory)
            renderVodPosterGrid()
        }
    }

    /**
     * Loads Xtream Series (`get_series_categories` + `get_series`) into `seriesCatalogGroups` ONLY.
     * NEVER modifies or overwrites `allChannels` (Live TV)!
     */
    private fun loadXtreamSeriesCatalog(creds: XtreamCredentials, forceNetworkRefresh: Boolean = false) {
        val baseKey = xtreamScopeKey(creds)
        val seriesCacheKey = "series_$baseKey"

        seriesCatalogLoadJob?.cancel()
        seriesCatalogLoadJob = lifecycleScope.launch {
            if (!forceNetworkRefresh) {
                val cachedSeries = channelCache.loadChannels(
                    key = seriesCacheKey,
                    maxLimit = 15_000,
                    defaultSourceType = ContentSourceType.XTREAM_SERIES
                ).filter { it.sourceType == ContentSourceType.XTREAM_SERIES }

                if (cachedSeries.isNotEmpty()) {
                    applyLoadedSeriesCatalog(cachedSeries)
                    return@launch
                }
            }

            Toast.makeText(this@PlayerActivity, "📺 Loading Series Catalog from Xtream...", Toast.LENGTH_SHORT).show()
            val res = xtreamRepo.fetchSeriesCatalog(creds, maxSeries = 15_000, startingNumber = 1)
            res.onSuccess { seriesEntries ->
                val strictSeries = seriesEntries.filter { it.sourceType == ContentSourceType.XTREAM_SERIES }
                applyLoadedSeriesCatalog(strictSeries)
                if (strictSeries.isNotEmpty()) {
                    launch(Dispatchers.IO) {
                        channelCache.saveChannels(seriesCacheKey, strictSeries, maxLimit = 15_000)
                    }
                    Toast.makeText(this@PlayerActivity, "📺 Loaded ${strictSeries.size} Series!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@PlayerActivity, "No Series returned by this Xtream server", Toast.LENGTH_SHORT).show()
                }
            }.onFailure { e ->
                Toast.makeText(this@PlayerActivity, "Series Load Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun applyLoadedSeriesCatalog(seriesEntries: List<Channel>) {
        seriesCatalogRaw = seriesEntries
        seriesCatalogGroups = MediaCatalogEngine.buildXtreamSeriesGroups(seriesEntries)
        if (vodPosterGridPanel.visibility == View.VISIBLE && activeEntertainmentSection == EntertainmentSection.SERIES) {
            val sidebarItems = buildVodSidebarCategories(EntertainmentSection.SERIES)
            vodSidebarAdapter.submitCategories(sidebarItems, selectedVodCategory)
            renderVodPosterGrid()
        }
    }

    private fun scheduleSilentXtreamRefresh(creds: XtreamCredentials, liveCacheKey: String) {
        bgSyncJob?.cancel()
        bgSyncJob = lifecycleScope.launch(Dispatchers.IO) {
            delay(4000L)
            val res = xtreamRepo.fetchLiveStreams(creds, maxStreams = maxPlaylistLimit)
            res.onSuccess { freshList ->
                if (freshList.isNotEmpty()) {
                    channelCache.saveChannels(liveCacheKey, freshList, maxLimit = maxPlaylistLimit)
                }
            }
        }
    }

    private fun showM3uLoadDialog() {
        val prefs = getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
        show4dGlassFormModal(
            headerIconRes = R.drawable.ic_3d_playlist,
            title = "Load M3U / M3U8 Live TV Playlist",
            subtitle = "Stream Live TV channels from URL, paste raw #EXTM3U content, or pick a local .m3u/.m3u8 file",
            badgeText = "LIVE TV ONLY",
            fields = listOf(
                GlassFormFieldSpec(
                    label = "M3U / M3U8 PLAYLIST URL OR #EXTM3U CONTENT",
                    hint = "Paste M3U URL (https://.../playlist.m3u) or #EXTM3U",
                    iconRes = R.drawable.ic_3d_server,
                    initialValue = prefs.getString("m3u_url", "").orEmpty(),
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                )
            ),
            neutralLabel = "Choose Local File",
            neutralBgRes = R.drawable.bg_btn_3d_emerald,
            neutralIconRes = R.drawable.ic_3d_playlist,
            onNeutral = {
                playlistPicker.launch(arrayOf("application/x-mpegURL", "audio/x-mpegurl", "text/plain", "*/*"))
            },
            positiveLabel = "Load Live TV",
            positiveBgRes = R.drawable.bg_btn_3d_cyan,
            positiveIconRes = R.drawable.ic_3d_sync
        ) { values ->
            val input = ProfileStore.sanitizeExternalInput(values.firstOrNull().orEmpty())
            if (input.isNotEmpty()) {
                prefs.edit().putString("m3u_url", input).apply()
                loadM3uFromInput(input, "M3U Live TV", forceNetworkRefresh = true)
            }
        }
    }

    /**
     * Loads M3U/M3U8 playlist strictly into Live TV (`allChannels`).
     * Clears any VOD Movies or Series catalogs so M3U profiles show a clean empty state in Movies & Series.
     */
    private fun loadM3uFromInput(
        input: String,
        label: String = "M3U",
        forceNetworkRefresh: Boolean = false,
        scopeOverride: String? = null
    ) {
        xtreamRepo.cancelActiveFetch()
        loadChannelsJob?.cancel()
        clearVodAndSeriesCatalogsForAccountSwitch()

        activeSourceType = ProfileType.M3U
        activeXtreamCreds = null
        activeM3uInput = input
        activeM3uLabel = label
        val cKey = cacheKeyFor("m3u_live_${input.take(256)}")
        activeAccountScope = scopeOverride ?: cKey

        loadChannelsJob = lifecycleScope.launch {
            val t0 = SystemClock.elapsedRealtime()
            if (!forceNetworkRefresh) {
                updateBootStage(68, "Restoring Fast SXB2 Live TV Cache...", label)
                val cached = channelCache.loadChannels(
                    key = cKey,
                    maxLimit = maxPlaylistLimit,
                    defaultSourceType = ContentSourceType.M3U_LIVE
                ) { firstBatch ->
                    withContext(Dispatchers.Main) {
                        if (currentPlayingStreamUrl.isEmpty()) {
                            applyLoadedChannels(
                                firstBatch,
                                "StreamX v18.1 • ⚡ $label (${firstBatch.size}+ CH)",
                                resumeLastWatched = false,
                                isPreliminaryBatch = true
                            )
                        }
                    }
                }
                if (cached.isNotEmpty()) {
                    lastPlaylistLoadDurationMs = SystemClock.elapsedRealtime() - t0
                    applyLoadedChannels(
                        cached,
                        "StreamX v18.1 • ⚡ $label (${cached.size} CH)",
                        resumeLastWatched = true
                    )
                    if (isNetworkConnectedNow() &&
                        (input.startsWith("http://", true) || input.startsWith("https://", true)) &&
                        channelCache.isCacheStale(cKey)
                    ) {
                        scheduleSilentM3uRefresh(input, cKey)
                    }
                    return@launch
                }
            }

            updateBootStage(72, "Loading M3U Live TV Playlist...", label)
            tvActiveSectionBadge.text = "⏳ Loading M3U Live TV..."
            try {
                val parsed = withContext(Dispatchers.IO) {
                    val emitFirstBatch: (List<Channel>) -> Unit = { batch ->
                        lifecycleScope.launch(Dispatchers.Main) {
                            if (currentPlayingStreamUrl.isEmpty()) {
                                applyLoadedChannels(
                                    batch,
                                    "StreamX v18.1 • ⏳ $label (${batch.size}+ CH)",
                                    resumeLastWatched = false,
                                    isPreliminaryBatch = true
                                )
                            }
                        }
                    }
                    when {
                        input.startsWith("http://", true) || input.startsWith("https://", true) -> {
                            val req = Request.Builder()
                                .url(input)
                                .header("User-Agent", NetworkClient.DEFAULT_USER_AGENT)
                                .build()
                            NetworkClient.apiClient.newCall(req).execute().use { res ->
                                if (!res.isSuccessful) error("Playlist HTTP ${res.code}")
                                val body = res.body ?: error("Empty M3U response")
                                BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 65536).use { reader ->
                                    M3uParser.parse(reader, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive }, onFirstBatch = emitFirstBatch)
                                }
                            }
                        }
                        input.startsWith("file://", true) -> {
                            val file = File(Uri.parse(input).path ?: "")
                            if (!file.exists()) error("Saved playlist file not found")
                            file.bufferedReader(Charsets.UTF_8).use { reader ->
                                M3uParser.parse(reader, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive }, onFirstBatch = emitFirstBatch)
                            }
                        }
                        input.startsWith("content://", true) -> {
                            contentResolver.openInputStream(Uri.parse(input))?.bufferedReader(Charsets.UTF_8)?.use { reader ->
                                M3uParser.parse(reader, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive }, onFirstBatch = emitFirstBatch)
                            } ?: emptyList()
                        }
                        else -> M3uParser.parse(input, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive }, onFirstBatch = emitFirstBatch)
                    }
                }
                lastPlaylistLoadDurationMs = SystemClock.elapsedRealtime() - t0
                if (parsed.isNotEmpty()) {
                    applyLoadedChannels(
                        parsed,
                        "StreamX v18.1 • $label (${parsed.size} CH)",
                        resumeLastWatched = true
                    )
                    launch(Dispatchers.IO) {
                        channelCache.saveChannels(cKey, parsed, maxLimit = maxPlaylistLimit)
                    }
                    Toast.makeText(this@PlayerActivity, "M3U Live TV Cached (${parsed.size} CH)!", Toast.LENGTH_SHORT).show()
                } else {
                    dismissDthBootOverlay("NO CHANNELS FOUND")
                    tvActiveSectionBadge.text = "StreamX v18.1 • All Live TV"
                    Toast.makeText(this@PlayerActivity, "No valid channels found in M3U", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Log.w("StreamX", "M3U load error", e)
                val fallbackCached = channelCache.loadChannels(
                    key = cKey,
                    maxLimit = maxPlaylistLimit,
                    defaultSourceType = ContentSourceType.M3U_LIVE
                )
                if (fallbackCached.isNotEmpty()) {
                    applyLoadedChannels(
                        fallbackCached,
                        "StreamX v18.1 • ⚡ $label (${fallbackCached.size} CH)",
                        resumeLastWatched = true
                    )
                } else {
                    dismissDthBootOverlay("CONNECTION ERROR")
                    tvActiveSectionBadge.text = "StreamX v18.1 • M3U Error"
                    Toast.makeText(this@PlayerActivity, "M3U Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun scheduleSilentM3uRefresh(url: String, cKey: String) {
        bgSyncJob?.cancel()
        bgSyncJob = lifecycleScope.launch(Dispatchers.IO) {
            delay(4000L)
            runCatching {
                val req = Request.Builder()
                    .url(url)
                    .header("User-Agent", NetworkClient.DEFAULT_USER_AGENT)
                    .build()
                NetworkClient.apiClient.newCall(req).execute().use { res ->
                    if (!res.isSuccessful) return@use
                    val body = res.body ?: return@use
                    val parsed = BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8), 65536).use { reader ->
                        M3uParser.parse(reader, maxChannels = maxPlaylistLimit, shouldCancel = { !isActive })
                    }
                    if (parsed.isNotEmpty()) {
                        channelCache.saveChannels(cKey, parsed, maxLimit = maxPlaylistLimit)
                    }
                }
            }
        }
    }

    private suspend fun restoreSavedDataFromBoot(prefs: android.content.SharedPreferences, hasNet: Boolean) {
        if (!autoResumeEnabled) {
            updateBootStage(90, "Preparing Live Television...", "Starting default stream")
            switchChannel(0, immediatePlayback = true)
            dismissDthBootOverlay("READY TO ADD PLAYLIST")
            return
        }

        if (prefs.getBoolean("has_saved_profiles", false)) {
            val savedProfiles = withContext(Dispatchers.IO) { profileStore.all() }
            val activeId = withContext(Dispatchers.IO) { profileStore.activeId() }
            val active = savedProfiles.firstOrNull { it.id == activeId } ?: savedProfiles.firstOrNull()
            if (active != null) {
                profileStore.setActive(active.id)
                if (!hasNet) {
                    updateBootStage(70, "Network unavailable – Loading saved channels.", active.name)
                }
                activateProfile(active)
                return
            }
        }

        val srv = prefs.getString("xtream_server", "") ?: ""
        val usr = prefs.getString("xtream_user", "") ?: ""
        val pwd = prefs.getString("xtream_pass", "") ?: ""
        val m3u = prefs.getString("m3u_url", "") ?: ""
        if (srv.isNotEmpty() && usr.isNotEmpty()) {
            loadXtreamChannels(XtreamCredentials("Saved", srv, usr, pwd), forceNetworkRefresh = false)
        } else if (m3u.isNotEmpty()) {
            loadM3uFromInput(m3u, "Saved M3U", forceNetworkRefresh = false)
        } else {
            updateBootStage(90, "Preparing Live Television...", "Ready to Watch")
            switchChannel(0, immediatePlayback = true)
            dismissDthBootOverlay("READY TO ADD PLAYLIST")
        }
    }

    private fun updateOsdForCurrentChannel() {
        if (allChannels.isEmpty() || currentChannelIndex !in allChannels.indices) return
        val channel = allChannels[currentChannelIndex]
        tvChannelNumber.text = channel.displayNumberFormatted()
        tvChannelName.text = channel.name
        if (channel.logoUrl.isNotBlank() && !isDestroyed && !isFinishing) {
            Glide.with(this)
                .load(channel.logoUrl)
                .apply(logoRequestOptions)
                .into(channelLogo)
        } else {
            channelLogo.setImageResource(R.drawable.ic_3d_live_tv)
        }
        val epg = lookupEpgForChannel(channel)
        val epgDetail = lookupEpgDetailForChannel(channel)
        val telemetrySuffix = if (liveTelemetryDetail.isNotEmpty()) " • $liveTelemetryDetail" else ""
        tvChannelCategory.text = "${channel.category} • $liveResolutionLabel$telemetrySuffix • $liveStatusLabel"
        val nowTitle = epgDetail?.nowTitle ?: epg?.first ?: Channel.DEFAULT_PROGRAM
        val nextTitle = epgDetail?.nextTitle ?: epg?.second ?: Channel.DEFAULT_NEXT_PROGRAM
        tvEpgNow.text = "Now: $nowTitle  •  Next: $nextTitle  •  CH ${currentChannelIndex + 1}/${allChannels.size}"
        if (epgDetail != null && liveStatusLabel.startsWith("🟢")) {
            osdLiveProgressBar.progress = epgDetail.progressPercent
        }
        updateFavButtonUi(channel.id)
    }

    // Ultra-Fast Zap: Fires ExoPlayer preparation FIRST on millisecond 0 before UI/Glide updates!
    private fun switchChannel(newIndex: Int, immediatePlayback: Boolean = false) {
        if (allChannels.isEmpty()) return
        val resolvedIndex = ((newIndex % allChannels.size) + allChannels.size) % allChannels.size
        val targetChannel = allChannels[resolvedIndex]

        if (::profileStore.isInitialized &&
            profileStore.isCategoryLocked(targetChannel.category) &&
            !unlockedSessionCategories.contains(targetChannel.category.lowercase(Locale.ROOT))
        ) {
            promptParentalPinToUnlock(targetChannel.category) {
                switchChannel(resolvedIndex, immediatePlayback = true)
            }
            return
        }

        recordCurrentVodOrSeriesProgress()
        activePlaybackMode = ActivePlaybackMode.LIVE_TV

        if (resolvedIndex != currentChannelIndex) {
            lastZapForward = resolvedIndex > currentChannelIndex ||
                (currentChannelIndex == allChannels.lastIndex && resolvedIndex == 0)
            previousChannelIndex = currentChannelIndex
        }
        currentChannelIndex = resolvedIndex
        val channel = allChannels[currentChannelIndex]
        playbackRetryCount = 0
        stallRecoveryCount = 0
        usingBackupStream = false
        liveTelemetryDetail = ""
        val nowElapsed = SystemClock.elapsedRealtime()
        lastKeyPressToSelectionMs = if (lastRemoteKeyPressElapsedMs in (nowElapsed - 1000L)..nowElapsed) {
            (nowElapsed - lastRemoteKeyPressElapsedMs).coerceAtLeast(1L)
        } else {
            1L
        }
        lastSwitchStartElapsedMs = nowElapsed
        liveStatusLabel = "⚡ Zapping..."
        osdLiveProgressBar.progress = 35

        StreamPreFetcher.notifyChannelSwitched(channel.streamUrl, lastZapForward)
        uiHandler.removeCallbacks(stallWatchdogRunnable)
        uiHandler.removeCallbacks(retryPlaybackRunnable)
        uiHandler.removeCallbacks(commitPlaybackRunnable)

        activePlaybackToken++
        val switchToken = activePlaybackToken

        // 1. Fire Media3 ExoPlayer immediately BEFORE any UI/Glide work for minimum zapping latency!
        if (immediatePlayback) {
            startPlaybackForCurrentChannel(forceReload = false)
        } else {
            pendingCommitToken = switchToken
            uiHandler.postDelayed(commitPlaybackRunnable, 25L)
        }
        lastSelectionToPrepareMs = (SystemClock.elapsedRealtime() - nowElapsed).coerceAtLeast(1L)

        // 2. Update OSD and Recent list asynchronously
        recentIds.remove(channel.id)
        recentIds.add(0, channel.id)
        if (recentIds.size > 20) recentIds.removeAt(recentIds.lastIndex)
        uiHandler.removeCallbacks(persistStateRunnable)
        uiHandler.postDelayed(persistStateRunnable, 600L)

        updateOsdForCurrentChannel()
        showZappingOsd()

        if (leftChannelDrawer.visibility == View.VISIBLE && activeTab == "RECENT") {
            renderDrawerList()
        } else {
            channelAdapter.updateActiveChannel(currentChannelIndex)
        }
    }

    private fun startPlaybackForCurrentChannel(forceReload: Boolean = false) {
        if (allChannels.isEmpty() || currentChannelIndex !in allChannels.indices) return
        val channel = allChannels[currentChannelIndex]
        if (::profileStore.isInitialized) {
            val savedLang = profileStore.getPreferredAudioLanguage(channel.id)
            if (!savedLang.isNullOrBlank()) {
                exoPlayer?.let { player ->
                    player.trackSelectionParameters = player.trackSelectionParameters
                        .buildUpon()
                        .setPreferredAudioLanguages(savedLang, "hi", "hin", "en", "eng")
                        .build()
                }
            }
        }
        playSpecificStreamUrl(channel.streamUrl, forceReload = forceReload)
    }

    private fun lookupEpgForChannel(channel: Channel): Pair<String, String>? {
        if (epgMap.isEmpty()) return null
        val primaryKey = channel.epgId.ifBlank { channel.id }
        epgMap[primaryKey]?.let { return it }
        epgMap[primaryKey.lowercase(Locale.ROOT)]?.let { return it }
        val normPrimary = XmltvParser.normalizeEpgKey(primaryKey)
        if (normPrimary.isNotEmpty()) {
            epgMap[normPrimary]?.let { return it }
        }
        if (channel.name.isNotBlank()) {
            epgMap[channel.name.lowercase(Locale.ROOT)]?.let { return it }
            val normName = XmltvParser.normalizeEpgKey(channel.name)
            if (normName.isNotEmpty()) {
                epgMap[normName]?.let { return it }
            }
        }
        return null
    }

    private fun lookupEpgDetailForChannel(channel: Channel): EpgProgrammeDetail? {
        val primaryKey = channel.epgId.ifBlank { channel.id }
        XmltvParser.getProgrammeDetail(primaryKey)?.let { return it }
        if (channel.name.isNotBlank()) {
            XmltvParser.getProgrammeDetail(channel.name)?.let { return it }
        }
        return null
    }

    private fun redactUrlForDisplay(raw: String): String {
        return NetworkClient.redactSensitiveUrl(raw).take(48)
    }

    private fun playSpecificStreamUrl(targetUrl: String, forceReload: Boolean = false) {
        exoPlayer?.let { player ->
            if (!forceReload &&
                currentPlayingStreamUrl == targetUrl &&
                (player.playbackState == Player.STATE_READY || player.playbackState == Player.STATE_BUFFERING)
            ) {
                player.playWhenReady = true
                return
            }
            currentPlayingStreamUrl = targetUrl

            // Preload-to-Playback Handoff: Reuse prepared MediaSource if available and fresh
            val preloadedSource = if (!forceReload && activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                StreamPreFetcher.consumePreparedMediaSource(targetUrl)
            } else {
                null
            }
            if (preloadedSource != null) {
                lastSwitchUsedPreload = true
                player.setMediaSource(preloadedSource, true)
                player.prepare()
                player.playWhenReady = true
                return
            }

            lastSwitchUsedPreload = false
            val mediaItem = StreamPreFetcher.buildLiveMediaItem(targetUrl)
            val hlsFactory = hlsChunklessFactory
            val defFactory = defaultMediaSourceFactory
            if (hlsFactory != null && StreamPreFetcher.detectStreamFormat(targetUrl) == StreamPreFetcher.StreamFormat.HLS) {
                player.setMediaSource(hlsFactory.createMediaSource(mediaItem), true)
            } else if (defFactory != null) {
                player.setMediaSource(defFactory.createMediaSource(mediaItem), true)
            } else {
                player.setMediaItem(mediaItem, true)
            }
            player.prepare()
            player.playWhenReady = true
        }
    }

    private fun showZappingOsd() {
        osdBanner.alpha = 1f
        osdBanner.visibility = View.VISIBLE
        topControlBar.visibility = View.VISIBLE
        uiHandler.removeCallbacks(hideOsdRunnable)
        uiHandler.postDelayed(hideOsdRunnable, 3200L)
    }

    // =========================================================================
    // v18.1 PREDICTABLE REMOTE NAVIGATION & BACK-STACK HANDLING
    // (Requirement 5, 6, 7:
    //  - Movie playback → Movie Details → Movies grid
    //  - Series episode playback → Episode list → Series grid
    //  - Live TV playback → Existing Live TV interface)
    // =========================================================================

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val isKeyRepeat = (event?.repeatCount ?: 0) > 0
        val isOverlayOpen = leftChannelDrawer.visibility == View.VISIBLE || vodPosterGridPanel.visibility == View.VISIBLE
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP -> {
                if (!isOverlayOpen && activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                    lastRemoteKeyPressElapsedMs = SystemClock.elapsedRealtime()
                    lastZapForward = true
                    switchChannel(currentChannelIndex + 1, immediatePlayback = !isKeyRepeat)
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> {
                if (!isOverlayOpen && activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                    lastRemoteKeyPressElapsedMs = SystemClock.elapsedRealtime()
                    lastZapForward = false
                    switchChannel(currentChannelIndex - 1, immediatePlayback = !isKeyRepeat)
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (!isOverlayOpen) {
                    if (activePlaybackMode == ActivePlaybackMode.VOD_MOVIE || activePlaybackMode == ActivePlaybackMode.SERIES_EPISODE) {
                        exoPlayer?.let { p ->
                            val newPos = (p.currentPosition - 15_000L).coerceAtLeast(0L)
                            p.seekTo(newPos)
                            showZappingOsd()
                        }
                        return true
                    }
                    openDrawerAndRequestFocus()
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (leftChannelDrawer.visibility == View.VISIBLE && channelListRecycler.hasFocus()) {
                    closeDrawerAndRestoreFocus()
                    return true
                }
                if (!isOverlayOpen) {
                    if (activePlaybackMode == ActivePlaybackMode.VOD_MOVIE || activePlaybackMode == ActivePlaybackMode.SERIES_EPISODE) {
                        exoPlayer?.let { p ->
                            val dur = p.duration.takeIf { it > 0L && it != C.TIME_UNSET } ?: Long.MAX_VALUE
                            val newPos = (p.currentPosition + 15_000L).coerceAtMost(dur)
                            p.seekTo(newPos)
                            showZappingOsd()
                        }
                        return true
                    }
                    recallPreviousChannel()
                    return true
                }
            }
            KeyEvent.KEYCODE_LAST_CHANNEL, KeyEvent.KEYCODE_MEDIA_PREVIOUS, KeyEvent.KEYCODE_DEL -> {
                if (!isOverlayOpen) {
                    recallPreviousChannel()
                    return true
                }
            }
            KeyEvent.KEYCODE_SEARCH -> {
                showUnifiedSearchDialog()
                return true
            }
            KeyEvent.KEYCODE_INFO, KeyEvent.KEYCODE_GUIDE, KeyEvent.KEYCODE_PROG_GREEN -> {
                showEpgGuideHubDialog()
                return true
            }
            KeyEvent.KEYCODE_PROG_RED -> {
                toggleCurrentChannelFavorite()
                showZappingOsd()
                return true
            }
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_PROG_YELLOW, KeyEvent.KEYCODE_MEDIA_AUDIO_TRACK, KeyEvent.KEYCODE_CAPTIONS -> {
                showAudioAndQualityDialog()
                return true
            }
            KeyEvent.KEYCODE_PROG_BLUE, KeyEvent.KEYCODE_SETTINGS -> {
                showThemeAndPipDialog()
                return true
            }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                exoPlayer?.let { player ->
                    if (player.isPlaying) {
                        recordCurrentVodOrSeriesProgress()
                        player.pause()
                        liveStatusLabel = "⏸ Paused"
                    } else {
                        if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                            player.seekToDefaultPosition()
                        }
                        player.playWhenReady = true
                        liveStatusLabel = "🟢 Playing"
                    }
                    if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                        updateOsdForCurrentChannel()
                    }
                    showZappingOsd()
                }
                return true
            }
            KeyEvent.KEYCODE_BACK -> {
                // 1. If playing a VOD Movie or Trailer in full-screen -> return to Movie Details & Movies Grid!
                if (vodPosterGridPanel.visibility != View.VISIBLE &&
                    (activePlaybackMode == ActivePlaybackMode.VOD_MOVIE || activePlaybackMode == ActivePlaybackMode.VOD_TRAILER)
                ) {
                    recordCurrentVodOrSeriesProgress()
                    exoPlayer?.pause()
                    updateSectionButtonsUi(EntertainmentSection.MOVIES)
                    openVodPosterHub(EntertainmentSection.MOVIES, restoreFocusIndex = lastFocusedPosterIndex)
                    val mIdx = activeVodMovieIndex
                    val detail = activeVodMovieDetailInfo
                    if (mIdx in vodMoviesCatalog.indices) {
                        showMovieDetailModal(mIdx, detail)
                    }
                    return true
                }
                // 2. If playing a Series Episode in full-screen -> return to the exact Series & Season Episode List!
                if (vodPosterGridPanel.visibility != View.VISIBLE &&
                    activePlaybackMode == ActivePlaybackMode.SERIES_EPISODE
                ) {
                    recordCurrentVodOrSeriesProgress()
                    autoNextCountdownJob?.cancel()
                    autoNextCountdownDialog?.dismiss()
                    exoPlayer?.pause()
                    updateSectionButtonsUi(EntertainmentSection.SERIES)
                    openVodPosterHub(EntertainmentSection.SERIES, restoreFocusIndex = lastFocusedPosterIndex)
                    val grp = activeSeriesGroup
                    if (grp != null) {
                        presentSeriesDetailOverlayDialog(grp, activeSeriesSeasonNum)
                    }
                    return true
                }
                // 3. If VOD Poster Grid is open -> return to Live TV
                if (vodPosterGridPanel.visibility == View.VISIBLE) {
                    closeVodGridAndReturnToLiveTv()
                    return true
                }
                // 4. If Live TV Channel Drawer is open -> close drawer
                if (leftChannelDrawer.visibility == View.VISIBLE) {
                    closeDrawerAndRestoreFocus()
                    return true
                }
                // 5. If OSD or Top Bar is visible -> hide them
                if (osdBanner.visibility == View.VISIBLE || topControlBar.visibility == View.VISIBLE) {
                    uiHandler.removeCallbacks(hideOsdRunnable)
                    osdBanner.visibility = View.GONE
                    topControlBar.visibility = View.GONE
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                if (numberInputBuffer.isNotEmpty()) {
                    uiHandler.removeCallbacks(numberJumpRunnable)
                    numberJumpRunnable.run()
                    return true
                }
                if (!isOverlayOpen) {
                    showZappingOsd()
                    return true
                }
            }
            in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> {
                if ((leftChannelDrawer.visibility == View.VISIBLE && channelSearch.hasFocus()) ||
                    (vodPosterGridPanel.visibility == View.VISIBLE && vodPosterSearch.hasFocus())
                ) {
                    return super.onKeyDown(keyCode, event)
                }
                if (activePlaybackMode != ActivePlaybackMode.LIVE_TV) {
                    return super.onKeyDown(keyCode, event)
                }
                val digit = keyCode - KeyEvent.KEYCODE_0
                if (numberInputBuffer.length < 5) {
                    numberInputBuffer += digit.toString()
                }
                tvChannelNumber.text = numberInputBuffer.padStart(3, '-')
                osdBanner.alpha = 1f
                osdBanner.visibility = View.VISIBLE
                uiHandler.removeCallbacks(numberJumpRunnable)
                uiHandler.postDelayed(numberJumpRunnable, 750L)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun registerNetworkCallbackSafe() {
        if (networkCallbackRegistered) return
        val cm = connectivityManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                cm.registerDefaultNetworkCallback(networkCallback)
            } else {
                val req = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build()
                cm.registerNetworkCallback(req, networkCallback)
            }
            networkCallbackRegistered = true
        } catch (e: Exception) {
            Log.w("StreamX", "NetworkCallback registration warning: ${e.message}")
        }
    }

    private fun unregisterNetworkCallbackSafe() {
        if (!networkCallbackRegistered) return
        try {
            connectivityManager?.unregisterNetworkCallback(networkCallback)
        } catch (e: Exception) {
            Log.w("StreamX", "NetworkCallback unregister warning: ${e.message}")
        } finally {
            networkCallbackRegistered = false
        }
    }

    override fun onStart() {
        super.onStart()
        registerNetworkCallbackSafe()
        exoPlayer?.let { player ->
            if (player.mediaItemCount > 0) {
                if (player.playbackState == Player.STATE_IDLE) {
                    if (activePlaybackMode == ActivePlaybackMode.LIVE_TV) {
                        player.seekToDefaultPosition()
                    }
                    player.prepare()
                }
                player.playWhenReady = true
            }
        }
    }

    override fun onStop() {
        super.onStop()
        val inPip = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) isInPictureInPictureMode else false
        if (!inPip) {
            unregisterNetworkCallbackSafe()
            StreamPreFetcher.cancelAllPrefetches()
            uiHandler.removeCallbacks(stallWatchdogRunnable)
            uiHandler.removeCallbacks(persistStateRunnable)
            persistStateRunnable.run()
            exoPlayer?.pause()
        }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        runCatching {
            Glide.get(this).trimMemory(level)
            if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW ||
                level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND
            ) {
                Glide.get(this).clearMemory()
                StreamPreFetcher.trimIdleCacheOnLowMemory()
                ChannelCacheStore.trimMemoryCache()
                sharedAllocator?.trim()
            }
        }
    }

    override fun onLowMemory() {
        super.onLowMemory()
        runCatching {
            Glide.get(this).clearMemory()
            StreamPreFetcher.trimIdleCacheOnLowMemory()
            ChannelCacheStore.trimMemoryCache()
            sharedAllocator?.trim()
        }
    }

    override fun onDestroy() {
        recordCurrentVodOrSeriesProgress()
        cancelBootAnimators()
        unregisterNetworkCallbackSafe()
        StreamPreFetcher.cancelAllPrefetches()
        xtreamRepo.cancelActiveFetch()
        filterJob?.cancel()
        vodPosterFilterJob?.cancel()
        vodCatalogLoadJob?.cancel()
        seriesCatalogLoadJob?.cancel()
        autoNextCountdownJob?.cancel()
        loadChannelsJob?.cancel()
        epgLoadJob?.cancel()
        bgSyncJob?.cancel()
        uiHandler.removeCallbacksAndMessages(null)
        playerView.player = null
        exoPlayer?.release()
        exoPlayer = null
        super.onDestroy()
    }

    /**
     * v18.1 Left VOD Category Sidebar Adapter (Matches Reference Screenshots 25369.jpg / 25373.jpg / 25375.jpg:
     * FAVORITES / WATCHLIST, RECENTLY ADDED, CONTINUE WATCHING, BOLLYWOOD (2025-2026) (297), PAK: HUM TV (224), etc.)
     */
    private class VodCategorySidebarAdapter(
        private val reducedAnimations: () -> Boolean,
        private val onCategorySelected: (VodCategorySidebarItem) -> Unit
    ) : RecyclerView.Adapter<VodCategorySidebarAdapter.SidebarViewHolder>() {

        private var items: List<VodCategorySidebarItem> = emptyList()
        private var selectedCatName: String = "RECENTLY ADDED"

        fun submitCategories(newItems: List<VodCategorySidebarItem>, activeCategory: String) {
            items = newItems
            selectedCatName = activeCategory
            notifyDataSetChanged()
        }

        fun setSelectedCategory(categoryName: String) {
            if (selectedCatName == categoryName) return
            selectedCatName = categoryName
            notifyDataSetChanged()
        }

        override fun getItemCount(): Int = items.size

        private fun dp(ctx: Context, v: Int): Int =
            TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), ctx.resources.displayMetrics).toInt()

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SidebarViewHolder {
            val ctx = parent.context
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isFocusable = true
                isClickable = true
                setBackgroundResource(R.drawable.bg_channel_row_4d)
                setPadding(dp(ctx, 12), dp(ctx, 10), dp(ctx, 12), dp(ctx, 10))
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(ctx, 5) }
            }

            val tvName = TextView(ctx).apply {
                textSize = 12.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.WHITE)
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            row.addView(tvName)

            val tvCount = TextView(ctx).apply {
                textSize = 11f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#94A3B8"))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginStart = dp(ctx, 6) }
            }
            row.addView(tvCount)

            return SidebarViewHolder(row, tvName, tvCount, reducedAnimations, onCategorySelected)
        }

        override fun onBindViewHolder(holder: SidebarViewHolder, position: Int) {
            val item = items[position]
            holder.boundItem = item
            val isSelected = item.categoryName.equals(selectedCatName, ignoreCase = true)
            holder.root.isSelected = isSelected
            holder.root.setBackgroundResource(
                if (isSelected) R.drawable.bg_btn_3d_cyan else R.drawable.bg_channel_row_4d
            )
            holder.tvName.text = item.categoryName
            holder.tvName.setTextColor(
                if (isSelected) Color.parseColor("#FDE047") else Color.WHITE
            )
            holder.tvCount.text = if (item.count > 0) "(${item.count})" else ""
            holder.tvCount.setTextColor(
                if (isSelected) Color.parseColor("#7DD3FC") else Color.parseColor("#94A3B8")
            )
        }

        class SidebarViewHolder(
            val root: LinearLayout,
            val tvName: TextView,
            val tvCount: TextView,
            reducedAnimations: () -> Boolean,
            onCategorySelected: (VodCategorySidebarItem) -> Unit
        ) : RecyclerView.ViewHolder(root) {
            var boundItem: VodCategorySidebarItem? = null

            init {
                root.setOnClickListener {
                    boundItem?.let(onCategorySelected)
                }
                root.setOnFocusChangeListener { v, hasFocus ->
                    if (reducedAnimations()) {
                        v.scaleX = if (hasFocus) 1.015f else 1.0f
                        v.scaleY = if (hasFocus) 1.015f else 1.0f
                    } else {
                        val s = if (hasFocus) 1.03f else 1.0f
                        v.animate().scaleX(s).scaleY(s).setDuration(95L).start()
                    }
                }
            }
        }
    }

    /**
     * v18.1 4D Poster Grid Adapter for Movies & Series (5 Posters per row alongside Left Category Sidebar).
     * Uses programmatic ViewHolders with bounded RGB_565 thumbnails, quality/year badges,
     * watchlist stars, resume progress bar, and focus restoration tracking.
     */
    private class VodPosterGridAdapter(
        private val posterOptionsProvider: () -> RequestOptions,
        private val reducedAnimations: () -> Boolean,
        private val onPosterFocused: (Int) -> Unit,
        private val onPosterClicked: (PosterCardBindItem) -> Unit
    ) : RecyclerView.Adapter<VodPosterGridAdapter.PosterViewHolder>() {

        private var items: List<PosterCardBindItem> = emptyList()

        init {
            setHasStableIds(true)
        }

        fun submitItems(newItems: List<PosterCardBindItem>) {
            items = newItems
            notifyDataSetChanged()
        }

        override fun getItemId(position: Int): Long {
            return M3uParser.fnv1a64(items[position].key)
        }

        override fun getItemCount(): Int = items.size

        private fun dp(ctx: Context, v: Int): Int =
            TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), ctx.resources.displayMetrics).toInt()

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PosterViewHolder {
            val ctx = parent.context
            val card = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                isFocusable = true
                isClickable = true
                setBackgroundResource(R.drawable.bg_poster_card_4d)
                setPadding(dp(ctx, 7), dp(ctx, 7), dp(ctx, 7), dp(ctx, 9))
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    val m = dp(ctx, 5)
                    setMargins(m, m, m, m)
                }
            }

            val posterFrame = FrameLayout(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(ctx, 168)
                )
            }

            val ivPoster = ImageView(ctx).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(Color.parseColor("#FF071326"))
                setImageResource(R.drawable.ic_3d_movies)
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
            posterFrame.addView(ivPoster)

            val tvQualityBadge = TextView(ctx).apply {
                textSize = 9.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#38BDF8"))
                setBackgroundResource(R.drawable.bg_badge_neon)
                setPadding(dp(ctx, 6), dp(ctx, 2), dp(ctx, 6), dp(ctx, 2))
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP or Gravity.END
                ).apply {
                    topMargin = dp(ctx, 5)
                    marginEnd = dp(ctx, 5)
                }
            }
            posterFrame.addView(tvQualityBadge)

            val tvYearBadge = TextView(ctx).apply {
                textSize = 9f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#FDE047"))
                setBackgroundResource(R.drawable.bg_live_dot_pill)
                setPadding(dp(ctx, 6), dp(ctx, 2), dp(ctx, 6), dp(ctx, 2))
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP or Gravity.START
                ).apply {
                    topMargin = dp(ctx, 5)
                    marginStart = dp(ctx, 5)
                }
            }
            posterFrame.addView(tvYearBadge)

            val progressBar = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progress = 0
                visibility = View.GONE
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(ctx, 4),
                    Gravity.BOTTOM
                )
            }
            posterFrame.addView(progressBar)

            card.addView(posterFrame)

            val tvTitle = TextView(ctx).apply {
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER_HORIZONTAL
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = dp(ctx, 6)
                }
            }
            card.addView(tvTitle)

            val tvSubtitle = TextView(ctx).apply {
                textSize = 10f
                setTextColor(Color.parseColor("#94A3B8"))
                gravity = Gravity.CENTER_HORIZONTAL
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = dp(ctx, 2)
                }
            }
            card.addView(tvSubtitle)

            return PosterViewHolder(
                card,
                ivPoster,
                tvQualityBadge,
                tvYearBadge,
                progressBar,
                tvTitle,
                tvSubtitle,
                reducedAnimations,
                onPosterFocused,
                onPosterClicked
            )
        }

        override fun onBindViewHolder(holder: PosterViewHolder, position: Int) {
            val item = items[position]
            holder.boundItem = item
            holder.boundPosition = position
            holder.tvTitle.text = item.title
            holder.tvSubtitle.text = if (item.isFavorite) "★ ${item.subtitle}" else item.subtitle

            if (item.qualityBadge.isNotBlank()) {
                holder.tvQualityBadge.text = item.qualityBadge
                holder.tvQualityBadge.visibility = View.VISIBLE
            } else {
                holder.tvQualityBadge.visibility = View.GONE
            }

            if (item.yearBadge.isNotBlank()) {
                holder.tvYearBadge.text = item.yearBadge
                holder.tvYearBadge.visibility = View.VISIBLE
            } else {
                holder.tvYearBadge.visibility = View.GONE
            }

            if (item.progressPercent > 0) {
                holder.progressBar.progress = item.progressPercent
                holder.progressBar.visibility = View.VISIBLE
            } else {
                holder.progressBar.visibility = View.GONE
            }

            val fallbackIcon = if (item.seriesSummary != null) R.drawable.ic_3d_series else R.drawable.ic_3d_movies
            if (item.posterUrl.isNotBlank()) {
                Glide.with(holder.ivPoster.context)
                    .load(item.posterUrl)
                    .apply(posterOptionsProvider().placeholder(fallbackIcon).error(fallbackIcon))
                    .into(holder.ivPoster)
            } else {
                Glide.with(holder.ivPoster.context).clear(holder.ivPoster)
                holder.ivPoster.scaleType = ImageView.ScaleType.FIT_CENTER
                holder.ivPoster.setImageResource(fallbackIcon)
            }
        }

        class PosterViewHolder(
            val root: LinearLayout,
            val ivPoster: ImageView,
            val tvQualityBadge: TextView,
            val tvYearBadge: TextView,
            val progressBar: ProgressBar,
            val tvTitle: TextView,
            val tvSubtitle: TextView,
            reducedAnimations: () -> Boolean,
            onPosterFocused: (Int) -> Unit,
            onPosterClicked: (PosterCardBindItem) -> Unit
        ) : RecyclerView.ViewHolder(root) {
            var boundItem: PosterCardBindItem? = null
            var boundPosition: Int = 0

            init {
                root.setOnClickListener {
                    boundItem?.let(onPosterClicked)
                }
                root.setOnFocusChangeListener { v, hasFocus ->
                    if (hasFocus) {
                        onPosterFocused(boundPosition)
                    }
                    if (reducedAnimations()) {
                        v.scaleX = if (hasFocus) 1.02f else 1.0f
                        v.scaleY = if (hasFocus) 1.02f else 1.0f
                    } else {
                        val s = if (hasFocus) 1.045f else 1.0f
                        v.animate().scaleX(s).scaleY(s).setDuration(105L).start()
                    }
                }
            }
        }
    }

    /**
     * 4D Crystal Glass Channel Card Adapter for 512MB RAM Android TVs.
     */
    private class ChannelDrawerAdapter(
        private val channelProvider: (Int) -> Channel?,
        private val isFavorite: (String) -> Boolean,
        private val epgProvider: (Channel) -> String?,
        private val logoOptions: RequestOptions,
        private val onChannelClick: (Int) -> Unit,
        private val onChannelFocused: (Int) -> Unit
    ) : RecyclerView.Adapter<ChannelDrawerAdapter.ChannelViewHolder>() {

        companion object {
            private const val PAYLOAD_ACTIVE_STATE = 1
            private const val PAYLOAD_FAVORITE_STATE = 2
        }

        private var indices: IntArray = IntArray(0)
        private var indicesAscending: Boolean = true
        private var activeGlobalIndex: Int = 0
        private var activeRowDrawableRes: Int = R.drawable.bg_btn_3d_cyan
        private val inactiveRowDrawableRes: Int = R.drawable.bg_channel_row_4d
        private val metaBuilder = StringBuilder(64)

        init {
            setHasStableIds(true)
        }

        fun currentIndices(): IntArray = indices

        private fun findAdapterPos(globalIndex: Int): Int {
            if (indices.isEmpty()) return -1
            if (indicesAscending) {
                val pos = Arrays.binarySearch(indices, globalIndex)
                return if (pos >= 0) pos else -1
            }
            return indices.indexOfFirst { it == globalIndex }
        }

        fun setActiveRowDrawable(drawableRes: Int) {
            if (activeRowDrawableRes == drawableRes) return
            activeRowDrawableRes = drawableRes
            val activePos = findAdapterPos(activeGlobalIndex)
            if (activePos != -1) {
                notifyItemChanged(activePos, PAYLOAD_ACTIVE_STATE)
            }
        }

        fun submitIndices(
            newIndices: IntArray,
            currentGlobalIndex: Int,
            diffResult: DiffUtil.DiffResult?,
            isAscending: Boolean = true
        ) {
            val prevActiveGlobal = activeGlobalIndex
            indices = newIndices
            indicesAscending = isAscending
            activeGlobalIndex = currentGlobalIndex
            if (diffResult != null) {
                diffResult.dispatchUpdatesTo(this)
                if (prevActiveGlobal != currentGlobalIndex) {
                    val oldPos = findAdapterPos(prevActiveGlobal)
                    val newPos = findAdapterPos(currentGlobalIndex)
                    if (oldPos != -1) notifyItemChanged(oldPos, PAYLOAD_ACTIVE_STATE)
                    if (newPos != -1) notifyItemChanged(newPos, PAYLOAD_ACTIVE_STATE)
                }
            } else {
                notifyDataSetChanged()
            }
        }

        fun updateActiveChannel(newGlobalIndex: Int) {
            if (activeGlobalIndex == newGlobalIndex) return
            val oldGlobal = activeGlobalIndex
            activeGlobalIndex = newGlobalIndex
            val oldPos = findAdapterPos(oldGlobal)
            val newPos = findAdapterPos(newGlobalIndex)
            if (oldPos != -1) notifyItemChanged(oldPos, PAYLOAD_ACTIVE_STATE)
            if (newPos != -1) notifyItemChanged(newPos, PAYLOAD_ACTIVE_STATE)
        }

        fun notifyFavoriteChanged(globalIndex: Int) {
            val pos = findAdapterPos(globalIndex)
            if (pos != -1) notifyItemChanged(pos, PAYLOAD_FAVORITE_STATE)
        }

        override fun getItemId(position: Int): Long = indices[position].toLong()

        private fun dp(ctx: Context, v: Int): Int =
            TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), ctx.resources.displayMetrics).toInt()

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
            val ctx = parent.context
            val root = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isFocusable = true
                isClickable = true
                setBackgroundResource(inactiveRowDrawableRes)
                setPadding(dp(ctx, 10), dp(ctx, 8), dp(ctx, 10), dp(ctx, 8))
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dp(ctx, 7)
                }
            }

            val tvNum = TextView(ctx).apply {
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#38BDF8"))
                setBackgroundResource(R.drawable.bg_badge_neon)
                gravity = Gravity.CENTER
                minWidth = dp(ctx, 42)
                setPadding(dp(ctx, 7), dp(ctx, 4), dp(ctx, 7), dp(ctx, 4))
            }
            root.addView(tvNum)

            val ivLogo = ImageView(ctx).apply {
                setBackgroundResource(R.drawable.bg_channel_logo_frame)
                setPadding(dp(ctx, 4), dp(ctx, 4), dp(ctx, 4), dp(ctx, 4))
                scaleType = ImageView.ScaleType.FIT_CENTER
                setImageResource(R.drawable.ic_3d_live_tv)
                layoutParams = LinearLayout.LayoutParams(dp(ctx, 34), dp(ctx, 34)).apply {
                    marginStart = dp(ctx, 8)
                }
            }
            root.addView(ivLogo)

            val textCol = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dp(ctx, 9)
                    marginEnd = dp(ctx, 6)
                }
            }
            val tvTitle = TextView(ctx).apply {
                textSize = 13.5f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.WHITE)
                setSingleLine(true)
                ellipsize = TextUtils.TruncateAt.END
            }
            val tvSub = TextView(ctx).apply {
                textSize = 11f
                setTextColor(Color.parseColor("#BAE6FD"))
                setSingleLine(true)
                ellipsize = TextUtils.TruncateAt.END
            }
            textCol.addView(tvTitle)
            textCol.addView(tvSub)
            root.addView(textCol)

            val tvFavBadge = TextView(ctx).apply {
                textSize = 11f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.parseColor("#FDE047"))
                setPadding(dp(ctx, 4), dp(ctx, 2), dp(ctx, 4), dp(ctx, 2))
            }
            root.addView(tvFavBadge)

            return ChannelViewHolder(root, tvNum, ivLogo, tvTitle, tvSub, tvFavBadge, onChannelClick, onChannelFocused)
        }

        override fun onBindViewHolder(
            holder: ChannelViewHolder,
            position: Int,
            payloads: MutableList<Any>
        ) {
            if (payloads.isEmpty()) {
                onBindViewHolder(holder, position)
                return
            }
            val globalIdx = indices[position]
            val ch = channelProvider(globalIdx) ?: return
            val isSelected = globalIdx == activeGlobalIndex
            holder.root.isSelected = isSelected
            for (payload in payloads) {
                when (payload) {
                    PAYLOAD_ACTIVE_STATE -> {
                        holder.root.setBackgroundResource(if (isSelected) activeRowDrawableRes else inactiveRowDrawableRes)
                        bindBadgeState(holder, ch, isSelected)
                    }
                    PAYLOAD_FAVORITE_STATE -> {
                        bindBadgeState(holder, ch, isSelected)
                    }
                }
            }
        }

        override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
            val globalIdx = indices[position]
            holder.boundGlobalIndex = globalIdx
            val ch = channelProvider(globalIdx) ?: return
            val isSelected = globalIdx == activeGlobalIndex
            holder.root.isSelected = isSelected

            holder.tvNum.text = ch.displayNumberFormatted()
            holder.tvTitle.text = ch.name

            metaBuilder.setLength(0)
            metaBuilder.append(ch.category)
            val nowProg = epgProvider(ch)
            if (!nowProg.isNullOrBlank()) {
                metaBuilder.append(" • ").append(nowProg)
            } else if (ch.backupUrl.isNotBlank()) {
                metaBuilder.append(" • ⚡ Dual-Stream")
            } else {
                metaBuilder.append(" • Live HD")
            }
            holder.tvSub.text = metaBuilder.toString()

            if (ch.logoUrl.isNotBlank()) {
                Glide.with(holder.ivLogo.context)
                    .load(ch.logoUrl)
                    .apply(logoOptions)
                    .into(holder.ivLogo)
            } else {
                Glide.with(holder.ivLogo.context).clear(holder.ivLogo)
                holder.ivLogo.setImageResource(R.drawable.ic_3d_live_tv)
            }

            holder.root.setBackgroundResource(if (isSelected) activeRowDrawableRes else inactiveRowDrawableRes)
            bindBadgeState(holder, ch, isSelected)
        }

        private fun bindBadgeState(holder: ChannelViewHolder, ch: Channel, isSelected: Boolean) {
            val fav = isFavorite(ch.id)
            when {
                isSelected && fav -> {
                    holder.tvFavBadge.text = "★ LIVE"
                    holder.tvFavBadge.setTextColor(Color.parseColor("#FDE047"))
                }
                isSelected -> {
                    holder.tvFavBadge.text = "● LIVE"
                    holder.tvFavBadge.setTextColor(Color.parseColor("#6EE7B7"))
                }
                fav -> {
                    holder.tvFavBadge.text = "★"
                    holder.tvFavBadge.setTextColor(Color.parseColor("#FDE047"))
                }
                else -> {
                    holder.tvFavBadge.text = ""
                }
            }
        }

        override fun getItemCount(): Int = indices.size

        class ChannelViewHolder(
            val root: LinearLayout,
            val tvNum: TextView,
            val ivLogo: ImageView,
            val tvTitle: TextView,
            val tvSub: TextView,
            val tvFavBadge: TextView,
            onChannelClick: (Int) -> Unit,
            onChannelFocused: (Int) -> Unit
        ) : RecyclerView.ViewHolder(root) {
            var boundGlobalIndex: Int = -1

            init {
                root.setOnClickListener {
                    if (boundGlobalIndex >= 0) {
                        onChannelClick(boundGlobalIndex)
                    }
                }
                root.setOnFocusChangeListener { v, hasFocus ->
                    val targetScale = if (hasFocus) 1.02f else 1.0f
                    v.animate().scaleX(targetScale).scaleY(targetScale).setDuration(100L).start()
                    if (hasFocus && boundGlobalIndex >= 0) {
                        onChannelFocused(boundGlobalIndex)
                    }
                }
            }
        }
    }
}
