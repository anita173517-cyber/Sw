package com.harindra.iptvpro

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

enum class ProfileType { M3U, XTREAM }

data class PlaylistProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: ProfileType,
    val source: String,
    val username: String = "",
    val password: String = ""
)

/**
 * StreamX Media3 Pro v18.1 — ProfileStore with Strict Per-Account Isolation:
 * - Encrypted credentials (`EncryptedSharedPreferences` + AES-256-GCM fallback).
 * - Salted SHA-256 4-digit Parental PIN lock.
 * - Per-account Continue Watching progress (`savePlaybackProgress`, `getContinueWatchingEntries`)
 *   strictly restricted to VOD Movies (`XTREAM_VOD_MOVIE`) and Series Episodes (`XTREAM_SERIES_EPISODE`).
 *   Live TV channels (`M3U_LIVE`, `XTREAM_LIVE`) NEVER enter Continue Watching.
 * - Per-account Personal Watchlist separated for Movies (`getMovieWatchlistIds`) and Series (`getSeriesWatchlistIds`).
 * - Smart Auto Next Episode setting (`isAutoNextEpisodeEnabled`, `setAutoNextEpisodeEnabled`).
 */
class ProfileStore(context: Context) {
    private val appContext = context.applicationContext
    private val fastMetaPrefs: SharedPreferences =
        appContext.getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)

    @Volatile
    private var usingFallbackPrefs: Boolean = false

    // Lazy initialization: Tink/KeyStore is NEVER loaded on cold boot if the user has no saved profiles
    private val securePrefs: SharedPreferences by lazy {
        try {
            usingFallbackPrefs = false
            EncryptedSharedPreferences.create(
                appContext,
                "streamx_secure_profiles",
                MasterKey.Builder(appContext).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            usingFallbackPrefs = true
            Log.w("StreamX", "EncryptedSharedPreferences unavailable on this TV; using AES-GCM protected fallback")
            appContext.getSharedPreferences("streamx_profiles_fallback", Context.MODE_PRIVATE)
        }
    }

    @Volatile
    private var cachedProfiles: MutableList<PlaylistProfile>? = null

    private val cachedProgressByScope = HashMap<String, MutableMap<String, PlaybackProgressEntry>>(4)

    companion object {
        private const val PIN_HASH_KEY = "parental_pin_hash_v2"
        private const val PIN_SALT_KEY = "parental_pin_salt_v2"
        private const val LEGACY_PIN_KEY = "parental_pin_code"
        private const val FALLBACK_ENC_PREFIX = "ENC1:"
        private const val PLAYBACK_PROGRESS_PREFIX = "vod_series_progress_v181_"
        private const val MOVIE_WATCHLIST_PREFIX = "movie_watchlist_v181_"
        private const val SERIES_WATCHLIST_PREFIX = "series_watchlist_v181_"
        private const val LIVE_FAVORITES_PREFIX = "live_favorites_v181_"
        private const val SEARCH_HISTORY_KEY = "unified_search_history_v18"
        private const val PERFORMANCE_MODE_KEY = "performance_mode_id_v18"
        private const val AUTO_NEXT_EPISODE_KEY = "auto_next_episode_enabled_v181"
        private const val MAX_PROGRESS_ITEMS = 120
        private const val MAX_SEARCH_HISTORY = 12

        fun sanitizeExternalInput(raw: String): String {
            if (raw.isEmpty()) return ""
            return raw
                .replace("\u200B", "")
                .replace("\uFEFF", "")
                .trim()
        }

        fun computeSaltedPinHash(pin: String, saltHex: String): String {
            val md = MessageDigest.getInstance("SHA-256")
            var digest = "$saltHex:${pin.trim()}".toByteArray(Charsets.UTF_8)
            repeat(1000) {
                md.reset()
                md.update(digest)
                digest = md.digest()
            }
            return digest.joinToString("") { "%02x".format(it) }
        }

        fun verifySaltedPinHash(candidatePin: String, saltHex: String, expectedHashHex: String): Boolean {
            if (candidatePin.length != 4 || expectedHashHex.isBlank() || saltHex.isBlank()) return false
            val actualHashHex = computeSaltedPinHash(candidatePin, saltHex)
            return MessageDigest.isEqual(
                actualHashHex.toByteArray(Charsets.UTF_8),
                expectedHashHex.toByteArray(Charsets.UTF_8)
            )
        }
    }

    private fun normalizeScope(accountScope: String?): String {
        val raw = accountScope?.trim().orEmpty().ifBlank { activeId().orEmpty().ifBlank { "default" } }
        return raw.take(48).map { c ->
            if (c.isLetterOrDigit() || c == '_' || c == '-') c else '_'
        }.joinToString("")
    }

    private fun getOrCreateFallbackAesKey(): SecretKeySpec {
        var seedHex = fastMetaPrefs.getString("fallback_kdf_seed", null)
        if (seedHex.isNullOrBlank()) {
            val randomBytes = ByteArray(32)
            SecureRandom().nextBytes(randomBytes)
            seedHex = randomBytes.joinToString("") { "%02x".format(it) }
            fastMetaPrefs.edit().putString("fallback_kdf_seed", seedHex).apply()
        }
        val keyBytes = MessageDigest.getInstance("SHA-256")
            .digest(("StreamX_AES256_${appContext.packageName}_$seedHex").toByteArray(Charsets.UTF_8))
        return SecretKeySpec(keyBytes, "AES")
    }

    private fun encryptFallbackPayload(plainJson: String): String {
        return try {
            val iv = ByteArray(12)
            SecureRandom().nextBytes(iv)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateFallbackAesKey(), GCMParameterSpec(128, iv))
            val cipherBytes = cipher.doFinal(plainJson.toByteArray(Charsets.UTF_8))
            val combined = ByteArray(iv.size + cipherBytes.size)
            System.arraycopy(iv, 0, combined, 0, iv.size)
            System.arraycopy(cipherBytes, 0, combined, iv.size, cipherBytes.size)
            FALLBACK_ENC_PREFIX + Base64.encodeToString(combined, Base64.NO_WRAP)
        } catch (_: Exception) {
            plainJson
        }
    }

    private fun decryptFallbackPayload(stored: String): String {
        if (!stored.startsWith(FALLBACK_ENC_PREFIX)) {
            return stored
        }
        return try {
            val raw = Base64.decode(stored.removePrefix(FALLBACK_ENC_PREFIX), Base64.NO_WRAP)
            if (raw.size <= 12) return "[]"
            val iv = raw.copyOfRange(0, 12)
            val cipherBytes = raw.copyOfRange(12, raw.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateFallbackAesKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(cipherBytes), Charsets.UTF_8)
        } catch (e: Exception) {
            Log.w("StreamX", "Fallback profile decrypt warning: ${e.message}")
            "[]"
        }
    }

    @Synchronized
    fun all(): MutableList<PlaylistProfile> {
        cachedProfiles?.let { return it.toMutableList() }
        if (!fastMetaPrefs.getBoolean("has_saved_profiles", true)) {
            val empty = mutableListOf<PlaylistProfile>()
            cachedProfiles = empty
            return mutableListOf()
        }
        val rawStored = try {
            securePrefs.getString("profiles", "[]") ?: "[]"
        } catch (e: Exception) {
            Log.w("StreamX", "Failed to read saved profiles")
            "[]"
        }
        val raw = if (rawStored.startsWith(FALLBACK_ENC_PREFIX)) {
            decryptFallbackPayload(rawStored)
        } else {
            rawStored
        }
        val parsed = try {
            val arr = JSONArray(raw)
            MutableList(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                PlaylistProfile(
                    id = sanitizeExternalInput(o.optString("id")).ifBlank { UUID.randomUUID().toString() },
                    name = sanitizeExternalInput(o.optString("name", "IPTV Account")).ifBlank { "IPTV Account" },
                    type = runCatching { ProfileType.valueOf(o.optString("type", "M3U")) }.getOrDefault(ProfileType.M3U),
                    source = sanitizeExternalInput(o.optString("source")),
                    username = sanitizeExternalInput(o.optString("username")),
                    password = sanitizeExternalInput(o.optString("password"))
                )
            }
        } catch (e: Exception) {
            Log.w("StreamX", "Corrupted profile JSON; resetting in-memory list")
            mutableListOf()
        }
        cachedProfiles = parsed
        fastMetaPrefs.edit().putBoolean("has_saved_profiles", parsed.isNotEmpty()).apply()
        return parsed.toMutableList()
    }

    @Synchronized
    fun save(profile: PlaylistProfile) {
        val cleanProfile = profile.copy(
            name = sanitizeExternalInput(profile.name).ifBlank { "IPTV Account" },
            source = sanitizeExternalInput(profile.source),
            username = sanitizeExternalInput(profile.username),
            password = sanitizeExternalInput(profile.password)
        )
        val list = all()
        val idx = list.indexOfFirst { it.id == cleanProfile.id }
        if (idx >= 0) list[idx] = cleanProfile else list.add(cleanProfile)
        persist(list)
    }

    @Synchronized
    fun delete(id: String) {
        val scope = normalizeScope(id)
        cachedProgressByScope.remove(scope)
        fastMetaPrefs.edit()
            .remove("$PLAYBACK_PROGRESS_PREFIX$scope")
            .remove("$MOVIE_WATCHLIST_PREFIX$scope")
            .remove("$SERIES_WATCHLIST_PREFIX$scope")
            .remove("$LIVE_FAVORITES_PREFIX$scope")
            .apply()
        persist(all().filterNot { it.id == id })
    }

    fun activeId(): String? = try {
        fastMetaPrefs.getString("active_profile_id_fast", null)
            ?: if (fastMetaPrefs.getBoolean("has_saved_profiles", false)) securePrefs.getString("active_id", null) else null
    } catch (e: Exception) {
        Log.w("StreamX", "Failed to read active profile ID")
        null
    }

    fun setActive(id: String) {
        try {
            fastMetaPrefs.edit().putString("active_profile_id_fast", id).apply()
            if (fastMetaPrefs.getBoolean("has_saved_profiles", false)) {
                securePrefs.edit().putString("active_id", id).apply()
            }
        } catch (e: Exception) {
            Log.w("StreamX", "Failed to save active profile ID")
        }
    }

    // Salted SHA-256 4-Digit Parental PIN Lock with Legacy Compatibility
    fun hasParentalPin(): Boolean {
        val hash = fastMetaPrefs.getString(PIN_HASH_KEY, "") ?: ""
        if (hash.isNotBlank()) return true
        val legacy = fastMetaPrefs.getString(LEGACY_PIN_KEY, "") ?: ""
        return legacy.length == 4
    }

    fun getParentalPin(): String {
        return if (hasParentalPin()) "****" else ""
    }

    fun verifyParentalPin(candidatePin: String): Boolean {
        val trimmed = candidatePin.trim()
        if (trimmed.length != 4) return false
        val savedHash = fastMetaPrefs.getString(PIN_HASH_KEY, "") ?: ""
        val savedSalt = fastMetaPrefs.getString(PIN_SALT_KEY, "") ?: ""
        if (savedHash.isNotBlank() && savedSalt.isNotBlank()) {
            return verifySaltedPinHash(trimmed, savedSalt, savedHash)
        }
        val legacyPin = fastMetaPrefs.getString(LEGACY_PIN_KEY, "") ?: ""
        if (legacyPin.length == 4 && legacyPin == trimmed) {
            setParentalPin(trimmed)
            return true
        }
        return false
    }

    fun setParentalPin(pin: String) {
        val clean = pin.trim()
        if (clean.isEmpty()) {
            fastMetaPrefs.edit()
                .remove(PIN_HASH_KEY)
                .remove(PIN_SALT_KEY)
                .remove(LEGACY_PIN_KEY)
                .apply()
            return
        }
        val saltBytes = ByteArray(16)
        SecureRandom().nextBytes(saltBytes)
        val saltHex = saltBytes.joinToString("") { "%02x".format(it) }
        val hashHex = computeSaltedPinHash(clean, saltHex)
        fastMetaPrefs.edit()
            .putString(PIN_SALT_KEY, saltHex)
            .putString(PIN_HASH_KEY, hashHex)
            .remove(LEGACY_PIN_KEY)
            .apply()
    }

    fun getLockedCategories(): Set<String> {
        return fastMetaPrefs.getStringSet("locked_categories", emptySet())?.toSet() ?: emptySet()
    }

    fun toggleCategoryLock(category: String): Boolean {
        val norm = category.trim()
        val current = getLockedCategories().toMutableSet()
        val nowLocked = if (current.contains(norm)) {
            current.remove(norm)
            false
        } else {
            current.add(norm)
            true
        }
        fastMetaPrefs.edit().putStringSet("locked_categories", current).apply()
        return nowLocked
    }

    fun isCategoryLocked(category: String): Boolean {
        if (!hasParentalPin()) return false
        val norm = category.trim()
        if (getLockedCategories().any { it.equals(norm, ignoreCase = true) }) return true
        val lower = norm.lowercase(Locale.ROOT)
        return lower.contains("adult") || lower.contains("18+") || lower.contains("xxx")
    }

    fun getPreferredAudioLanguage(channelId: String): String? {
        return fastMetaPrefs.getString("audio_lang_$channelId", null)?.takeIf { it.isNotBlank() }
    }

    fun setPreferredAudioLanguage(channelId: String, language: String) {
        fastMetaPrefs.edit().putString("audio_lang_$channelId", language.trim()).apply()
    }

    // =========================================================================
    // v18.1 SMART CONTINUE WATCHING (PER-ACCOUNT ISOLATED, VOD & SERIES ONLY)
    // =========================================================================

    @Synchronized
    private fun ensureProgressLoaded(accountScope: String? = null): MutableMap<String, PlaybackProgressEntry> {
        val scope = normalizeScope(accountScope)
        cachedProgressByScope[scope]?.let { return it }
        val raw = fastMetaPrefs.getString("$PLAYBACK_PROGRESS_PREFIX$scope", "") ?: ""
        val map = LinkedHashMap<String, PlaybackProgressEntry>(64)
        if (raw.isNotBlank()) {
            for (line in raw.lineSequence()) {
                if (line.isBlank()) continue
                val parts = line.split('\t')
                if (parts.size >= 4) {
                    val id = parts[0]
                    val pos = parts[1].toLongOrNull() ?: 0L
                    val dur = parts[2].toLongOrNull() ?: 0L
                    val ts = parts[3].toLongOrNull() ?: 0L
                    val sKey = parts.getOrNull(4).orEmpty()
                    val sNum = parts.getOrNull(5)?.toIntOrNull() ?: 0
                    val eNum = parts.getOrNull(6)?.toIntOrNull() ?: 0
                    val cType = ContentSourceType.fromCode(
                        parts.getOrNull(7).orEmpty().ifBlank {
                            if (sKey.isNotBlank() || id.startsWith("ep_")) ContentSourceType.XTREAM_SERIES_EPISODE.code
                            else ContentSourceType.XTREAM_VOD_MOVIE.code
                        }
                    )
                    if (id.isNotBlank() && pos > 0L && !cType.isLiveTv()) {
                        map[id] = PlaybackProgressEntry(id, pos, dur, ts, cType, sKey, sNum, eNum)
                    }
                }
            }
        }
        cachedProgressByScope[scope] = map
        return map
    }

    /**
     * Saves playback progress ONLY for VOD Movies and Series Episodes.
     * Live TV channels (`M3U_LIVE`, `XTREAM_LIVE`) are strictly rejected so they never enter Continue Watching.
     */
    @Synchronized
    fun savePlaybackProgress(
        contentId: String,
        positionMs: Long,
        durationMs: Long,
        seriesKey: String = "",
        seasonNumber: Int = 0,
        episodeNumber: Int = 0,
        contentType: ContentSourceType = if (seriesKey.isNotBlank() || contentId.startsWith("ep_")) {
            ContentSourceType.XTREAM_SERIES_EPISODE
        } else {
            ContentSourceType.XTREAM_VOD_MOVIE
        },
        accountScope: String? = null
    ) {
        if (contentId.isBlank() || contentType.isLiveTv()) return
        val scope = normalizeScope(accountScope)
        val map = ensureProgressLoaded(scope)
        // Mark as watched / remove from Continue Watching if >= 95% complete or < 10s watched
        if (positionMs < 10_000L || (durationMs > 0L && (positionMs * 100L / durationMs) >= 95L)) {
            map.remove(contentId)
        } else {
            map[contentId] = PlaybackProgressEntry(
                contentId = contentId,
                positionMs = positionMs,
                durationMs = durationMs.coerceAtLeast(0L),
                updatedAtMs = System.currentTimeMillis(),
                contentType = contentType,
                seriesKey = seriesKey,
                seasonNumber = seasonNumber,
                episodeNumber = episodeNumber
            )
        }
        persistProgressMap(scope, map)
    }

    @Synchronized
    fun getPlaybackProgress(contentId: String, accountScope: String? = null): PlaybackProgressEntry? {
        if (contentId.isBlank()) return null
        return ensureProgressLoaded(accountScope)[contentId]
    }

    @Synchronized
    fun getContinueWatchingEntries(accountScope: String? = null): List<PlaybackProgressEntry> {
        return ensureProgressLoaded(accountScope)
            .values
            .filter { it.isResumable() && !it.contentType.isLiveTv() }
            .sortedByDescending { it.updatedAtMs }
    }

    @Synchronized
    fun clearPlaybackProgress(contentId: String, accountScope: String? = null) {
        val scope = normalizeScope(accountScope)
        val map = ensureProgressLoaded(scope)
        if (map.remove(contentId) != null) {
            persistProgressMap(scope, map)
        }
    }

    private fun persistProgressMap(scope: String, map: MutableMap<String, PlaybackProgressEntry>) {
        val sorted = map.values.sortedByDescending { it.updatedAtMs }.take(MAX_PROGRESS_ITEMS)
        map.clear()
        val sb = StringBuilder(sorted.size * 56)
        for (entry in sorted) {
            map[entry.contentId] = entry
            sb.append(entry.contentId.replace('\t', ' ').replace('\n', ' '))
                .append('\t')
                .append(entry.positionMs)
                .append('\t')
                .append(entry.durationMs)
                .append('\t')
                .append(entry.updatedAtMs)
                .append('\t')
                .append(entry.seriesKey.replace('\t', ' ').replace('\n', ' '))
                .append('\t')
                .append(entry.seasonNumber)
                .append('\t')
                .append(entry.episodeNumber)
                .append('\t')
                .append(entry.contentType.code)
                .append('\n')
        }
        fastMetaPrefs.edit().putString("$PLAYBACK_PROGRESS_PREFIX$scope", sb.toString()).apply()
    }

    // =========================================================================
    // v18.1 PERSONAL WATCHLIST (SEPARATED MOVIES & SERIES, PER-ACCOUNT ISOLATED)
    // =========================================================================

    fun getMovieWatchlistIds(accountScope: String? = null): Set<String> {
        val scope = normalizeScope(accountScope)
        return fastMetaPrefs.getStringSet("$MOVIE_WATCHLIST_PREFIX$scope", emptySet())?.toSet() ?: emptySet()
    }

    fun toggleMovieWatchlist(movieId: String, sourceType: ContentSourceType = ContentSourceType.XTREAM_VOD_MOVIE, accountScope: String? = null): Boolean {
        if (movieId.isBlank() || sourceType != ContentSourceType.XTREAM_VOD_MOVIE) return false
        val scope = normalizeScope(accountScope)
        val key = "$MOVIE_WATCHLIST_PREFIX$scope"
        val current = getMovieWatchlistIds(scope).toMutableSet()
        val added = if (current.contains(movieId)) {
            current.remove(movieId)
            false
        } else {
            current.add(movieId)
            true
        }
        fastMetaPrefs.edit().putStringSet(key, current).apply()
        return added
    }

    fun isMovieInWatchlist(movieId: String, accountScope: String? = null): Boolean {
        if (movieId.isBlank()) return false
        return getMovieWatchlistIds(accountScope).contains(movieId)
    }

    fun getSeriesWatchlistIds(accountScope: String? = null): Set<String> {
        val scope = normalizeScope(accountScope)
        return fastMetaPrefs.getStringSet("$SERIES_WATCHLIST_PREFIX$scope", emptySet())?.toSet() ?: emptySet()
    }

    fun toggleSeriesWatchlist(seriesKeyOrId: String, sourceType: ContentSourceType = ContentSourceType.XTREAM_SERIES, accountScope: String? = null): Boolean {
        if (seriesKeyOrId.isBlank() || (sourceType != ContentSourceType.XTREAM_SERIES && sourceType != ContentSourceType.XTREAM_SERIES_EPISODE)) return false
        val scope = normalizeScope(accountScope)
        val key = "$SERIES_WATCHLIST_PREFIX$scope"
        val current = getSeriesWatchlistIds(scope).toMutableSet()
        val added = if (current.contains(seriesKeyOrId)) {
            current.remove(seriesKeyOrId)
            false
        } else {
            current.add(seriesKeyOrId)
            true
        }
        fastMetaPrefs.edit().putStringSet(key, current).apply()
        return added
    }

    fun isSeriesInWatchlist(seriesKeyOrId: String, accountScope: String? = null): Boolean {
        if (seriesKeyOrId.isBlank()) return false
        return getSeriesWatchlistIds(accountScope).contains(seriesKeyOrId)
    }

    // =========================================================================
    // v18.1 SMART AUTO NEXT EPISODE, SEARCH HISTORY & PERFORMANCE MODES
    // =========================================================================

    fun isAutoNextEpisodeEnabled(): Boolean {
        return fastMetaPrefs.getBoolean(AUTO_NEXT_EPISODE_KEY, true)
    }

    fun setAutoNextEpisodeEnabled(enabled: Boolean) {
        fastMetaPrefs.edit().putBoolean(AUTO_NEXT_EPISODE_KEY, enabled).apply()
    }

    fun getSearchHistory(): List<String> {
        val raw = fastMetaPrefs.getString(SEARCH_HISTORY_KEY, "") ?: ""
        return raw.lines().map { it.trim() }.filter { it.isNotEmpty() }.take(MAX_SEARCH_HISTORY)
    }

    fun addSearchHistoryQuery(query: String) {
        val clean = sanitizeExternalInput(query)
        if (clean.length < 2) return
        val current = getSearchHistory().toMutableList()
        current.removeAll { it.equals(clean, ignoreCase = true) }
        current.add(0, clean)
        val trimmed = current.take(MAX_SEARCH_HISTORY)
        fastMetaPrefs.edit().putString(SEARCH_HISTORY_KEY, trimmed.joinToString("\n")).apply()
    }

    fun clearSearchHistory() {
        fastMetaPrefs.edit().remove(SEARCH_HISTORY_KEY).apply()
    }

    fun getPerformanceMode(isLowRamDevice: Boolean): PerformanceMode {
        val savedId = fastMetaPrefs.getString(PERFORMANCE_MODE_KEY, null)
        return PerformanceMode.fromId(savedId, isLowRamDevice)
    }

    fun setPerformanceMode(mode: PerformanceMode) {
        fastMetaPrefs.edit().putString(PERFORMANCE_MODE_KEY, mode.id).apply()
    }

    @Synchronized
    private fun persist(list: List<PlaylistProfile>) {
        cachedProfiles = list.toMutableList()
        fastMetaPrefs.edit().putBoolean("has_saved_profiles", list.isNotEmpty()).apply()
        try {
            val arr = JSONArray()
            list.forEach { p ->
                arr.put(
                    JSONObject()
                        .put("id", p.id)
                        .put("name", p.name)
                        .put("type", p.type.name)
                        .put("source", p.source)
                        .put("username", p.username)
                        .put("password", p.password)
                )
            }
            val rawJson = arr.toString()
            val prefInstance = securePrefs
            val toStore = if (usingFallbackPrefs) encryptFallbackPayload(rawJson) else rawJson
            prefInstance.edit().putString("profiles", toStore).apply()
        } catch (e: Exception) {
            Log.w("StreamX", "Failed to persist profiles")
        }
    }
}
